// Geometry Uniqueness Attributes 
//
#include <stdlib.h>
#include <windows.h>		/* must include this before GL/gl.h */
#include <OBJBASE.H>
#include <direct.h>
#include <GL/gl.h>			/* OpenGL header file */
#include <GL/glext.h>		/* OpenGL header file */
#include <GL/wglext.h>
#include <stdio.h>
#include <math.h>
#include <commdlg.h>
#include "resource.h"
#include <geoutil.h>
#include <matrix.h>
#include <link.h>
#include "ds_color.h"
#include "ds_sph.h"
#include "ds_file.h"
//-----------------------------------------------------------------------------------
void gut_scale_vector(GUT_VECTOR *a, double s, GUT_VECTOR *b)
//-----------------------------------------------------------------------------------
{
	b->i = a->i * s;
	b->j = a->j * s;
	b->k = a->k * s;
	b->l = a->l * s;
}

//-----------------------------------------------------------------------------------
void gut_point_on_line(GUT_POINT *a, GUT_POINT *b, double t, GUT_POINT *c)
//-----------------------------------------------------------------------------------
{
	c->x = (b->x - a->x) * t + a->x;
	c->y = (b->y - a->y) * t + a->y;
	c->z = (b->z - a->z) * t + a->z;
}

//-----------------------------------------------------------------------------------
void gut_add_vector(GUT_VECTOR *a, GUT_VECTOR *b, GUT_VECTOR *c)
//-----------------------------------------------------------------------------------
{
	c->i = a->i + b->i;
	c->j = a->j + b->j;
	c->k = a->k + b->k;
	c->l = a->l + b->l;
}

//-----------------------------------------------------------------------------------
void gut_reverse_vector(GUT_VECTOR *a)
//-----------------------------------------------------------------------------------
{
	a->i = -a->i;
	a->j = -a->j;
	a->k = -a->k;
	a->l = -a->l;
}

//-----------------------------------------------------------------------------------
 void geo_scale_pt(VERTEX *a, VERTEX *b, double d)
//-----------------------------------------------------------------------------------
{
	b->x = a->x * d;
	b->y = a->y * d;
	b->z = a->z * d;
}

//-----------------------------------------------------------------------------------
int gut_point_plus_vector(GUT_POINT *a, GUT_VECTOR *v, GUT_POINT *b)
//-----------------------------------------------------------------------------------
{
	b->x = a->x + v->i;
	b->y = a->y + v->j;
	b->z = a->z + v->k;
	return 0;
}

//-----------------------------------------------------------------------------------
int geo_plane_from_points(GUT_POINT *a, GUT_POINT *b, GUT_POINT *c, GUT_PLANE *p) //GUT_POINT *a, GUT_POINT *b, GUT_POINT *c, GUT_PLANE *p
//-----------------------------------------------------------------------------------
{
	/*
	A = y1 (z2 - z3) + y2 (z3 - z1) + y3 (z1 - z2)
	B = z1 (x2 - x3) + z2 (x3 - x1) + z3 (x1 - x2)
	C = x1 (y2 - y3) + x2 (y3 - y1) + x3 (y1 - y2)
   -D = x1 (y2 z3 - y3 z2) + x2 (y3 z1 - y1 z3) + x3 (y1 z2 - y2 z1)
	*/
	p->A = a->y * (b->z - c->z) + b->y * (c->z - a->z) + c->y * (a->z - b->z);
	p->B = a->z * (b->x - c->x) + b->z * (c->x - a->x) + c->z * (a->x - b->x);
	p->C = a->x * (b->y - c->y) + b->x * (c->y - a->y) + c->x * (a->y - b->y);
	p->D = -(a->x * (b->y * c->z - c->y * b->z) + b->x * (c->y * a->z - a->y * c->z) + c->x * (a->y * b->z - b->y * a->z));
	geo_normalize_plane(p);
	return 0;
}

//-----------------------------------------------------------------------------------
int geo_normalize_plane(GUT_PLANE *p) //GUT_PLANE *p
//-----------------------------------------------------------------------------------
{
	double	d;
	d = sqrt(p->A * p->A + p->B * p->B + p->C * p->C);
	if (d < 0.00000000001)
		return 1;	
	d = 1 / d;
	p->A *= d;
	p->B *= d;
	p->C *= d;
	p->D *= d;
	return 0;
}

//-----------------------------------------------------------------------------------
void geo_edge_to_triangles(CTX *ctx, EDGE_ATTRIBUTES *eattr, VERTEX *a, VERTEX *b, VERTEX *out, int normalize, GUT_POINT *origin)
//-----------------------------------------------------------------------------------
{
	// create new points that represent triangles around edge
	GUT_POINT			*o = origin;
	GUT_PLANE	p; 
	GUT_VECTOR	v; 
	double		d;

//	gut_distance_from_point_to_point(a, b, &d);
	d = eattr->maxLength;
	geo_plane_from_points(origin, b, a, &p);
	d *= eattr->width / 2; // scale the edge length
	v.i = p.A * d; // scale the normal vector
	v.j = p.B * d;
	v.k = p.C * d;
	gut_point_plus_vector(a, &v, &out[0]);
	gut_point_plus_vector(b, &v, &out[1]);
	v.i *= -1; // reverse the direction
	v.j *= -1;
	v.k *= -1;
	gut_point_plus_vector(b, &v, &out[2]);
	gut_point_plus_vector(a, &v, &out[3]);
	d = (1 - eattr->height);
	geo_scale_pt(&out[0], &out[4], d);
	geo_scale_pt(&out[1], &out[5], d);
	geo_scale_pt(&out[2], &out[6], d);
	geo_scale_pt(&out[3], &out[7], d);
	// triangle out(0,1,2) - top
	// triangle out(2,3,0) - top
	// triangle out(0,4,5) - side
	// triangle out(5,1,0) - side 
	// triangle out(2,6,7) - side 
	// triangle out(7,3,2) - side 
	if (eattr->offset != 1.0)
	{	// move the points radially (in or out)
		d = eattr->offset;
		geo_scale_pt(&out[0], &out[0], d);
		geo_scale_pt(&out[1], &out[1], d);
		geo_scale_pt(&out[2], &out[2], d);
		geo_scale_pt(&out[3], &out[3], d);
		geo_scale_pt(&out[4], &out[4], d);
		geo_scale_pt(&out[5], &out[5], d);
		geo_scale_pt(&out[6], &out[6], d);
		geo_scale_pt(&out[7], &out[7], d);
	}
}
//-----------------------------------------------------------------------------------
void geo_edge_to_triangles_hex_axii(EDGE_ATTRIBUTES *eattr, VERTEX *a, VERTEX *b, VERTEX *p, GUT_VECTOR *x, GUT_VECTOR *y, GUT_VECTOR *z, GUT_VECTOR *n, int normalize, GUT_POINT *origin)
//-----------------------------------------------------------------------------------
{
	// create normals
	GUT_VECTOR	h, w, r, tmp;
	GUT_POINT	m;
	double		rad, d;
	double		angle, aInc;
	int			i, j, nSeg=6;

	// create points 
	gut_distance_from_point_to_point((GUT_POINT*)a, (GUT_POINT*)b, &d);
	rad = d * eattr->width / 2;

	for (i = 0, j=6, angle = 0, aInc = 360.0 / nSeg; i < nSeg; ++i, angle += aInc, ++j)
	{
		gut_scale_vector(z, rad * sin(DTR(angle)), &h);
		gut_scale_vector(x, rad * cos(DTR(angle)), &w);
		gut_add_vector(&h, &w, &tmp);
		gut_point_plus_vector((GUT_POINT*)a, &tmp, &p[i]);
		gut_point_plus_vector((GUT_POINT*)b, &tmp, &p[j]);
		n[i] = tmp;
		gut_normalize_vector(&n[i]);
	}
}
//
//int draw_vertex(double scale, GUT_POINT *vertex, GEO_OBJECT *obj)
//{
//	return 0;
//}

//***********************************************************************************
int gut_point_on_line_closest_to_origin(GUT_POINT *p1, GUT_POINT *p2, GUT_POINT *closest, double *t)
//***********************************************************************************
{
	double	a,
		b,
		c,
		d;

	a = p2->x - p1->x;
	b = p2->y - p1->y;
	c = p2->z - p1->z;

	d = (a * p1->x + b * p1->y + c * p1->z) / (a * a + b * b + c * c);

	// return parametric 't' value
	*t = d;

	closest->x = p1->x - d * a;
	closest->y = p1->y - d * b;
	closest->z = p1->z - d * c;

	return 0;
}

void geo_build_transform_matrix ( CTX *ctx )
{ 
	GUT_POINT	xAxis, yAxis, zAxis;
	// build transformation matrix
	// normalize vectors 
	zAxis = *(GUT_POINT*)&ctx->inputTrans.zAxis;
	yAxis = *(GUT_POINT*)&ctx->inputTrans.yAxis;
	gut_normalize_point(&zAxis);
	gut_normalize_point(&yAxis);

	gut_cross_product(&yAxis, &zAxis, &xAxis);
	gut_normalize_point(&xAxis);
	gut_cross_product(&zAxis, &xAxis, &yAxis);
	gut_normalize_point(&yAxis);

	// set unit matrix initially
	mtx_set_unity(&ctx->inputTrans.matrix[0]);

	ctx->inputTrans.matrix[0].data.array[0]  = xAxis.x;
	ctx->inputTrans.matrix[0].data.array[4]  = xAxis.y;
	ctx->inputTrans.matrix[0].data.array[8]  = xAxis.z;
										    
	ctx->inputTrans.matrix[0].data.array[1]  = yAxis.x;
	ctx->inputTrans.matrix[0].data.array[5]  = yAxis.y;
	ctx->inputTrans.matrix[0].data.array[9]  = yAxis.z;
										    
	ctx->inputTrans.matrix[0].data.array[2]  = zAxis.x;
	ctx->inputTrans.matrix[0].data.array[6]  = zAxis.y;
	ctx->inputTrans.matrix[0].data.array[10] = zAxis.z;
}

//-----------------------------------------------------------------------------------
void geo_edge_to_triangles_hex_axii2(EDGE_ATTRIBUTES *eattr, VERTEX *a, VERTEX *b, VERTEX *pa, VERTEX *pb, GUT_VECTOR *x, GUT_VECTOR *y, GUT_VECTOR *z, GUT_VECTOR *n, int normalize, GUT_POINT *origin)
//-----------------------------------------------------------------------------------
{
	// create normals
	GUT_VECTOR	h, w, r, tmp;
	GUT_POINT	m;
	double		rad, d;
	int			i, nSeg;
	double		angle, aInc; 

	// create points around the cylinder
	gut_distance_from_point_to_point((GUT_POINT*)a, (GUT_POINT*)b, &d);
	rad = d * eattr->width / 2;

	for (i = 0, angle = 0, aInc = 360.0 / nSeg; i < nSeg; ++i, angle += aInc)
	{
		gut_scale_vector(z, rad * sin(DTR(angle)), &h);
		gut_scale_vector(x, rad * cos(DTR(angle)), &w);
		gut_add_vector(&h, &w, &tmp);
		gut_point_plus_vector((GUT_POINT*)a, &tmp, &pa[i]);
		gut_point_plus_vector((GUT_POINT*)b, &tmp, &pb[i]);
		n[i] = tmp;
		gut_normalize_vector(&n[i]);
	}
}

//-----------------------------------------------------------------------------------
void geo_edge_to_triangles_hex(CTX *ctx, EDGE_ATTRIBUTES *eattr, VERTEX *a, VERTEX *b, VERTEX *pa, VERTEX *pb, GUT_VECTOR *n, int normalize, GUT_POINT *origin, int nSeg)
//-----------------------------------------------------------------------------------
{
	// a & b are the endpoints of the line
	// p[] is the array of new endpoints arranged in 2 pairs of 6 vertices surrounding each end point
	// n[] is the normals to apply to each new endpoint when drawing
	// normalize is a flag 
	// origin is the local origin point
	//
	// create normals
	GUT_VECTOR	z, x, y, h, w, r, tmp;
	GUT_POINT	m;
	double		rad, d, t;
	int			i;
	double		angle, aInc;

	gut_vector((GUT_POINT*)a, (GUT_POINT*)b, &y);
	gut_normalize_vector(&y);

	gut_point_on_line_closest_to_origin((GUT_POINT*)a, (GUT_POINT*)b, &m, &t);
	gut_distance_from_point_to_point(&m, origin, &d);
	if (d < 0.00001) // line ab passes thru origin
	{
		z.i = 0; z.j = 0.0; z.k = 1.0; z.l = 0.0; // z axis
		gut_dot_product(&z, &y, &d);
		if (fabs(d - 1.0) < 0.000001)
		{
			z.i = 0.0; z.j = 1.0; z.k = 0.0;
			x.i = 1.0; x.j = 0.0; x.k = 0.0;
		}
		else
			gut_cross_product(&y, &z, &x);
	}
	else
	{
		gut_vector(&m, origin, &x); // line from origin to point on line is local x axis
		gut_normalize_vector(&x);
		gut_cross_product(&x, &y, &z);
	}

	// create points 
	d = ctx->eAttr.maxLength;
	rad = d * eattr->width / 2;

	for (i = 0, angle = 0, aInc = 360.0 / nSeg; i < nSeg; ++i, angle += aInc)
	{
		gut_scale_vector(&z, rad * sin(DTR(angle)), &h);
		gut_scale_vector(&x, rad * cos(DTR(angle)), &w);
		gut_add_vector(&h, &w, &tmp);
		gut_point_plus_vector((GUT_POINT*)a, &tmp, &pa[i]);
		gut_point_plus_vector((GUT_POINT*)b, &tmp, &pb[i]);
		n[i] = tmp;
		gut_normalize_vector(&n[i]);
	}
}
