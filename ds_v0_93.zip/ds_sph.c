
/* An example of processing mouse events in an OpenGL program using the Win32 API. */

#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <stdlib.h>
#include <windows.h>		/* must include this before GL/gl.h */
#include <OBJBASE.H>
#include <direct.h>
#include <ShlObj.h>
#include <GL/gl.h>			/* OpenGL header file */
#include <GL/glext.h>		/* OpenGL header file */
#include <GL/wglext.h>
#include <stdio.h>
#include <math.h>
#include <commdlg.h>
#include "resource.h"
#include <geoutil.h>
#include <matrix.h>
#include <link.h>
#include "ds_color.h"
#include "ds_sph.h"
#include "ds_file.h"
#include "ds_gua.h"

#define _WIN32_DCOM
WINOLEAPI  CoInitializeEx(LPVOID pvReserved, DWORD dwCoInit);
LONG WINAPI WindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
LONG WINAPI WindowProc2(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
void reshape(HWND hWnd, int width, int height);

#define clamp(x) x = x > 360.0f ? x-360.0f : x < -360.0f ? x+=360.0f : x

//-----------------------------------------------------------------------------
static void update ( CTX *ctx, int state, int ox, int nx, int oy, int ny )
//-----------------------------------------------------------------------------
{
	int dx = ox - nx;
	int dy = ny - oy;

	switch(state) {
	case PAN:
		ctx->trans[0] -= dx / 100.0f;
		ctx->trans[1] -= dy / 100.0f;
		break;

	case ROTATE:
		ctx->rot[0] += (dy * 180.0f) / 500.0f;
		ctx->rot[1] -= (dx * 180.0f) / 500.0f;
		clamp(ctx->rot[0]);
		clamp(ctx->rot[1]);
		{
			MTX_MATRIX	mrx,
				mry,
				mm;

			mtx_create_rotation_matrix(&mrx, MTX_ROTATE_X_AXIS, DTR(ctx->rot[0]));
			mtx_multiply_matrix(&ctx->matrix, &mrx, &mm);
			mtx_create_rotation_matrix(&mry, MTX_ROTATE_Y_AXIS, DTR(ctx->rot[1]));
			mtx_multiply_matrix(&mm, &mry, &ctx->matrix);
		}
		ctx->rot[0] = ctx->rot[1] = ctx->rot[2] = 0;
		break;

	case ROTATE_Z:
		ctx->rot[2] += (-dy * 180.0f) / 500.0f;
		clamp(ctx->rot[2]);
		{
			MTX_MATRIX	mrx,
				mry,
				mm;

			mtx_create_rotation_matrix(&mrx, MTX_ROTATE_Z_AXIS, DTR(ctx->rot[2]));
			mtx_multiply_matrix(&ctx->matrix, &mrx, &mm);
			ctx->matrix = mm;
		}
		ctx->rot[0] = ctx->rot[1] = ctx->rot[2] = 0;
		break;

	case 3:
	case 5:
//	case ZOOM:
		ctx->trans[2] -= (dx+dy) / 100.0f;
		reshape(ctx->mainWindow, ctx->window.width, ctx->window.height);
		break;
	}
}

//-----------------------------------------------------------------------------
static void update3(CTX *ctx, int dx, int dy, int dz )
//-----------------------------------------------------------------------------
{
	ctx->rot[0] += (double)dy/2.0;
	ctx->rot[1] += (double)dx/2.0;
	ctx->rot[2] += (double)dz/2.0;
	clamp(ctx->rot[0]);
	clamp(ctx->rot[1]);
	clamp(ctx->rot[2]);
	{
		MTX_MATRIX	m_src, m_dst;

		mtx_create_rotation_matrix(&m_src, MTX_ROTATE_X_AXIS, DTR(ctx->rot[0]));
		mtx_multiply_matrix(&ctx->matrix, &m_src, &m_dst);
		mtx_create_rotation_matrix(&m_src, MTX_ROTATE_Y_AXIS, DTR(ctx->rot[1]));
		mtx_multiply_matrix(&m_dst, &m_src, &ctx->matrix);
		mtx_create_rotation_matrix(&m_src, MTX_ROTATE_Z_AXIS, DTR(ctx->rot[2]));
		mtx_multiply_matrix(&ctx->matrix, &m_src, &m_dst);
		ctx->matrix = m_dst;
	}
	ctx->rot[0] = ctx->rot[1] = ctx->rot[2] = 0;
}

//-----------------------------------------------------------------------------
static void update2 ( CTX *ctx, int state, double dx, double dy, double dz )
//-----------------------------------------------------------------------------
{
	switch (state) {
	case PAN:
		ctx->trans[0] -= (float)dx / 100.0f;
		ctx->trans[1] -= (float)dy / 100.0f;
		break;
	
	case ROTATE:
		ctx->rot[0] = (float)dx;
		ctx->rot[1] = (float)dy;
		ctx->rot[2] = (float)dz;
		{
			MTX_MATRIX	mrx,
						mry,
						mm;

			mtx_create_rotation_matrix(&mrx, MTX_ROTATE_X_AXIS, DTR(ctx->rot[0]));
			mtx_multiply_matrix(&ctx->matrix, &mrx, &mm);
			mtx_create_rotation_matrix(&mry, MTX_ROTATE_Y_AXIS, DTR(ctx->rot[1]));
			mtx_multiply_matrix(&mm, &mry, &ctx->matrix);
			mtx_create_rotation_matrix(&mry, MTX_ROTATE_Z_AXIS, DTR(ctx->rot[2]));
			mtx_multiply_matrix(&ctx->matrix, &mry, &mm);
			ctx->matrix = mm;
		}
		break;
	
	case 3:
	case 5:
//	case ZOOM:
		ctx->trans[2] -= ((float)dx + (float)dy) / 100.0f;
		reshape(ctx->mainWindow, ctx->window.width, ctx->window.height);
		break;
	}
}

//-----------------------------------------------------------------------------
void reshape ( HWND hWnd, int width, int height )
//-----------------------------------------------------------------------------
{
	CTX		*ctx;
	float	ar;
	float	zoom; 

	ctx = (CTX*)GetWindowLong ( hWnd, GWL_USERDATA );
	if (!ctx)
		return;

	ctx->window.width  = width;
	ctx->window.height = height;
	ar = (float)(width) / (float)height;

	glViewport( 0, 0, width, height );
    glMatrixMode ( GL_PROJECTION );
    glLoadIdentity ();
	if ( ctx->drawAdj.projection == GEOMETRY_PROJECTION_ORTHOGRAPHIC )
	{
		double	size = 1.045;
		double  zoom;
		//        left,  right,  bottom, top, nearVal, farVal
		zoom = -ctx->trans[2]*0.25 + 1;
		glOrtho(-size*ar*zoom , size*ar*zoom, -size*zoom, size*zoom, -100.00f, 100.0f);
	}
	else if (ctx->drawAdj.projection == GEOMETRY_PROJECTION_PERPSECTIVE )
	{
		float	f, 
				zn, 
				zf;
		GLfloat	m[16];

		// projective
		f = (float)( 1.0 / tan ( DTR( 15.0 ) ) );
		zn = 0.001f;
		zf = 100.0f;
		
		m[0] = f / ar;
		m[1] = 0.0f;
		m[2] = 0.0f;
		m[3] = 0.0f;

		m[4] = 0.0f;
		m[5] = f;
		m[6] = 0.0f;
		m[7] = 0.0f;

		m[8] = 0.0f;
		m[9] = 0.0f;
		m[10] = ( zf + zn ) / ( zn - zf );
		m[11] = -1.0f ;

		m[12] = 0.0f;
		m[13] = 0.0f;
		m[14] = ( 2.0f * zf * zn ) / ( zn - zf );
		m[15] = 0.0f; // 0.0f;

		glLoadMatrixf ( m );
	}
    glMatrixMode ( GL_MODELVIEW );
    glLoadIdentity ();
	glTranslatef(0.f, 0.f, -4.0f);
}

//-----------------------------------------------------------------------------
static void PositionWindow(CTX *ctx, HWND hWnd, int flag, RECT *rect)
//-----------------------------------------------------------------------------
{
	// only call when tool window is first visible 
	HMONITOR	monitor = MonitorFromWindow(ctx->mainWindow, MONITOR_DEFAULTTONEAREST);
	MONITORINFO	info;
	RECT		mrect, arect, trect;
	int			left, top;
	int			x_offset = 10, y_offset = 10;

	info.cbSize = sizeof(MONITORINFO);
	GetMonitorInfo(monitor, &info);
/*
	int monitor_width = info.rcMonitor.right - info.rcMonitor.left;
	int monitor_height = info.rcMonitor.bottom - info.rcMonitor.top;
	GetWindowRect(ctx->mainWindow, &mrect);
	GetWindowRect(hWnd, &trect);

	if (hWnd == ctx->attrControl)
	{
		GetWindowRect(ctx->attrControl, &arect);
		if (mrect.right < info.rcMonitor.right)
			left = mrect.right + 10;
		else
			left = mrect.left + 10;
		MoveWindow(ctx->attrControl, left, mrect.top, arect.right - arect.left, arect.bottom - arect.top, 1);
	}
	if (hWnd == ctx->objControl)
	{
		GetWindowRect(ctx->objControl, &arect);
		if (mrect.bottom < info.rcMonitor.bottom)
		{
			left = mrect.left;
			top = mrect.bottom + 1;
		}
		else
		{
			left = mrect.left + 10;
			top = mrect.top + 10;
		}
		if ( !flag) // new position
			MoveWindow(ctx->objControl, left, top, arect.right - arect.left, arect.bottom - arect.top, 1);
		else // use previous position
			MoveWindow(ctx->objControl, rect->left, rect->top, arect.right - arect.left, arect.bottom - arect.top, 1);
	}
*/
	int mon_w, main_w, tool_w; 
	int mon_h, main_h, tool_h;
	mon_w = info.rcMonitor.right - info.rcMonitor.left;
	mon_h = info.rcMonitor.bottom - info.rcMonitor.top;
	GetWindowRect(ctx->mainWindow, &mrect);
	main_w = mrect.right - mrect.left;
	main_h = mrect.bottom - mrect.top;
	GetWindowRect(hWnd, &trect);
	tool_w = trect.right - trect.left;
	tool_h = trect.bottom - trect.top;

	if (hWnd == ctx->attrControl)
	{
		top = mrect.top + y_offset;
		if (mrect.right + tool_w + x_offset < info.rcMonitor.right)
		{ // normal
			left = mrect.right + x_offset;
		}
		else
		{
			left = info.rcMonitor.right - tool_w - x_offset;
		}
		MoveWindow(hWnd, left, top, tool_w, tool_h, 1);
	}
	else if (hWnd == ctx->objControl)
	{
		left = mrect.left + x_offset;
		if (mrect.bottom + tool_h + y_offset < info.rcMonitor.bottom)
		{ // normal
			top = mrect.bottom + y_offset;
		}
		else
		{
			top = info.rcMonitor.bottom - tool_h - y_offset;
		}
		MoveWindow(hWnd, left, top, tool_w, tool_h, 1);
	}
}

//-----------------------------------------------------------------------------
void setRenderQuality(CTX *ctx)
//-----------------------------------------------------------------------------
{
	if (ctx->drawAdj.hiResFlag) // need to reset pointers
	{
		ctx->drawAdj.quality = &ctx->drawAdj.hiRes; // edge 
		ctx->renderVertex.vtxObj = &ctx->renderVertex.vtxObjHiRes; // vertex
	}
	else
	{
		ctx->drawAdj.quality = &ctx->drawAdj.loRes; // edge
		ctx->renderVertex.vtxObj = &ctx->renderVertex.vtxObjLoRes; // vertex
	}
}

//-----------------------------------------------------------------------------
static void UpdateObjControlWindow(CTX *ctx)
//-----------------------------------------------------------------------------
{
	RECT	rect;
	// if window visible then save top,left position
	if (ctx->objControl)
	{
		GetWindowRect(ctx->objControl, &rect); // get existing rectangle
		DestroyWindow(ctx->objControl); //destroy existing
		ctx->objControl = CreateDialog(ctx->hInstance, MAKEINTRESOURCE(IDD_DIALOG8), ctx->mainWindow, DlgObjectControl);
		ShowWindow(ctx->objControl, SW_SHOW);// make window visible
		PositionWindow(ctx, ctx->objControl, 1, &rect); // move windows to appropriate spots - bottom or right of the current window 
	}
}

//-----------------------------------------------------------------------------
LONG WINAPI WindowProc ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
//-----------------------------------------------------------------------------
{
    static PAINTSTRUCT	ps;
    static GLboolean	left  = GL_FALSE;	/* left button currently down? */
    static GLboolean	right = GL_FALSE;	/* right button currently down? */
    static GLuint		state   = 0;	/* mouse state flag */
    static int			omx = 0, omy=0, mx=0, my=0, keyState=0;
	CTX					*ctx;

	ctx = (CTX*)GetWindowLong ( hWnd, GWL_USERDATA ); // user context has been stored in the window structure

	switch ( uMsg ) {
	case WM_CREATE:
		DragAcceptFiles ( hWnd, TRUE );
		break;

	case WM_SHOWWINDOW:
		// open tool windows 
		if (ctx && ctx->window.toolsVisible)
		{
			ctx->attrControl = CreateDialog(ctx->hInstance, MAKEINTRESOURCE(IDD_DIALOG5), hWnd, DlgAttributesFull);
			ShowWindow(ctx->attrControl, SW_SHOW);
			PositionWindow(ctx, ctx->attrControl,0,0); // move windows to appropriate spots - bottom or right of the current window 

			ctx->objControl = CreateDialog(ctx->hInstance, MAKEINTRESOURCE(IDD_DIALOG8), hWnd, DlgObjectControl);
//			ctx->objControl = CreateDialog(ctx->hInstance, MAKEINTRESOURCE(IDD_DIALOG7), hWnd, DlgObjectControl5);
			ShowWindow(ctx->objControl, SW_SHOW);
			PositionWindow(ctx, ctx->objControl,0,0); // move windows to appropriate spots - bottom or right of the current window 
		}
		InvalidateRect(hWnd, 0, 0);
		break;

	case WM_COMMAND: 
        // Test for the identifier of a command item. 
		switch (LOWORD(wParam)) {
		case ID_FILE_OPEN_POLY:
			DoFileDialog(hWnd, ctx, 0);   // application-defined 
			SendMessage(ctx->objInfo, WM_PAINT, 0, 0);//init
			UpdateObjControlWindow(ctx);
			InvalidateRect(hWnd, 0, 0);
			SendMessage(ctx->objInfo, WM_PAINT, 0, 0);
			//			return 0;
			break;

		case ID_FILE_OPEN_POLY_ADD:
			ctx->gobjAddFlag = 1;
			DoFileDialog(hWnd, ctx, 0);   // application-defined 
			SendMessage(ctx->objInfo, WM_PAINT, 0, 0);//init
			UpdateObjControlWindow(ctx);
			ctx->gobjAddFlag = 0;
			InvalidateRect(hWnd, 0, 0);
			SendMessage(ctx->objInfo, WM_PAINT, 0, 0);
			break;

		case ID_FILE_READCOLORTABLES:
			DoFileDialog(hWnd, ctx, 1);   // application-defined 
			InvalidateRect(hWnd, 0, 0);
			break;

		case ID_FILE_REPEAT:
			if (!ReadFileFromBuffer(ctx)) {
				InvalidateRect(hWnd, 0, 0);
				SendMessage(ctx->objInfo, WM_PAINT, 0, 0);
				SendMessage(ctx->objControl, WM_INITDIALOG, 0, 0);//init
			}
			break;

		case ID_FILE_EXIT:
			exit(0);
			break;

		case ID_FILE_ABOUT:
			DialogBox(ctx->hInstance, MAKEINTRESOURCE(IDD_DIALOG1), hWnd, DlgAbout);
			break;
		
		case ID_FILE_ATTRIBUTECONTROL:
			if (!ctx->attrControl)
			{
				ctx->attrControl = CreateDialog(ctx->hInstance, MAKEINTRESOURCE(IDD_DIALOG5), hWnd, DlgAttributesFull);
				ShowWindow(ctx->attrControl, SW_SHOW);
				PositionWindow(ctx, ctx->attrControl,0,0);
			}
			break;

		case ID_FILE_OBJECTCONTROL:
			if (!ctx->objControl)
			{
				ctx->objControl = CreateDialog(ctx->hInstance, MAKEINTRESOURCE(IDD_DIALOG8), hWnd, DlgObjectControl);
//				ctx->objControl = CreateDialog(ctx->hInstance, MAKEINTRESOURCE(IDD_DIALOG7), hWnd, DlgObjectControl5);
				ShowWindow(ctx->objControl, SW_SHOW);
				PositionWindow(ctx, ctx->objControl,0,0); // move windows to appropriate spots - bottom or right of the current window 
			}
			break;

		case ID_FILE_OBJECTINFORMATION:
			if (!ctx->objInfo)
			{
				ctx->objInfo = CreateDialog(ctx->hInstance, MAKEINTRESOURCE(IDD_DIALOG6), hWnd, DlgObjectInformation);
				ShowWindow(ctx->objInfo, SW_SHOW);
//				PositionWindow(ctx, ctx->objInfo); // move windows to appropriate spots - bottom or right of the current window 
			}
			break;

		case ID_SHOW_TOGGLE:
			ctx->kbdToggle = CreateDialog(ctx->hInstance, MAKEINTRESOURCE(IDD_DIALOG2), hWnd, DlgKbdToggles);
			ShowWindow(ctx->kbdToggle, SW_SHOW);
			break;
		}
		break;

	case WM_DROPFILES:
		if ( GetKeyState(VK_SHIFT) & 0x1000 ) // check high order bit to see if key is down
			ctx->gobjAddFlag = 1; // return to default state
		FILM_DragAndDrop ( hWnd, (HDROP)wParam );
		InvalidateRect(hWnd, 0, 0);
		SendMessage(ctx->objInfo, WM_PAINT, 0, 0);//init
		break;

	case WM_SIZE:
		reshape ( hWnd, LOWORD( lParam ), HIWORD( lParam ) );
		InvalidateRect(hWnd, 0, 0);
		SendMessage(ctx->attrControl, WM_PAINT, 0, 0);//init
		break;

    case WM_KEYDOWN: 
		switch (wParam) {
		case VK_LEFT:  update3(ctx, -1,  0,  0 ); InvalidateRect(hWnd, 0, 0); break;
		case VK_RIGHT: update3(ctx,  1,  0,  0 ); InvalidateRect(hWnd, 0, 0); break;
		case VK_UP:    update3(ctx,  0, -1,  0 ); InvalidateRect(hWnd, 0, 0); break;
		case VK_DOWN:  update3(ctx,  0,  1,  0 ); InvalidateRect(hWnd, 0, 0); break;
		case VK_PRIOR: update3(ctx,  0,  0,  1 ); InvalidateRect(hWnd, 0, 0); break;
		case VK_NEXT:  update3(ctx,  0,  0, -1 ); InvalidateRect(hWnd, 0, 0); break;
		}
		break;

    case WM_CHAR:
		switch (wParam) {
		case '0': ctx->drawAdj.circleFlag = !ctx->drawAdj.circleFlag; break; /* 2 key */
//		case '2': ctx->base_geometry_new.oneFaceFlag = !ctx->base_geometry_new.oneFaceFlag; break; /* 2 key */
		case 'a': ctx->drawAdj.axiiFlag = !ctx->drawAdj.axiiFlag; break; // reset drawing of axii
		case 'b': ctx->geomAdj.polymode[1] += 1; if (ctx->geomAdj.polymode[1] > 2) ctx->geomAdj.polymode[1] = 0; break;// back polymode
		case 'c': ctx->drawAdj.clipFlag = !ctx->drawAdj.clipFlag; break;
		case 'e':
			if (!ctx->objControl)
			{
				ctx->objControl = CreateDialog(ctx->hInstance, MAKEINTRESOURCE(IDD_DIALOG8), hWnd, DlgObjectControl);
				ShowWindow(ctx->objControl, SW_SHOW);
				PositionWindow(ctx, ctx->objControl, 0, 0); // move window to appropriate spot - left or right of the current window 
			}
			break;
		case 'f': ctx->geomAdj.polymode[0] += 1; if (ctx->geomAdj.polymode[0] > 2) ctx->geomAdj.polymode[0] = 0; break;// front polymode
		case 'g': // change base geometry
			switch (ctx->base_geometry_new.type) {
			case GEOMETRY_ICOSAHEDRON: ctx->base_geometry_new.type = GEOMETRY_OCTAHEDRON;  break;
			case GEOMETRY_OCTAHEDRON:  ctx->base_geometry_new.type = GEOMETRY_TETRAHEDRON; break;
			case GEOMETRY_TETRAHEDRON: ctx->base_geometry_new.type = GEOMETRY_CUBEHEDRON;  break;
			case GEOMETRY_CUBEHEDRON:  ctx->base_geometry_new.type = GEOMETRY_ICOSAHEDRON; break;
			}
			File_SetWindowText(hWnd, ctx->filename);
			break;
		case 'h': ctx->drawAdj.hiResFlag = !ctx->drawAdj.hiResFlag; setRenderQuality(ctx); break; 
		case 'i': CaptureAnImage(hWnd); break;
		case 'n': ctx->drawAdj.normalizeFlag = ctx->drawAdj.normalizeFlag ? 0 : 1; break; //global_normalize = ctx->global_normalize ? 0 : 1; break;			/* n key */
		case 'o': // change base geometry orientation
			switch (ctx->geomAdj.orientation) {
			case GEOMETRY_ORIENTATION_FACE: ctx->geomAdj.orientation = GEOMETRY_ORIENTATION_EDGE; break;
			case GEOMETRY_ORIENTATION_EDGE: ctx->geomAdj.orientation = GEOMETRY_ORIENTATION_VERTEX; break;
			case GEOMETRY_ORIENTATION_VERTEX: ctx->geomAdj.orientation = GEOMETRY_ORIENTATION_FACE; break;
			}
			File_SetWindowText(hWnd, ctx->filename);
			break;
		case 'p': ctx->drawAdj.projection = !ctx->drawAdj.projection; reshape(hWnd, ctx->window.width, ctx->window.height); break;	/* p key - switch from perspective to orthographic projection */
		case 'r': ctx->trans[0] = ctx->trans[1] = ctx->trans[2] = 0; ctx->rot[0] = ctx->rot[1] = ctx->rot[2] = 0; mtx_set_unity(&ctx->matrix); reshape(ctx->mainWindow, ctx->window.width, ctx->window.height); break; // reset rotation/translation
		case 's': if (ctx->drawAdj.spin.spinState) { ctx->drawAdj.spin.spinState = 0; KillTimer(hWnd, 0); }
				  else { ctx->drawAdj.spin.spinState = ROTATE; SetTimer(hWnd, 0, (int)ctx->drawAdj.spin.timerMSec, 0); } break; // reset spin of axii
		case 'w':
			if (!ctx->attrControl)
			{
				ctx->attrControl = CreateDialog(ctx->hInstance, MAKEINTRESOURCE(IDD_DIALOG5), hWnd, DlgAttributesFull);
				ShowWindow(ctx->attrControl, SW_SHOW);
				PositionWindow(ctx, ctx->attrControl, 0, 0); // move window to appropriate spot - left or right of the current window 
			}
			break;
		case 'z': ctx->drawAdj.fogFlag  = ctx->drawAdj.fogFlag ? 0 : 1; break;
		case '-':
			if ( ctx->drawAdj.clipFlag )
			{
				ctx->drawAdj.clipZValue -= ctx->drawAdj.clipZIncrement; // clip.z_increment;
				if ( ctx->drawAdj.clipZValue > 1.0 )
					ctx->drawAdj.clipZValue = 1.0;
				else if ( ctx->drawAdj.clipZValue < -1.0 )
					ctx->drawAdj.clipZValue = -1.0;
			}
			break;
		case '+':
		case '=':
			if (ctx->drawAdj.clipFlag)
			{
				ctx->drawAdj.clipZValue += ctx->drawAdj.clipZIncrement; // clip.z_increment;
				if (ctx->drawAdj.clipZValue > 1.0)
					ctx->drawAdj.clipZValue = 1.0;
				else if (ctx->drawAdj.clipZValue < -1.0)
					ctx->drawAdj.clipZValue = -1.0;
			}
			break;
		case 27:			/* ESC key */
			PostQuitMessage(0);
			break;
		}
		InvalidateRect(hWnd, 0, 0);
		SendMessage(ctx->attrControl, WM_PAINT, 0, 0);//init
		break;

    case WM_LBUTTONDOWN:
    case WM_RBUTTONDOWN:
		/* if we don't set the capture we won't get mouse move
			   messages when the mouse moves outside the window. */
		SetCapture(hWnd);
//		keyState = GetKeyState(VK_SHIFT);
		mx = LOWORD(lParam);
		my = HIWORD(lParam);
		if (uMsg == WM_LBUTTONDOWN )
			state |= PAN;
		if (uMsg == WM_RBUTTONDOWN)
			state |= ( GetKeyState(VK_SHIFT) & 0x8000 )  ? ROTATE_Z : ROTATE;
		break; 

    case WM_LBUTTONUP:
    case WM_RBUTTONUP: /* remember to release the capture when we are finished. */
		ReleaseCapture();
		state = 0;
		keyState = 0;
		break;

    case WM_MOUSEMOVE:
		if ( state ) {
			omx = mx;
			omy = my;
			mx = LOWORD(lParam);
			my = HIWORD(lParam);
			/* Win32 is pretty braindead about the x, y position that
			   it returns when the mouse is off the left or top edge
			   of the window (due to them being unsigned). therefore,
			   roll the Win32's 0..2^16 pointer co-ord range to the
			   more amenable (and useful) 0..+/-2^15. */
			if ( mx & 1 << 15 )
				mx -= (1 << 16);
			if ( my & 1 << 15 )
				my -= (1 << 16);
			update ( ctx, state, omx, mx, omy, my );
			InvalidateRect(hWnd, 0, 0);
		}
		break; 

    case WM_PALETTECHANGED:
		if ( hWnd == (HWND)wParam )
			break;
		/* fall through to WM_QUERYNEWPALETTE */
		break;

    case WM_QUERYNEWPALETTE:
		if ( ctx->hPalette ) {
			UnrealizeObject (ctx->hPalette );
			SelectPalette (ctx->hDC, ctx->hPalette, FALSE );
			RealizePalette (ctx->hDC );
//			return TRUE;
		}
		break;

	case WM_CLOSE:
		PostQuitMessage(0);
//		if (fp)
//			fclose(fp);
		exit(0);
		break;

	case WM_PAINT:
		BeginPaint(hWnd, &ps);
		display(ctx);
		EndPaint(hWnd, &ps);
		break;

//	case WM_USER+2:
//		if (ctx->png.nFrames==1 && ctx->png.singleFlag)
//		{
//			--ctx->png.nFrames;
//			CaptureAnImage(hWnd);
//			PostQuitMessage(0);
//		}
//		break;

	case WM_USER+100:
		if (ctx->png.nFrames)//|| ctx->png.singleFlag )
		{
			CaptureAnImage(hWnd);
			--ctx->png.nFrames;
			if ( !ctx->png.nFrames )//|| ctx->png.singleFlag)
				PostQuitMessage(0); // all done
		}
		break;

	case WM_TIMER:
		if (ctx->drawAdj.spin.spinState)
		{
			if (ctx->png.nFrames)
			{
				update2(ctx, ctx->drawAdj.spin.spinState, ctx->drawAdj.spin.dx, ctx->drawAdj.spin.dy, ctx->drawAdj.spin.dz); // update transformation matrix
				InvalidateRect(hWnd, 0, 0);
				PostMessage(hWnd, WM_USER + 100, 0, 0);
			}
			else
			{
				update2(ctx,ctx->drawAdj.spin.spinState, ctx->drawAdj.spin.dx, ctx->drawAdj.spin.dy, ctx->drawAdj.spin.dz); // update transformation matrix
				InvalidateRect(hWnd, 0, 0);
			}
		}
		break;
    }

	return DefWindowProc ( hWnd, uMsg, wParam, lParam );
} 

//-----------------------------------------------------------------------------
int cmdLineOptions(CTX *ctx, LPSTR lpszCmdLine)
//-----------------------------------------------------------------------------
{
	// decode command line options
	char	*p = (char*)lpszCmdLine;

	char	buffer[1024];
	char	*av[64];
	int		ac,
			error=0,
			nextAc,
			badArgIndex;

	// make copy of the command line
	strncpy(buffer, (char*)lpszCmdLine, 1024);

	// parse the command string
	ac = par_lexeme(buffer, av, 64);
	nextAc = 0;

	ds_command_line(ctx, ac, av, &error, &badArgIndex); // NEED TO HANDLE ERRORS
	if (error)
	{
		char	buffer[128];
		//badArgIndex = 0;
		sprintf(buffer, "An error in the command line was encountered at <%s>", av[badArgIndex]);
		MessageBox(NULL, buffer, 0, MB_OK);
	}
	return 0;
}

//-----------------------------------------------------------------------------
int APIENTRY WinMain ( HINSTANCE hCurrentInst, HINSTANCE hPreviousInst, LPSTR lpszCmdLine, int nCmdShow )
//-----------------------------------------------------------------------------
{
	HGLRC	hRC;						/* opengl context */
	HWND	hWnd;						/* window */
	MSG		msg;						/* message */
	DWORD	buffer = PFD_DOUBLEBUFFER;	/* buffering type */
	BYTE	color  = PFD_TYPE_RGBA;		/* color type */
	static CTX		ctx;
	int		method = 3; // 2;

	disp_pre_init(&ctx); // initialize CTX structure prior to command line options being processed

	// process the command line
	cmdLineOptions(&ctx, lpszCmdLine);

	hWnd = CreateOpenGLWindow2(&ctx, "Display Sphere", ctx.window.start_x, ctx.window.start_y, ctx.window.width + WINDOW_SIZE_OFFSET_WIDTH, ctx.window.height + WINDOW_SIZE_OFFSET_HEIGHT);
	if ( hWnd == NULL )
		exit ( 1 );
	ctx.mainWindow = hWnd;

	SetWindowLong ( hWnd, GWL_USERDATA, (long)&ctx );

	ctx.hDC = GetDC ( hWnd );
	hRC = wglCreateContext (ctx.hDC );
    wglMakeCurrent (ctx.hDC, hRC);

	disp_post_init(&ctx);// , polyhedron); // re-initialize neccessary items after window is created and command line is processed 

    ShowWindow(hWnd, nCmdShow);

	while (GetMessage(&msg, NULL, 0, 0))
	{
//		if (!IsWindow(hWnd) 
//			|| !IsDialogMessage(ctx.kbdToggle, &msg) 
//			|| !IsDialogMessage(ctx.attrControl, &msg)
//			|| !IsDialogMessage(ctx.objControl, &msg)
//			)
		if ( !IsDialogMessage(ctx.kbdToggle, &msg)
			&& !IsDialogMessage(ctx.attrControl, &msg)
			&& !IsDialogMessage(ctx.objControl, &msg)
			)
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	ReleaseDC ( ctx.hDC, hWnd );
    wglDeleteContext ( hRC );
    DestroyWindow ( hWnd );

    if ( ctx.hPalette )
		DeleteObject ( ctx.hPalette );

    return 0;
}
void *font = 0; // GLUT_BITMAP_HELVETICA_18;

//-----------------------------------------------------------------------------
void textout ( float offset, float x, float y, float z, char *string )
//-----------------------------------------------------------------------------
{
	int				len,
					i;
	static char		buf[36];

	if ( fabs ( x ) <= 0.0000001 )
		x = 0;
	if ( fabs ( y ) <= 0.0000001 )
		y = 0;
	if ( fabs ( z ) <= 0.0000001 )
		z = 0;

	// format string
	sprintf ( buf, "%6.4f", z );

	x *= offset;
	y *= offset;
	z *= offset;

	glDisable    ( GL_LIGHTING   );
	glColor3f(0.0, 0.0, 0.0);
	glRasterPos3f( x, y, z );
	len = (int) strlen(buf);
	for (i = 0; i < len; i++)
	{
//		glutBitmapCharacter(font, string[i]);
//		glutBitmapCharacter(font, buf[i]);
	}
	glEnable    ( GL_LIGHTING   );

}

//-----------------------------------------------------------------------------
static void FILM_DragAndDrop ( HWND hWnd, HDROP hdrop )
//-----------------------------------------------------------------------------
{
	// DESCRIPTION: Respond to a file drag and drop event.
	//
	// INPUT:
	//    hdrop  Drag and Drop context
	//
	char			buffer[256];
	unsigned int	count, index;
	CTX				*ctx;

	ctx = (CTX*)GetWindowLong(hWnd, GWL_USERDATA);

	// determine if a file is available
	if ( count = DragQueryFile( hdrop, 0xFFFFFFFF, (LPSTR)buffer, (UINT)256 ) )
	{
		for (index = 0; index < count; ++index)
		{
			if (index)
				ctx->gobjAddFlag = 1;

			// get the new filename
			DragQueryFile(hdrop, index, (LPSTR)buffer, (UINT)256);

			// reset the menus
			//FILM_SetDirectoryAndFile ( buffer );
			FileInitialization(hWnd, buffer, 0);
			SendMessage(ctx->objInfo, WM_PAINT, 0, 0);
			UpdateObjControlWindow(ctx);
		}
	}

	// release system resources 
	DragFinish ( hdrop );
	ctx->gobjAddFlag = 0; // return to default state
}

//-----------------------------------------------------------------------------
LRESULT CALLBACK WindowProcedure(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
//-----------------------------------------------------------------------------
{

	switch (message) {
	case WM_KEYDOWN:
		if (wParam == VK_ESCAPE) {
			PostQuitMessage(0);
		}
		break;
	case WM_CLOSE:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;       // message handled
}

//-----------------------------------------------------------------------------
ATOM registerClass(HINSTANCE hInstance)
//-----------------------------------------------------------------------------
{

	WNDCLASSEX wcex;
	ZeroMemory(&wcex, sizeof(wcex));
	wcex.cbSize = sizeof(wcex);
	wcex.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
	wcex.lpfnWndProc = WindowProcedure;
//	wcex.lpfnWndProc = (WNDPROC)WindowProc;
	wcex.hInstance = hInstance;
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcex.lpszClassName = "Core";
//	hInstance = GetModuleHandle(NULL);
//	return RegisterClassEx(&wcex);

	wcex.style = CS_OWNDC | CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
	wcex.lpfnWndProc = (WNDPROC)WindowProc;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hInstance;
	wcex.hIcon = LoadIcon(NULL, IDI_ICON1);
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground = NULL;
	//exwc.lpszMenuName  = NULL;
	wcex.lpszMenuName = MAKEINTRESOURCE(IDR_MENU1);
//	wcex.lpszClassName = "OpenGL";
	wcex.hIconSm = LoadImage(hInstance,
		MAKEINTRESOURCE(IDI_ICON1),
		IMAGE_ICON,
		16,
		16,
		0);

	return RegisterClassEx(&wcex);
}

//-----------------------------------------------------------------------------
HWND CreateOpenGLWindow2(CTX *ctx, char* title, int x, int y, int width, int height )
//-----------------------------------------------------------------------------
{
//	WNDCLASSEX				wc; //	wndclass ;

//	static HINSTANCE		hInstance = 0;

	if (!ctx->hInstance)
		registerClass(ctx->hInstance);

	/* only register the window class once - use hInstance as a flag. */
	HWND fakeWND = CreateWindow(
		"Core", "Fake Window",      // window class, title
		WS_OVERLAPPEDWINDOW | WS_CLIPSIBLINGS | WS_CLIPCHILDREN, // style
		0, 0,                       // position x, y
		1, 1,                       // width, height
		NULL, NULL,                 // parent window, menu
		ctx->hInstance, NULL);           // instance, param

	HDC fakeDC = GetDC(fakeWND);        // Device Context
	PIXELFORMATDESCRIPTOR fakePFD;
	ZeroMemory(&fakePFD, sizeof(fakePFD));
	fakePFD.nSize		= sizeof(fakePFD);
	fakePFD.nVersion	= 1;
	fakePFD.dwFlags		= PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
	fakePFD.iPixelType	= PFD_TYPE_RGBA;
	fakePFD.cColorBits	= 32;
	fakePFD.cAlphaBits	= 8;
	fakePFD.cDepthBits	= 24;

	int fakePFDID = ChoosePixelFormat(fakeDC, &fakePFD);

	if (fakePFDID == 0) {
		MessageBox(NULL,"ChoosePixelFormat() failed.",0,MB_OK);
		return 1;
	}

	if (SetPixelFormat(fakeDC, fakePFDID, &fakePFD) == FALSE) {
		MessageBox(NULL,"SetPixelFormat() failed.", 0, MB_OK);
		return 1;
	}

	HGLRC fakeRC = wglCreateContext(fakeDC);    // Rendering Contex

	if (fakeRC == 0) {
		MessageBox(NULL,"wglCreateContext() failed.", 0, MB_OK);
		return 1;
	}

	if (wglMakeCurrent(fakeDC, fakeRC) == FALSE) {
		MessageBox(NULL,"wglMakeCurrent() failed.", 0, MB_OK);
		return 1;
	}

	PFNWGLCHOOSEPIXELFORMATARBPROC wglChoosePixelFormatARB = NULL;
	wglChoosePixelFormatARB = (PFNWGLCHOOSEPIXELFORMATARBPROC)wglGetProcAddress("wglChoosePixelFormatARB");
	if (wglChoosePixelFormatARB == NULL) {
		MessageBox(NULL,"wglGetProcAddress() failed.", 0, MB_OK);
		return 1;
	}

	PFNWGLCREATECONTEXTATTRIBSARBPROC wglCreateContextAttribsARB = NULL;
	wglCreateContextAttribsARB = (PFNWGLCREATECONTEXTATTRIBSARBPROC)wglGetProcAddress("wglCreateContextAttribsARB");
	if (wglCreateContextAttribsARB == NULL) {
		MessageBox(NULL,"wglGetProcAddress() failed.", 0, MB_OK);
		return 1;
	}

	HWND WND = CreateWindow(
		"Core", "OpenGL Window",        // class name, window name  WS_OVERLAPPEDWINDOW | WS_CLIPSIBLINGS | WS_CLIPCHILDREN
		WS_OVERLAPPEDWINDOW | WS_CAPTION | WS_SYSMENU | WS_CLIPSIBLINGS | WS_CLIPCHILDREN, // style
//		config.posX, config.posY,       // posx, posy
//		config.width, config.height,    // width, height
		x, y,
		width, height,
		NULL, NULL,                     // parent window, menu
		ctx->hInstance, NULL);               // instance, param

	HDC DC = GetDC(WND);

	const int pixelAttribs[] = {
	WGL_DRAW_TO_WINDOW_ARB, GL_TRUE,
	WGL_SUPPORT_OPENGL_ARB, GL_TRUE,
	WGL_DOUBLE_BUFFER_ARB, GL_TRUE,
	WGL_PIXEL_TYPE_ARB, WGL_TYPE_RGBA_ARB,
	WGL_ACCELERATION_ARB, WGL_FULL_ACCELERATION_ARB,
	WGL_COLOR_BITS_ARB, 32,
	WGL_ALPHA_BITS_ARB, 8,
	WGL_DEPTH_BITS_ARB, 24,
	WGL_STENCIL_BITS_ARB, 8,
	WGL_SAMPLE_BUFFERS_ARB, GL_TRUE,
	WGL_SAMPLES_ARB, ctx->opengl.samplesPerPixel, //12, //8,
	0
	};

	int pixelFormatID; UINT numFormats;
	int/*bool*/ status = wglChoosePixelFormatARB(DC, pixelAttribs, NULL, 1, &pixelFormatID, &numFormats);

	if (status == FALSE || numFormats == 0) {
		MessageBox(NULL,"wglChoosePixelFormatARB() failed.",0,MB_OK);
		return 1;
	}

	PIXELFORMATDESCRIPTOR PFD;
	DescribePixelFormat(DC, pixelFormatID, sizeof(PFD), &PFD);
	SetPixelFormat(DC, pixelFormatID, &PFD);

	const int major_min = 4, minor_min = 2; // 5;
	int  contextAttribs[] = {
		WGL_CONTEXT_MAJOR_VERSION_ARB, major_min,
		WGL_CONTEXT_MINOR_VERSION_ARB, minor_min,
		WGL_CONTEXT_PROFILE_MASK_ARB, WGL_CONTEXT_CORE_PROFILE_BIT_ARB,
		0
	};

	HGLRC RC = wglCreateContextAttribsARB(DC, 0, contextAttribs);
	if (RC == NULL) {
		MessageBox(NULL,"wglCreateContextAttribsARB() failed.", 0, MB_OK);
		return 1;
	}

	wglMakeCurrent(NULL, NULL);
	wglDeleteContext(fakeRC);
	ReleaseDC(fakeWND, fakeDC);
	DestroyWindow(fakeWND);
	if (!wglMakeCurrent(DC, RC)) {
		MessageBox(NULL,"wglMakeCurrent() failed.", 0, MB_OK);
		return 1;
	}

	ReleaseDC(WND, DC);
	return WND;
}

#include "common.h"
#include "bmphed.h"
#include "zlib.h"

//-----------------------------------------------------------------------------
int CaptureAnImage(HWND hWnd)
//-----------------------------------------------------------------------------
{
	//	Captures a screenshot into a window and then saves it in a .bmp file.


	HDC		hdcWindow;
	HDC		hdcMemDC = NULL;
	HBITMAP	hbmWindow = NULL;
	BITMAP	bmpWindow;
	CTX		*ctx;
	char	outputFilename[256];

	ctx = (CTX*)GetWindowLong(hWnd, GWL_USERDATA);

	// Retrieve the handle to a display device context for the client area of the window. 
	hdcWindow = GetDC(hWnd);

	// Create a compatible DC which is used in a BitBlt from the window DC
	hdcMemDC = CreateCompatibleDC(hdcWindow);

	if (!hdcMemDC)
	{
		MessageBox(hWnd, L"CreateCompatibleDC has failed", L"Failed", MB_OK);
		goto done;
	}

	// Get the client area for size calculation
	RECT rcClient;
	GetClientRect(hWnd, &rcClient);

	// Create a compatible bitmap from the Window DC
	hbmWindow = CreateCompatibleBitmap(hdcWindow, rcClient.right - rcClient.left, rcClient.bottom - rcClient.top);

	if (!hbmWindow)
	{
		MessageBox(hWnd, L"CreateCompatibleBitmap Failed", L"Failed", MB_OK);
		goto done;
	}

	// Select the compatible bitmap into the compatible memory DC.
	SelectObject(hdcMemDC, hbmWindow);

	// Bit block transfer into our compatible memory DC.
	if (!BitBlt(hdcMemDC,
		0, 0,
		rcClient.right - rcClient.left, rcClient.bottom - rcClient.top,
		hdcWindow,
		0, 0,
		SRCCOPY))
	{
		MessageBox(hWnd, L"BitBlt has failed", L"Failed", MB_OK);
		goto done;
	}

	// Get the BITMAP from the HBITMAP
	GetObject(hbmWindow, sizeof(BITMAP), &bmpWindow);

	BITMAPFILEHEADER   bmfHeader;
	BITMAPINFOHEADER   bi;

	bi.biSize = sizeof(BITMAPINFOHEADER);
	bi.biWidth = bmpWindow.bmWidth;
	bi.biHeight = bmpWindow.bmHeight;
	bi.biPlanes = 1;
	bi.biBitCount = 32;
	bi.biCompression = BI_RGB;
	bi.biSizeImage = 0;
	bi.biXPelsPerMeter = 0;
	bi.biYPelsPerMeter = 0;
	bi.biClrUsed = 0;
	bi.biClrImportant = 0;

	DWORD dwBmpSize = ((bmpWindow.bmWidth * bi.biBitCount + 31) / 32) * 4 * bmpWindow.bmHeight;

	// Starting with 32-bit Windows, GlobalAlloc and LocalAlloc are implemented as wrapper functions that 
	// call HeapAlloc using a handle to the process's default heap. Therefore, GlobalAlloc and LocalAlloc 
	// have greater overhead than HeapAlloc.
	HANDLE hDIB = GlobalAlloc(GHND, dwBmpSize);
	char *lpbitmap = (char *)GlobalLock(hDIB);

	// Gets the "bits" from the bitmap and copies them into a buffer 
	// which is pointed to by lpbitmap.
	GetDIBits(hdcWindow, hbmWindow, 0,
		(UINT)bmpWindow.bmHeight,
		lpbitmap,
		(BITMAPINFO *)&bi, DIB_RGB_COLORS);

	// Add the size of the headers to the size of the bitmap to get the total file size
	DWORD dwSizeofDIB = dwBmpSize + sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);

	//Offset to where the actual bitmap bits start.
	bmfHeader.bfOffBits = (DWORD)sizeof(BITMAPFILEHEADER) + (DWORD)sizeof(BITMAPINFOHEADER);

	//Size of the file
	bmfHeader.bfSize = dwSizeofDIB;

	//bfType must always be BM for Bitmaps
	bmfHeader.bfType = 0x4D42; //BM   

	DWORD dwBytesWritten = 0;
	{ // Call BMP to PNG library
		IMAGE	image;
		image.width = bi.biWidth; // = bmpWindow.bmWidth;
		image.height = bi.biHeight; // = bmpWindow.bmHeight;
		image.pixdepth = 32;
		image.palnum = 0;
		image.topdown = 0;
		image.alpha = 0;
		image.palette = 0;
//		image.rowbytes = ((bi.biWidth * bi.biBitCount + 31) / 32) * 4;
//		image.imgbytes = ((bi.biWidth * bi.biBitCount + 31) / 32) * 4 * bi.biHeight; // lpbitmap;
		image.sigbit.red = image.sigbit.green = image.sigbit.blue = 8;
		image.sigbit.gray = image.sigbit.alpha = 8;
		image.rowbytes = ((DWORD)image.width * image.pixdepth + 31) / 32 * 4;
		image.imgbytes = image.rowbytes * image.height;
		image.rowptr = malloc((size_t)image.height * sizeof(BYTE *));
		image.bmpbits = lpbitmap; // malloc((size_t)image.imgbytes);
		// fill the row pointers
		BYTE *bp, **rp;
		LONG n;

		n  = image.height;
		rp = image.rowptr;
		bp = image.bmpbits;

		bp += image.imgbytes;
		while (--n >= 0) {
			bp -= image.rowbytes;
			*(rp++) = bp;
		}

		if (strlen(ctx->curWorkingDir))
			SetCurrentDirectory(ctx->curWorkingDir);

		if(ctx->png.singleFlag) //do not add index
			sprintf(outputFilename, "%s.png", ctx->png.basename); // , ctx->png.curFrame++);
		else
			sprintf(outputFilename, "%s%05d.png", ctx->png.basename, ctx->png.curFrame++);

		write_png(outputFilename, &image);
		free(image.rowptr);
	}

	//Unlock and Free the DIB from the heap
	GlobalUnlock(hDIB);
	GlobalFree(hDIB);

done: //Clean up
	DeleteObject(hbmWindow);
	DeleteObject(hdcMemDC);
	ReleaseDC(hWnd, hdcWindow);

	return 0;
}
