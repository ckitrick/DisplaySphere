#include <stdlib.h>
#include <windows.h>		/* must include this before GL/gl.h */
#include <OBJBASE.H>
#include <direct.h>
#include <ShlObj.h>
#include <GL/gl.h>			/* OpenGL header file */
#include <GL/glut.h>		/* OpenGL header file */
#include <GL/glext.h>		/* OpenGL header file */
#include <GL/wglext.h>
#include <stdio.h>
#include <math.h>
#include <commdlg.h>
#include "resource.h"
#include <geoutil.h>
#include <matrix.h>
#include <link.h>
#include "ds_color.h"
#include "ds_sph.h"
#include "ds_file.h"
#include "ds_gua.h"

void display_original(CTX *ctx);

//-----------------------------------------------------------------------------
void reshape_stereo(CTX *ctx, int eye)
//-----------------------------------------------------------------------------
{
	float	ar;
	float	zoom;
	int		xs, ys, width, height;

	width = ctx->window.width / 2;
	height = ctx->window.height;
	if (!eye)
	{
		xs = ys = 0;
	}
	else
	{
		xs = width;
		ys = 0;
	}
	ar = (float)(width) / (float)height;

	glViewport(xs, 0, width, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	if (ctx->drawAdj.projection == GEOMETRY_PROJECTION_ORTHOGRAPHIC)
	{
		double	size = 1.045;
		double  zoom;
		//        left,  right,  bottom, top, nearVal, farVal
		zoom = -ctx->trans[2] * 0.25 + 1;
		glOrtho(-size*ar*zoom, size*ar*zoom, -size*zoom, size*zoom, -100.00f, 100.0f);
	}
	else if (ctx->drawAdj.projection == GEOMETRY_PROJECTION_PERPSECTIVE)
	{
		float	f,
			zn,
			zf;
		GLfloat	m[16];

		// projective
		f = (float)(1.0 / tan(DTR(15.0)));
		zn = 0.001f;
		zf = 100.0f;

		m[0] = f / ar;
		m[1] = 0.0f;
		m[2] = 0.0f;
		m[3] = 0.0f;

		m[4] = 0.0f;
		m[5] = f;
		m[6] = 0.0f;
		m[7] = 0.0f;

		m[8] = 0.0f;
		m[9] = 0.0f;
		m[10] = (zf + zn) / (zn - zf);
		m[11] = -1.0f;

		m[12] = 0.0f;
		m[13] = 0.0f;
		m[14] = (2.0f * zf * zn) / (zn - zf);
		m[15] = 0.0f; // 0.0f;

		glLoadMatrixf(m);
	}
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glTranslatef(0.f, 0.f, -4.0f);
	{
		MTX_MATRIX	mry, mm;
		double		angle = ctx->drawAdj.stereoCrossEyeFlag ? ctx->drawAdj.eyeSeparation : -ctx->drawAdj.eyeSeparation;
//		double		rotation = !eye ? -ctx->drawAdj.eyeSeparation : ctx->drawAdj.eyeSeparation;
		double		rotation = !eye ? -angle : angle;

		mtx_create_rotation_matrix(&mry, MTX_ROTATE_Y_AXIS, DTR(rotation));
		mtx_multiply_matrix(&ctx->matrix, &mry, &mm);
		ctx->matrix = mm;
	}
}
//-----------------------------------------------------------------------------------
void display(CTX *ctx)
//-----------------------------------------------------------------------------------
{	
	int	stereo = 1;

	if (ctx->drawAdj.stereoFlag)
	{
		MTX_MATRIX	copy = ctx->matrix;
		reshape_stereo(ctx, 0);
		display_original(ctx, 0, 1);
		ctx->matrix = copy;
		reshape_stereo(ctx, 1);
		display_original(ctx, 1, 0);
		ctx->matrix = copy;
	}
	else
	{
//		reshape(ctx->mainWindow, ctx->window.width, ctx->window.height);
		display_original(ctx, 1, 1);
	}
}

//-----------------------------------------------------------------------------------
void display_original ( CTX *ctx, int swap, int clear )
//-----------------------------------------------------------------------------------
{
	static GLfloat mat_specular[4] = { (float)0.0, (float)0.5, (float)1.0, (float)1.0 };
	static GLfloat mat_shininess = 50.0;
	static GLfloat light_position[4];// = { (float)0.5, (float)0.5, (float)2.0, (float)0.0 };
	static GLfloat light_ambient[4] = { (float)0.1, (float)0.1, (float)0.1, (float)1.0 };
	static GLfloat light_diffuse[4] = { (float)0.3, (float)0.3, (float)0.3, (float)1.0 };
	static GLfloat light_specular[4] = { (float)0.0, (float)0.0, (float)0.0, (float)1.0 };
	static GLdouble eqn[4] = { 0.0, 1.0, 0.0, 0.0 };
	static GLdouble eqn2[4] = { 1.0, 0.0, 0.0, 0.0 };
	static MTX_VECTOR clip_in = { 0.0, 0.0, 1.0, 0.0 }, clip_out;
	static GLfloat	density = 0.9;
	static GLfloat fogStart = 4.0, fogEnd = 4.5;
	static GLfloat fogColor[4];
	static GLfloat fogStartCoord[4] = { 0.0,0.0,0.0,1.0 };
	static GUT_POINT		pt;
	static GUT_PLANE		pl;
	static GUT_VECTOR		n;

	glShadeModel(GL_SMOOTH);          // Use Smooth shading ( This is the Default so we dont actually have to set it) 
	if (ctx->drawAdj.fogFlag)//global_fog)
	{
		fogColor[0] = ctx->clrCtl.bkgClear.r * 0.90;
		fogColor[1] = ctx->clrCtl.bkgClear.g * 0.90;
		fogColor[2] = ctx->clrCtl.bkgClear.b * 0.90;
		fogColor[3] = 1.0;
		glEnable(GL_FOG);
		glFogi(GL_FOG_MODE, GL_LINEAR);// GL_EXP2); // GL_LINEAR);
		glFogfv(GL_FOG_COLOR, fogColor);
		glFogf(GL_FOG_DENSITY, density);
		// transform the start and end points of fog

		fogStart = 4.0 - ctx->trans[2];
		fogEnd = 4.5 - ctx->trans[2];
		glFogf(GL_FOG_START, fogStart);
		glFogf(GL_FOG_END, fogEnd);
		glHint(GL_FOG_HINT, GL_NICEST);
	}
	else
	{
		glDisable(GL_FOG);
	}

	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_SHININESS, &mat_shininess);
	glDisable(GL_LIGHTING);
	if (ctx->clrCtl.useLightingFlag)
	{
		glEnable(GL_LIGHTING);
		light_position[0] = ctx->clrCtl.light.x;
		light_position[1] = ctx->clrCtl.light.y;
		light_position[2] = ctx->clrCtl.light.z;
		light_position[3] = 0; // ctx->clrCtl.light.w;
		glLightfv(GL_LIGHT0, GL_POSITION, light_position);
		glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
		glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
		glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
		glEnable(GL_LIGHT0);
	}

	glColorMaterial(GL_FRONT, GL_DIFFUSE);
	glEnable(GL_COLOR_MATERIAL);
	glDepthFunc(GL_LESS);
	glEnable(GL_DEPTH_TEST);

	if (ctx->drawAdj.clipFlag) //->clip.active )
	{
		pt.x = 0;
		pt.y = 0;
		pt.z = ctx->drawAdj.clipZValue; // ctx->clip.z_value;
		n.i = 0;
		n.j = 0;
		n.k = 1;
		n.l = 1;
		gut_plane_from_point_normal(&pt, &n, &pl);

		glEnable(GL_CLIP_PLANE0);
		clip_in.data.ijkl[0] = pl.A;
		clip_in.data.ijkl[1] = pl.B;
		clip_in.data.ijkl[2] = pl.C;
		clip_in.data.ijkl[3] = pl.D;
		glPushMatrix();
		glTranslatef(ctx->trans[0], ctx->trans[1], ctx->trans[2]);
		{
			glMatrixMode(GL_MODELVIEW);
			glMultMatrixd((double*)&ctx->matrix);
			glClipPlane(GL_CLIP_PLANE0, (const double*)&clip_in);
		}
		glPopMatrix();
	}
	else
	{
		glDisable(GL_CLIP_PLANE0);
	}

	glDisable(GL_LINE_SMOOTH);
	glDisable(GL_BLEND);

	if (clear)
	{
		//	glClearColor((float)ctx->clear.r, (float)ctx->clear.g, (float)ctx->clear.b, (float)0.0);
		glClearColor((float)ctx->clrCtl.bkgClear.r, (float)ctx->clrCtl.bkgClear.g, (float)ctx->clrCtl.bkgClear.b, (float)0.0);

		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	}

//	glEnable(GL_ALPHA_TEST);
//	glEnable(GL_BLEND);
//	glDepthMask(GL_FALSE);
//	glBlendFunc(GL_SRC_ALPHA, GL_ONE);

	glPushMatrix();
	glTranslatef(ctx->trans[0], ctx->trans[1], ctx->trans[2]);
	{
		glMatrixMode(GL_MODELVIEW);
		glMultMatrixd((double*)&ctx->matrix);
	}

	//--------------------------------------------------------------------
	glDisable(GL_ALPHA_TEST);

	glColor3f(1.0f, 0.0f, 0.0f);

	switch (ctx->geomAdj.polymode[0]) {
	case GEOMETRY_POLYMODE_FILL:   glPolygonMode(GL_FRONT, GL_FILL); break;
	case GEOMETRY_POLYMODE_LINE:   glPolygonMode(GL_FRONT, GL_LINE); break;
	case GEOMETRY_POLYMODE_POINT:  glPolygonMode(GL_FRONT, GL_POINT); break;
	default: glPolygonMode(GL_FRONT, GL_FILL);
	}

	switch (ctx->geomAdj.polymode[1]) {
	case GEOMETRY_POLYMODE_FILL:  glPolygonMode(GL_BACK, GL_FILL); break;
	case GEOMETRY_POLYMODE_LINE:  glPolygonMode(GL_BACK, GL_LINE); break;
	case GEOMETRY_POLYMODE_POINT: glPolygonMode(GL_BACK, GL_POINT); break;
	default: glPolygonMode(GL_FRONT, GL_FILL);
	}

//	draw_geometry_new(ctx);
	draw_geometry_poly(ctx);

	//--------------------------------------------------------------------

	//	glViewport(0, 0, ctx->window_width, ctx->window_height);
	glPopMatrix();
	glFlush();
//	SwapBuffers(ctx->hDC);			/* nop if singlebuffered */
	if (swap)
	{
//		glFlush();
		SwapBuffers(ctx->hDC);			/* nop if singlebuffered */
	}
}

//-----------------------------------------------------------------------------
int draw_circle_segment(GUT_POINT *a, GUT_POINT *b, GUT_POINT *c, GUT_VECTOR *n, COLOR *clr)
//-----------------------------------------------------------------------------
{
	// determine if a,b, or c is not on the sphere
	double		distance[3];
	GUT_POINT	*p[3];

	gut_distance_from_point_to_origin(a, &distance[0]);
	gut_distance_from_point_to_origin(b, &distance[1]);
	gut_distance_from_point_to_origin(c, &distance[2]);

	if (fabs(distance[0] - 1.0) > 0.00001)
	{
		p[0] = a;
		p[1] = b;
		p[2] = c;
	}
	else if (fabs(distance[1] - 1.0) > 0.00001)
	{
		p[0] = b;
		p[1] = c;
		p[2] = a;
	}
	else if (fabs(distance[2] - 1.0) > 0.00001)
	{
		p[0] = c;
		p[1] = a;
		p[2] = b;
	}
	else
	{
		return 1;
	}

	{
		GUT_VECTOR	v[2];
		double		angle,
			t,
			tInc;
		GUT_POINT	d,
			e;
		int			i,
			nInc;

		gut_vector(p[0], p[1], &v[0]);
		gut_vector(p[0], p[2], &v[1]);

		gut_normalize_vector(&v[0]);
		gut_normalize_vector(&v[1]);

		gut_dot_product(&v[1], &v[0], &angle);

		angle = acos(angle);

		t = angle / DTR(10.0);
		//		nInc = angle / DTR( 10.0 );
		if (t < 1.0)
			nInc = 1;
		else if (t < 2.0)
			nInc = 2;
		else
			nInc = t;

		tInc = 1.0 / nInc;

		gut_distance_from_point_to_point(p[0], p[1], &distance[0]);

		for (i = 0, d = *p[1], t = tInc; i<nInc; ++i, t += tInc)
		{
			gut_vector(p[0], &d, &v[0]);
			distance[1] = sqrt(v[0].i * v[0].i + v[0].j * v[0].j + v[0].k * v[0].k);
			distance[2] = distance[1] / distance[0];
			d.x = p[0]->x + v[0].i / distance[2];
			d.y = p[0]->y + v[0].j / distance[2];
			d.z = p[0]->z + v[0].k / distance[2];

			gut_parametric_point(p[1], p[2], &e, t);
			gut_vector(p[0], &e, &v[0]);
			distance[1] = sqrt(v[0].i * v[0].i + v[0].j * v[0].j + v[0].k * v[0].k);
			distance[2] = distance[1] / distance[0];
			e.x = p[0]->x + v[0].i / distance[2];
			e.y = p[0]->y + v[0].j / distance[2];
			e.z = p[0]->z + v[0].k / distance[2];
			glBegin(GL_TRIANGLES);
			glNormal3f((float)n->i * 3, (float)n->j * 3, (float)n->k * 3);
			glColor3f((float)clr->r, (float)clr->g, (float)clr->b);
			glVertex3f((float)p[0]->x, (float)p[0]->y, (float)p[0]->z);
			glVertex3f((float)d.x, (float)d.y, (float)d.z);
			glVertex3f((float)e.x, (float)e.y, (float)e.z);
			glEnd();
			d = e;
		}
	}

	return 0;
}

//-----------------------------------------------------------------------------------
void gut_plane_from_point_normal(GUT_POINT *pt, GUT_VECTOR *normal, GUT_PLANE *p)
//-----------------------------------------------------------------------------------
{
	GUT_VECTOR	v, pv;
	p->A = p->B = p->C = p->D = 0; // p // clear out the plane data
	gut_normalize_vector(normal);
	p->A = normal->i;
	p->B = normal->j;
	p->C = normal->k;
	double	d;
	pv.i = pt->x;
	pv.j = pt->y;
	pv.k = pt->z;
	pv.l = 0;
	gut_dot_product(&pv, normal, &d);

	p->D = -d;
}

//-----------------------------------------------------------------------------
void draw_triangle(CTX *ctx, GUT_POINT *a, GUT_POINT *b, GUT_POINT *c, COLOR *clr) //COLOR *ctbl, int id)
//-----------------------------------------------------------------------------
{
	static GUT_VECTOR	vab, vbc, normal;

	// determine face normal from cross product
	gut_vector(a, b, &vab);
	gut_vector(b, c, &vbc);
	gut_cross_product(&vab, &vbc, &normal);
	gut_normalize_point((GUT_POINT*)&normal);

	glNormal3f((float)normal.i * 3, (float)normal.j * 3, (float)normal.k * 3);
	glColor3f((float)clr->r, (float)clr->g, (float)clr->b);

	glVertex3f((float)a->x, (float)a->y, (float)a->z);
	glVertex3f((float)b->x, (float)b->y, (float)b->z);
	glVertex3f((float)c->x, (float)c->y, (float)c->z);
}

//-----------------------------------------------------------------------------
void draw_triangle_hex(CTX *ctx, GUT_POINT *p, GUT_VECTOR *n, COLOR *clr, int i, int j, int k, int nSeg )
//-----------------------------------------------------------------------------
{
	// determine face normal from cross product
	glColor3f((float)clr->r, (float)clr->g, (float)clr->b);
	glNormal3f((float)n[i % nSeg].i * 3, (float)n[i % nSeg].j * 3, (float)n[i % nSeg].k * 3);
	glVertex3f((float)p[i].x, (float)p[i].y, (float)p[i].z);
	glNormal3f((float)n[j % nSeg].i * 3, (float)n[j % nSeg].j * 3, (float)n[j % nSeg].k * 3);
	glVertex3f((float)p[j].x, (float)p[j].y, (float)p[j].z);
	glNormal3f((float)n[k % nSeg].i * 3, (float)n[k % nSeg].j * 3, (float)n[k % nSeg].k * 3);
	glVertex3f((float)p[k].x, (float)p[k].y, (float)p[k].z);
}

//-----------------------------------------------------------------------------
void draw_geometry_poly(CTX *ctx) //NEW VERSION
//-----------------------------------------------------------------------------
{
	static int			i, j, k, reverseOrder;
	static MTX_MATRIX	*mp;
	static MTX_VECTOR	*v;
	static GUT_POINT	p[32]; // pa, pb, pc;
	static GUT_VECTOR	vab, vbc, normal;
	static POLYHEDRON	*poly;
	static GEO_OBJECT	*gobj;
	static POLYGON		*tri;
	static COLOR		*clr;
	static EDGE			*edge;
//	static GUT_POINT	out[12]; // edge triangle points 
	static GUT_POINT	out[24]; // edge triangle points 
	static GUT_POINT	origin = { 0,0,0,1 };
	int					nSeg = 12;
	static GUT_VECTOR	edgeNormal[24];

	if (ctx->drawAdj.axiiFlag) gl_render_axii(ctx, p, out, &origin);

	LL_SetHead(ctx->gobjectq);
	while (gobj = (GEO_OBJECT*)LL_GetNext(ctx->gobjectq))
	{
		if (!gobj->active) continue;

		if (!gobj->v_out) gobj->v_out = malloc(sizeof(MTX_VECTOR) * gobj->nVtx); // alocate memory once 

		geometry_draw_init(ctx,gobj); // initialize transformations unque to each object
		while (geometry_next_draw_transform(ctx, gobj, &mp, &reverseOrder, ctx->geomAdj.orientation))
		{
			mtx_vector_multiply(gobj->nVtx, (MTX_VECTOR*)gobj->vtx, gobj->v_out, mp); // transform the vertices once

			if (gobj->nTri && (gobj->drawWhat & GEOMETRY_DRAW_FACES)) // faces
			{
				tri = gobj->tri;

				for (i = 0, v = gobj->v_out; i < gobj->nTri; ++i, ++tri)
				{
					switch (gobj->cAttr.face.state) {
					case COLOR_STATE_EXPLICIT: clr = &tri->color; break;
					case COLOR_STATE_AUTOMATIC: ctbl_get_color(gobj->ctT, tri->id, &clr);  break;
					case COLOR_STATE_OVERRIDE: clr = &gobj->cAttr.face.color; break;// &ctx->clrCtl.triangle.override; break;
					}

					switch (tri->nVtx) {
					case 1: // degenerate vertices
						double		scale;
						if (ctx->eAttr.maxLength > 0.0)		scale = gobj->vAttr.scale * ctx->eAttr.maxLength;
						else								scale = gobj->vAttr.scale;
						gl_render_vertex(ctx, &v[tri->vtx[0]], ctx->renderVertex.vtxObj->vtx, ctx->renderVertex.vtxObj->v_out, ctx->renderVertex.vtxObj->tri, ctx->renderVertex.vtxObj->nVtx, ctx->renderVertex.vtxObj->nTri, scale, clr);
						break;
					case 2: // degenerate edges
						gl_render_edge(ctx, gobj, (GUT_POINT*)&v[tri->vtx[0]].data.xyzw[0], (GUT_POINT*)&v[tri->vtx[1]].data.xyzw[0], p, &origin, out, edgeNormal, clr,
							ctx->drawAdj.quality->edgeNSeg);
						break;
					default: // normal polygon faces
						if (!reverseOrder) // copy vertex data to new variables
							for (j = 0; j<tri->nVtx; ++j) p[j] = *(GUT_POINT*)&v[tri->vtx[j]].data.xyzw[0];
						else
							for (k = 0, j = tri->nVtx - 1; j >= 0; --j, ++k) p[k] = *(GUT_POINT*)&v[tri->vtx[j]].data.xyzw[0];

						// check for special flag to re-normalize
						if (ctx->drawAdj.normalizeFlag)//if (ctx->global_normalize)
							for (j = 0; j < tri->nVtx; ++j) gut_normalize_point(&p[j]);

						// determine face normal from cross product
						gut_vector(&p[0], &p[1], &vab);
						gut_vector(&p[1], &p[2], &vbc);
						gut_cross_product(&vab, &vbc, &normal);
						gut_normalize_point((GUT_POINT*)&normal);

						if (tri->nVtx == 3 && ctx->drawAdj.circleFlag)
						{
							//							glBegin(GL_TRIANGLES);
							draw_circle_segment(&p[0], &p[1], &p[2], &normal, clr);
							//							glEnd();
						}
						else
						{
							glBegin(GL_TRIANGLES);
							for (j = 0; j < tri->nVtx; ++j)
							{
								if (j >= 2)
								{
									// determine face normal from cross product
									gut_vector(&p[0], &p[j - 1], &vab);
									gut_vector(&p[j - 1], &p[j], &vbc);
									gut_cross_product(&vab, &vbc, &normal);
									gut_normalize_point((GUT_POINT*)&normal);
									glNormal3f((float)normal.i * 3, (float)normal.j * 3, (float)normal.k * 3);
									glColor3f((float)clr->r, (float)clr->g, (float)clr->b);
									glVertex3f((float)p[0].x, (float)p[0].y, (float)p[0].z);
									glVertex3f((float)p[j - 1].x, (float)p[j - 1].y, (float)p[j - 1].z);
									glVertex3f((float)p[j].x, (float)p[j].y, (float)p[j].z);
								}
							}
							glEnd();
						}
					}
				}
			}

			if (gobj->nEdge && (gobj->drawWhat & GEOMETRY_DRAW_EDGES))//0x2)) //ctx->tri_edge_mode == 1 || ctx->tri_edge_mode == 2))
			{
				for (i = 0, v = gobj->v_out, edge = gobj->edge; i < gobj->nEdge; ++i, ++edge)
				{
					switch (gobj->cAttr.edge.state) {
					case COLOR_STATE_EXPLICIT: clr = &tri->color; break;
					case COLOR_STATE_AUTOMATIC: ctbl_get_color(gobj->ctE, edge->id, &clr);  break;
					case COLOR_STATE_OVERRIDE: clr = &gobj->cAttr.edge.color; break;// &ctx->clrCtl.triangle.override; break;
					}

					gl_render_edge(ctx, gobj, (GUT_POINT*)&v[edge->vtx[0]].data.xyzw, (GUT_POINT*)&v[edge->vtx[1]].data.xyzw, p, &origin, out,edgeNormal, clr, 
						ctx->drawAdj.quality->edgeNSeg);
				}
			}

			if (gobj->drawWhat & GEOMETRY_DRAW_VERTICES)//0x4) // render vertices if required
			{
				double		scale;

				clr = &gobj->cAttr.vertex.color;// ctx->renderVertex.clr;

				if (ctx->eAttr.maxLength > 0.0)	scale = gobj->vAttr.scale * ctx->eAttr.maxLength; // 0.03;
				else								scale = gobj->vAttr.scale; // 0.03;

				for (i = 0, v = gobj->v_out; i < gobj->nVtx; ++i, ++tri, ++v)
				{
					gl_render_vertex(ctx, v, ctx->renderVertex.vtxObj->vtx, ctx->renderVertex.vtxObj->v_out, ctx->renderVertex.vtxObj->tri, ctx->renderVertex.vtxObj->nVtx, ctx->renderVertex.vtxObj->nTri, scale, clr);
				}
			}
		}
	}

	glBegin(GL_TRIANGLES);

	if (ctx->drawAdj.clipFlag && ctx->drawAdj.clipVisibleFlag)
	{
		glNormal3f((float)0, (float)0, (float)3);

		glColor3f((float)1, (float)1, (float)0);
		glVertex3f((float)1.05, (float)-1.05, (float)ctx->drawAdj.clipZValue);
		glVertex3f((float)1.05, (float)1.05, (float)ctx->drawAdj.clipZValue);
		glVertex3f((float)-1.05, (float)1.05, (float)ctx->drawAdj.clipZValue);

		glVertex3f((float)-1.05, (float)1.05, (float)ctx->drawAdj.clipZValue);
		glVertex3f((float)-1.05, (float)-1.05, (float)ctx->drawAdj.clipZValue);
		glVertex3f((float)1.05, (float)-1.05, (float)ctx->drawAdj.clipZValue);
	}

	glEnd();
}

//-----------------------------------------------------------------------------
int gl_render_vertex(CTX *ctx, VERTEX *vtx, VERTEX *vs, VERTEX *vd, VTRIANGLE	*vt, int nVtx, int nTri, double scale, COLOR *clr)
//-----------------------------------------------------------------------------
{
	// RENDER A SINGLE VERTEX WITH THE SPECIFIED COLOR
	int					j;
//	static VTRIANGLE	*vt;
	static VERTEX		v;
//	int					nTri;

	v = *vtx;

	// check for special flag to re-normalize
	if (ctx->drawAdj.normalizeFlag)
		gut_normalize_point(&v);

	// modify vertex object coordinates to be at this global position
	for (j = 0; j < nVtx; ++j) //ctx->renderVertex.vtxObj.nVtx; ++j)
	{
		vd[j].x = vs[j].x * scale + v.x;
		vd[j].y = vs[j].y * scale + v.y;
		vd[j].z = vs[j].z * scale + v.z;
		vd[j].w = 1;
	}
	// make OpenGL calls
	glBegin(GL_TRIANGLES);
//	for (j = 0, vt = ctx->renderVertex.vtxObj.tri; j < ctx->renderVertex.vtxObj.nTri; ++j, ++vt)
	for (j = 0; j < nTri; ++j, ++vt)
	{
		glNormal3f((float)vs[vt->vtx[0]].x * 3, (float)vs[vt->vtx[0]].y * 3, (float)vs[vt->vtx[0]].z * 3);
		glColor3f((float)clr->r, (float)clr->g, (float)clr->b);
		glVertex3f((float)vd[vt->vtx[0]].x, (float)vd[vt->vtx[0]].y, (float)vd[vt->vtx[0]].z);// ++v;

		glNormal3f((float)vs[vt->vtx[1]].x * 3, (float)vs[vt->vtx[1]].y * 3, (float)vs[vt->vtx[1]].z * 3);
		glColor3f((float)clr->r, (float)clr->g, (float)clr->b);
		glVertex3f((float)vd[vt->vtx[1]].x, (float)vd[vt->vtx[1]].y, (float)vd[vt->vtx[1]].z);// ++v;

		glNormal3f((float)vs[vt->vtx[2]].x * 3, (float)vs[vt->vtx[2]].y * 3, (float)vs[vt->vtx[2]].z * 3);
		glColor3f((float)clr->r, (float)clr->g, (float)clr->b);
		glVertex3f((float)vd[vt->vtx[2]].x, (float)vd[vt->vtx[2]].y, (float)vd[vt->vtx[2]].z);// ++v;
	}
	glEnd();
}

//-----------------------------------------------------------------------------
int gl_render_edge(CTX *ctx, GEO_OBJECT *gobj, VERTEX *va, VERTEX *vb, VERTEX *p, VERTEX *origin, VERTEX *out, GUT_VECTOR *normal, COLOR *clr, int nSeg)
//-----------------------------------------------------------------------------
{
//	static GUT_VECTOR	normal[6];
//	GUT_VECTOR	normal[6];
	glBegin(GL_TRIANGLES);
	// copy vertex data to new variables
	p[0] = *va;
	p[1] = *vb;
	// check for special flag to re-normalize
	if (ctx->drawAdj.normalizeFlag)//if (ctx->global_normalize)
	{
		gut_normalize_point(&p[0]);
		gut_normalize_point(&p[1]);
	}

	if (gobj->eAttr.type == GEOMETRY_EDGE_SQUARE)
	{
		geo_edge_to_triangles(ctx, &gobj->eAttr, &p[0], &p[1], out, ctx->drawAdj.normalizeFlag, origin);

		draw_triangle(ctx, &out[0], &out[1], &out[2], clr); //gobj->clrE, edge->id);
		draw_triangle(ctx, &out[2], &out[3], &out[0], clr); //gobj->clrE, edge->id);
		draw_triangle(ctx, &out[0], &out[1], &out[2], clr); //gobj->clrE, edge->id);
		draw_triangle(ctx, &out[2], &out[3], &out[0], clr); //gobj->clrE, edge->id);
		if (ctx->eAttr.height != 0.0)
		{
			draw_triangle(ctx, &out[0], &out[4], &out[5], clr); //, gobj->clrE, edge->id);
			draw_triangle(ctx, &out[5], &out[1], &out[0], clr); //, gobj->clrE, edge->id);
			draw_triangle(ctx, &out[2], &out[6], &out[7], clr); //, gobj->clrE, edge->id);
			draw_triangle(ctx, &out[7], &out[3], &out[2], clr); //, gobj->clrE, edge->id);
		}
	}
	else
	{
		static int i, j;
		geo_edge_to_triangles_hex(ctx, &gobj->eAttr, &p[0], &p[1], out+0, out+nSeg, normal, ctx->drawAdj.normalizeFlag, origin, nSeg);

		for (i = 0, j=nSeg; i < nSeg; ++i, ++j)
		{
			draw_triangle_hex(ctx, out, normal, clr, i, j, (j + 1) % nSeg + nSeg, nSeg);
			draw_triangle_hex(ctx, out, normal, clr, (j + 1) % nSeg + nSeg, (i + 1) % nSeg, i, nSeg);
		}
	}
	glEnd();
}

//-----------------------------------------------------------------------------
int gl_render_axii(CTX *ctx, VERTEX *p, VERTEX *out, VERTEX *origin )
//-----------------------------------------------------------------------------
{
	double	width = ctx->eAttr.width;
	static COLOR		red = { 1,0,0 }, grn = { 0,1,0 }, blu = { 0,0,1 };
	static GUT_VECTOR	normal[6], x = { 1,0,0 }, y = { 0, 1, 0 }, z = { 0,0,1 };
	static COLOR		*clr;
	glBegin(GL_TRIANGLES);
	// copy vertex data to new variables
	ctx->eAttr.width = 0.01;
	p[0].x = -1.05; p[0].y = 0; p[0].z = 0; p[1].x = 1.05; p[1].y = 0; p[1].z = 0;
	clr = &red;
	x.i *= -1.0;
	geo_edge_to_triangles_hex_axii(&ctx->eAttr, &p[0], &p[1], out, &y, &x, &z, normal, ctx->drawAdj.normalizeFlag, &origin);
	draw_triangle_hex(ctx, out, &normal, clr,  0,  6,  7, 6 );
	draw_triangle_hex(ctx, out, &normal, clr,  7,  1,  0, 6 );
	draw_triangle_hex(ctx, out, &normal, clr,  1,  7,  8, 6 );
	draw_triangle_hex(ctx, out, &normal, clr,  8,  2,  1, 6 );
	draw_triangle_hex(ctx, out, &normal, clr,  2,  8,  9, 6 );
	draw_triangle_hex(ctx, out, &normal, clr,  9,  3,  2, 6 );
	draw_triangle_hex(ctx, out, &normal, clr,  3,  9, 10, 6 );
	draw_triangle_hex(ctx, out, &normal, clr, 10,  4,  3, 6 );
	draw_triangle_hex(ctx, out, &normal, clr,  4, 10, 11, 6 );
	draw_triangle_hex(ctx, out, &normal, clr, 11,  5,  4, 6 );
	draw_triangle_hex(ctx, out, &normal, clr,  5, 11,  6, 6 );
	draw_triangle_hex(ctx, out, &normal, clr,  6,  0,  5, 6 );
	x.i *= -1.0;
	p[0].x = 0; p[0].y = -1.05; p[0].z = 0; p[1].x = 0; p[1].y = 1.05; p[1].z = 0;
	clr = &grn;
	geo_edge_to_triangles_hex_axii(&ctx->eAttr, &p[0], &p[1], out, &x, &y, &z, normal, ctx->drawAdj.normalizeFlag, &origin);
	draw_triangle_hex(ctx, out, &normal, clr, 0, 6, 7, 6);
	draw_triangle_hex(ctx, out, &normal, clr, 7, 1, 0, 6);
	draw_triangle_hex(ctx, out, &normal, clr, 1, 7, 8, 6);
	draw_triangle_hex(ctx, out, &normal, clr, 8, 2, 1, 6);
	draw_triangle_hex(ctx, out, &normal, clr, 2, 8, 9, 6);
	draw_triangle_hex(ctx, out, &normal, clr, 9, 3, 2, 6);
	draw_triangle_hex(ctx, out, &normal, clr, 3, 9, 10, 6);
	draw_triangle_hex(ctx, out, &normal, clr, 10, 4, 3, 6);
	draw_triangle_hex(ctx, out, &normal, clr, 4, 10, 11, 6);
	draw_triangle_hex(ctx, out, &normal, clr, 11, 5, 4, 6);
	draw_triangle_hex(ctx, out, &normal, clr, 5, 11, 6, 6);
	draw_triangle_hex(ctx, out, &normal, clr, 6, 0, 5, 6);
	p[0].x = 0; p[0].y = 0; p[0].z = -1.05; p[1].x = 0; p[1].y = 0; p[1].z = 1.05;
	clr = &blu;
	geo_edge_to_triangles_hex_axii(&ctx->eAttr, &p[0], &p[1], out, &y, &z, &x, normal, ctx->drawAdj.normalizeFlag, &origin);
	draw_triangle_hex(ctx, out, &normal, clr, 0, 6, 7, 6);
	draw_triangle_hex(ctx, out, &normal, clr, 7, 1, 0, 6);
	draw_triangle_hex(ctx, out, &normal, clr, 1, 7, 8, 6);
	draw_triangle_hex(ctx, out, &normal, clr, 8, 2, 1, 6);
	draw_triangle_hex(ctx, out, &normal, clr, 2, 8, 9, 6);
	draw_triangle_hex(ctx, out, &normal, clr, 9, 3, 2, 6);
	draw_triangle_hex(ctx, out, &normal, clr, 3, 9, 10, 6);
	draw_triangle_hex(ctx, out, &normal, clr, 10, 4, 3, 6);
	draw_triangle_hex(ctx, out, &normal, clr, 4, 10, 11, 6);
	draw_triangle_hex(ctx, out, &normal, clr, 11, 5, 4, 6);
	draw_triangle_hex(ctx, out, &normal, clr, 5, 11, 6, 6);
	draw_triangle_hex(ctx, out, &normal, clr, 6, 0, 5, 6);
	ctx->eAttr.width = width;
	glEnd();
	return 0;
}
