#ifndef PAR_HEADER
#define PAR_HEADER

int par_lexeme ( char *pcString, char **pcArray, int nMaxSize );

#endif