
#ifndef DISP_SPH_HEADER
#define DISP_SPH_HEADER

#include "ds_color.h"

enum { 
    PAN = 1,			/* pan state bit */
    ROTATE,				/* rotate state bits */
	ROTATE_Z=4,
    ZOOM				/* zoom state bit */
};

typedef struct {
		int			visible,
					active;
		float		z_value,
					z_increment;
} CLIP;

typedef struct {
		int			start_x,
					start_y,
					width,
					height;
		int			toolsVisible;
} WINDOW_DATA;

typedef struct {
	int			front;
	int			back;
} POLYMODE;

typedef struct {
	double	x,
			y,
			z,
			w;
} VERTEX;

typedef struct {
	COLOR	color;
	VERTEX	vertex[3];
} SPHERE_DATA;

#define PROGRAM_VERSION					"0.93" 

#define GEOMETRY_ICOSAHEDRON			1
#define GEOMETRY_OCTAHEDRON				2
#define GEOMETRY_TETRAHEDRON			3
#define GEOMETRY_CUBEHEDRON				4

#define GEOMETRY_ORIENTATION_FACE		2
#define GEOMETRY_ORIENTATION_EDGE		1
#define GEOMETRY_ORIENTATION_VERTEX		0

#define WINDOW_SIZE_OFFSET_WIDTH		16	// add these numbers to window size to ensure canvas is the requested size
#define WINDOW_SIZE_OFFSET_HEIGHT		59

#define GEOMETRY_DRAW_NONE				0
#define GEOMETRY_DRAW_FACES				1
#define GEOMETRY_DRAW_TRIANGLES			1
#define GEOMETRY_DRAW_EDGES				2
#define GEOMETRY_DRAW_VERTICES			4
#define GEOMETRY_DRAW_ALL				7
#define GEOMETRY_DRAW_BOTH				7

#define GEOMETRY_EDGE_SQUARE			2
#define GEOMETRY_EDGE_ROUND				1

#define GEOMETRY_REPLICATE_ONCE			1
#define GEOMETRY_REPLICATE_MULTIPLE		0

#define GEOMETRY_POLYMODE_FILL			0
#define GEOMETRY_POLYMODE_LINE			1
#define GEOMETRY_POLYMODE_POINT			2

#define COLOR_STATE_EXPLICIT			1
#define COLOR_STATE_AUTOMATIC			2
#define COLOR_STATE_OVERRIDE			4	

#define GEOMETRY_PROJECTION_ORTHOGRAPHIC	1
#define GEOMETRY_PROJECTION_PERPSECTIVE		0

#define MAX_NUM_INPUT_FILES				8

#define COLOR_FORMAT_ZERO_TO_ONE		1
#define COLOR_FORMAT_255				2

typedef struct {
	int		axis;
	double	angle;
} ROT_PAIR;

typedef struct {
	int			n_rotations;
	ROT_PAIR	*pair;
	MTX_MATRIX	matrix;
	int			initialized;
	int			orientation;
} ROT_SET;

typedef struct {
	ROT_SET		*set;
	int			n_faces;
} POLYHEDRON;

typedef POLYHEDRON ICOSAHEDRON;
typedef POLYHEDRON OCTAHEDRON;
typedef POLYHEDRON TETRAHEDRON;
typedef POLYHEDRON CUBEHEDRON;

typedef struct {
	int			type,
				n_transforms_override;
	POLYHEDRON	*icosa,
				*octa,
				*tetra,
				*cube;
} BASE_GEOMETRY;

typedef struct {
	int				nFaces;
	MTX_MATRIX		*face; // transformation matrix - unique to each face
	MTX_MATRIX		mirror;	// mirror matrix - unique to each polyhedron
	MTX_MATRIX		edge;
	MTX_MATRIX		vertex;
	MTX_MATRIX		zrotation;
	int				nZRot;
} POLYHEDRON_NEW;

typedef struct {
	int				type;
	int				mirrorFlag;			// apply mirroring flag
	int				mirrorRoll;			// current mirror status
	int				zRotFlag;			// apply z rotation flag
	int				zRoll;				// used to control the number of z rotations to apply
	int				faceRoll;			// used to control how often to change the curFaceIndex
	int				nZRot;				// max number of Z rotations per face (3 or 4)
	int				oneFaceFlag;		// only transform one polyhedron face
	int				curFaceIndex;		// current face index
	int				curPolyIndex;		// current polyhedron index (0,1,2,3)
	int				curTransformIndex;	// current transform
//	MTX_MATRIX		zRotationMatrix;	// rotation matrix for any polyhedron
	int				maxFaceIndex;		// max number of faces to transform
	int				maxNTransforms;		// total number of transformations to apply
	POLYHEDRON_NEW	*poly;
	POLYHEDRON_NEW	*curPoly;
	MTX_STACK		*stack;
} BASE_GEOMETRY_NEW;

typedef struct {
		VERTEX	vertex[3];
		COLOR	color;
} VTX_CLR;

typedef struct {
	char		basename[256];
	int			singleFlag,
				nFrames,
				curFrame,
				backgroundFlag;
	double		lineWidth;
} CAPTURE;

typedef struct {
	float		dx;
	float		dy;
	float		dz;
	float		timerMSec;
	int			spinState;
} SPIN;

typedef struct {	// Triangle specific
//	int		vtx[3]; // unique vertex IDs
	int		*vtx; // unique vertex IDs
	int		id;		// unique ID auto generated 
	int		nVtx;	// size of vertex array
	COLOR	color;	// explict color
} TRIANGLE;

typedef struct {	// General version 
	int		*vtx;	// unique vertex IDs
	int		id;		// unique ID auto generated 
	int		nVtx;	// size of vertex array
	COLOR	color;	// explict color
} POLYGON;

typedef struct {
	int		vtx[3]; // unique vertex IDs
} VTRIANGLE;

typedef struct {
	int		vtx[2]; // unique vertex IDs
	int		id;		// unique ID auto generated 
} EDGE;

typedef struct {
	int		type;		// GEOMETRY_EDGE_SQUARE/ROUND
	double	width,		// adjustment from radius position
			height,		// fraction of 1.0
			offset,		// fraction of 1.0
			minLength,	// minimum length of all edges
			maxLength;	// maximum length of all edges
} EDGE_ATTRIBUTES;

typedef struct {
	double				scale;
} VERTEX_ATTRIBUTES;

typedef struct {
	int				oneFaceFlag;
	int				zRotationFlag;
	int				xMirrorFlag;
} REPLICATION_ATTRIBUTES;

typedef struct {
	int				state;
	COLOR			color;
} COLOR_STATE;

typedef struct {
	COLOR_STATE		face;
	COLOR_STATE		edge;
	COLOR_STATE		vertex;
} COLOR_ATTRIBUTES;

typedef struct {
	int	polymode[2]; //0 - front, 1 - back
	int geometry; // icosa
	int orientation;
	int drawWhat;
	int replication; // number depends on geometry
} GEOMETRY_ADJUSTMENTS;

typedef struct {
	int		sphereFrequency;
	int		edgeNSeg;
} RENDER_QUALITY;

typedef struct {
	int				projection;
	int				stereoFlag;
	int				stereoCrossEyeFlag;
	int				normalizeFlag;
	int				circleFlag;
	int				fogFlag;
	int				axiiFlag;
	int				clipFlag;
	double			clipZIncrement;
	int				clipVisibleFlag;
	double			clipZValue;
	float			eyeSeparation;
	SPIN			spin;
	int				spinFlag;
	double			matrix[16];
	int				hiResFlag;
	RENDER_QUALITY	loRes;
	RENDER_QUALITY	hiRes;
	RENDER_QUALITY	*quality;
} DRAWING_ADJUSTMENTS;

typedef struct {
	char		directory[256];
	char		basename[64];
	int			index;
	int			nFrames;
	int			singleFlag;
} IMAGE_CAPTURE;

typedef struct {
	int			guaFlag,
				guaResultsFlag;
	VERTEX		zAxis, yAxis, xAxis; // x axis will be determined
	int			transformFlag,
				replicateFlag,
				mirrorFlag;
	int			centerAndScaleFlag;
	MTX_MATRIX	matrix[2]; // 0 - rotation for ZY, 1 - rotation for replication (120 degrees) 
} INPUT_TRANSFORMATION;

typedef struct {
	int			flag;			// override flag
	COLOR		override,		// geometry forced to this color if override flag set
				defaultColor;	// assigned to objects without explicit color
} COLOR_SET;

typedef struct {
	int				updateFlag;
	int				autoColor; // only applies to triangles
	int				forceWhat; // used at init with command line
	COLOR_SET		line,
					triangle;
	COLOR			bkgClear;
	int				useLightingFlag;
	int				reverseColorFlag;
	GUT_POINT		light;
	char			user_color_table[128];
} COLOR_CONTROL;

typedef struct {
	MTX_VECTOR			*v_out;		// temp space for coordinate data to be used for transformations
	VERTEX				*vtx;		// array of unique vertex coordinates
	VTRIANGLE			*tri;		// array of unique triangles
	int					nVtx,		// number of unique vertices in object
						nTri;		// number of unique triangles in object by vertex sets
} GEO_OBJECT_VERTEX;

typedef struct {
	double				scale;
	COLOR				clr;
	GEO_OBJECT_VERTEX	vtxObjLoRes;
	GEO_OBJECT_VERTEX	vtxObjHiRes;
	GEO_OBJECT_VERTEX	*vtxObj;
} RENDER_VERTEX;

typedef struct {
	int					samplesPerPixel;
	COLOR				clr;
} OPENGL;

typedef struct {
	int						active;
	char					*filename;	// saved to compare with updates
	int						drawWhat;	// what part of the object to draw F 1 E 2 V 4
	EDGE_ATTRIBUTES			eAttr;		// edge state for rendering
	VERTEX_ATTRIBUTES		vAttr;		// vertex scale
	COLOR_ATTRIBUTES		cAttr;		// face, edge, and vertex color control
	REPLICATION_ATTRIBUTES	rAttr;		// replication flags
} GEO_INPUT_OBJECT;

typedef struct {
	int						active;
	char					*filename;	// saved to compare with updates
	int						drawWhat;	// what part of the object to draw F 1 E 2 V 4
	EDGE_ATTRIBUTES			eAttr;		// edge state for rendering
	VERTEX_ATTRIBUTES		vAttr;		// vertex scale
	COLOR_ATTRIBUTES		cAttr;		// face, edge, and vertex color control
	REPLICATION_ATTRIBUTES	rAttr;		// replication flags

	MTX_VECTOR				*v_out;		// temp space for coordinate data to be used for transformations
	VERTEX					*vtx;		// array of unique vertex coordinates
	TRIANGLE				*tri;		// array of unique triangles/polygons
	EDGE					*edge;		// array of unique edges
//	EDGE_ATTRIBUTES			eAttr;		// edge attributes for display
	int						nVtx,		// number of unique vertices in object
							nTri,		// number of unique triangles in object by vertex sets
							nEdge,		// number of unique edges in object by vertex pairs
							nUTri,		// number of unique triangles by unique edge length sets
							nUEdge;		// number of unique edges by length
	int						*vIndex;	// array of all vertex indices for all faces/polygons
	COLOR_TABLE				*ctT,		// color table for triangles 
							*ctE,		// color table for edges
							*ctB;		// color table for edges & triangles 
} GEO_OBJECT;

typedef struct {
	WINDOW_DATA				window;
	char					*version;
	char					filename[512]; // used for color table

	char					curWorkingDir[512];
	int						matrixFlag;

	RENDER_VERTEX			renderVertex;

	int						gobjAddFlag; // allow objects to be added rather than be replaced

	BASE_GEOMETRY_NEW		base_geometry_new;
	LL						*gobjectq;
	LL						*inputObjq;
	float					trans[3];			/* current translation */
	float					rot[3];				/* current rotation */
	float					init_rot[3];
	MTX_MATRIX				matrix;

	COLOR_CONTROL			clrCtl;
	DRAWING_ADJUSTMENTS		drawAdj;
	GEOMETRY_ADJUSTMENTS	geomAdj;
	EDGE_ATTRIBUTES			eAttr;		// global edge attributes for display
	CAPTURE					png;		
	CAPTURE					svg;

	GEO_INPUT_OBJECT		defInputObj; // objDefault;// defaultObject;
	GEO_INPUT_OBJECT		*curInputObj;// defaultObject;

	INPUT_TRANSFORMATION	inputTrans; // modify vertex data when read in

	COLOR_TABLE_SET			cts;

	HWND					mainWindow;
	HWND					kbdToggle;
	HWND					attrControl;
	HWND					objInfo;
	HWND					objControl;

	HDC						hDC;				/* device context */
	HPALETTE				hPalette; // = 0;		/* custom palette (if needed) */
	HINSTANCE				hInstance; // = 0;
	OPENGL					opengl;

	HANDLE					handle_out;
	HANDLE					handle_in;
} CTX;

COLOR *clr_get_table(int nClr, int *mod);
void geo_edge_to_triangles_hex(CTX *ctx, EDGE_ATTRIBUTES *eattr, VERTEX *a, VERTEX *b, VERTEX *p, GUT_VECTOR *n, int normalize, GUT_POINT *origin);
void geo_edge_to_triangles(CTX *ctx, EDGE_ATTRIBUTES *eattr, VERTEX *a, VERTEX *b, VERTEX *out, int normalize, GUT_POINT *origin);
//void geo_edge_to_triangles_hex(EDGE_ATTRIBUTES *eattr, VERTEX *a, VERTEX *b, VERTEX *p, GUT_VECTOR *n, int normalize, GUT_POINT *origin);
LRESULT CALLBACK DlgKbdToggles(HWND hWndDlg, UINT Msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK DlgCommandLineOptions(HWND hWndDlg, UINT Msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK DlgAbout(HWND hWndDlg, UINT Msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK DlgAttributesFull(HWND hWndDlg, UINT Msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK DlgObjectInformation(HWND hWndDlg, UINT Msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK DlgObjectControl(HWND hWndDlg, UINT Msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK DlgObjectControl5(HWND hWndDlg, UINT Msg, WPARAM wParam, LPARAM lParam);

int GeneralColorDialog(HWND hOwnerWnd, CTX *ctx, COLOR *clr);
int command_line(CTX *ctx, int ac, char **av);
void disp_pre_init(CTX *ctx);
void disp_post_init(CTX *ctx); // , POLYHEDRON **list);

GEO_OBJECT *parse_file2(CTX *ctx, FILE *fp, char *filename);

void draw_geometry(CTX *ctx);
void draw_geometry_new(CTX *ctx);
void draw_geometry_poly(CTX *ctx);
HWND CreateOpenGLWindow2(CTX *ctx, char* title, int x, int y, int width, int height);
int CaptureAnImage(HWND hWnd);
int CaptureBMP(HWND hWnd);
void gut_plane_from_point_normal(GUT_POINT *pt, GUT_VECTOR *normal, GUT_PLANE *p);

void gut_point_on_line(GUT_POINT *a, GUT_POINT *b, double t, GUT_POINT *c);
void gut_scale_vector(GUT_VECTOR *a, double s, GUT_VECTOR *b);
void gut_add_vector(GUT_VECTOR *a, GUT_VECTOR *b, GUT_VECTOR *c);
void gut_reverse_vector(GUT_VECTOR *a);
void geo_scale_pt(VERTEX *a, VERTEX *b, double d);
int gut_point_plus_vector(GUT_POINT *a, GUT_VECTOR *v, GUT_POINT *b);
int geo_plane_from_points(GUT_POINT *a, GUT_POINT *b, GUT_POINT *c, GUT_PLANE *p);
int geo_normalize_plane(GUT_PLANE *p);
void geo_build_transform_matrix(CTX *ctx);

void setRenderQuality(CTX *ctx);

#endif