﻿/*
//-----------------------------------------------------------------------------
int CaptureAnImage(HWND hWnd)
//-----------------------------------------------------------------------------
{
	//	Captures a screenshot into a window and then saves it in a .bmp file.

	CaptureAnImageNew(hWnd);
	return 0;

	HDC		hdcWindow;
	HDC		hdcMemDC = NULL;
	HBITMAP	hbmWindow = NULL;
	BITMAP	bmpWindow;
	CTX		*ctx;
	char	outputFilename[256];

	ctx = (CTX*)GetWindowLong(hWnd, GWL_USERDATA);

	// Retrieve the handle to a display device context for the client area of the window. 
	hdcWindow = GetDC(hWnd);

	// Create a compatible DC which is used in a BitBlt from the window DC
	hdcMemDC = CreateCompatibleDC(hdcWindow);

	if (!hdcMemDC)
	{
		MessageBox(hWnd, L"CreateCompatibleDC has failed", L"Failed", MB_OK);
		goto done;
	}

	// Get the client area for size calculation
	RECT rcClient;
	GetClientRect(hWnd, &rcClient);

	// Create a compatible bitmap from the Window DC
	hbmWindow = CreateCompatibleBitmap(hdcWindow, rcClient.right - rcClient.left, rcClient.bottom - rcClient.top);

	if (!hbmWindow)
	{
		MessageBox(hWnd, L"CreateCompatibleBitmap Failed", L"Failed", MB_OK);
		goto done;
	}

	// Select the compatible bitmap into the compatible memory DC.
	SelectObject(hdcMemDC, hbmWindow);

	// Bit block transfer into our compatible memory DC.
	if (!BitBlt(hdcMemDC,
		0, 0,
		rcClient.right - rcClient.left, rcClient.bottom - rcClient.top,
		hdcWindow,
		0, 0,
		SRCCOPY))
	{
		MessageBox(hWnd, L"BitBlt has failed", L"Failed", MB_OK);
		goto done;
	}

	// Get the BITMAP from the HBITMAP
	GetObject(hbmWindow, sizeof(BITMAP), &bmpWindow);

	BITMAPFILEHEADER   bmfHeader;
	BITMAPINFOHEADER   bi;

	bi.biSize = sizeof(BITMAPINFOHEADER);
	bi.biWidth = bmpWindow.bmWidth;
	bi.biHeight = bmpWindow.bmHeight;
	bi.biPlanes = 1;
	bi.biBitCount = 32;
	bi.biCompression = BI_RGB;
	bi.biSizeImage = 0;
	bi.biXPelsPerMeter = 0;
	bi.biYPelsPerMeter = 0;
	bi.biClrUsed = 0;
	bi.biClrImportant = 0;

	DWORD dwBmpSize = ((bmpWindow.bmWidth * bi.biBitCount + 31) / 32) * 4 * bmpWindow.bmHeight;

	// Starting with 32-bit Windows, GlobalAlloc and LocalAlloc are implemented as wrapper functions that 
	// call HeapAlloc using a handle to the process's default heap. Therefore, GlobalAlloc and LocalAlloc 
	// have greater overhead than HeapAlloc.
	HANDLE hDIB = GlobalAlloc(GHND, dwBmpSize);
	char *lpbitmap = (char *)GlobalLock(hDIB);

	// Gets the "bits" from the bitmap and copies them into a buffer 
	// which is pointed to by lpbitmap.
	GetDIBits(hdcWindow, hbmWindow, 0,
		(UINT)bmpWindow.bmHeight,
		lpbitmap,
		(BITMAPINFO *)&bi, DIB_RGB_COLORS);

	// A file is created, this is where we will save the screen capture.
	sprintf(outputFilename, "%s%05d.bmp", ctx->imageCapture.basename, ctx->imageCapture.index++);
	HANDLE hFile = CreateFile(outputFilename, //"captureqwsx.bmp",
		GENERIC_WRITE,
		0,
		NULL,
		CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL, NULL);

	// Add the size of the headers to the size of the bitmap to get the total file size
	DWORD dwSizeofDIB = dwBmpSize + sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);

	//Offset to where the actual bitmap bits start.
	bmfHeader.bfOffBits = (DWORD)sizeof(BITMAPFILEHEADER) + (DWORD)sizeof(BITMAPINFOHEADER);

	//Size of the file
	bmfHeader.bfSize = dwSizeofDIB;

	//bfType must always be BM for Bitmaps
	bmfHeader.bfType = 0x4D42; //BM   

	DWORD dwBytesWritten = 0;
	WriteFile(hFile, (LPSTR)&bmfHeader, sizeof(BITMAPFILEHEADER), &dwBytesWritten, NULL);
	WriteFile(hFile, (LPSTR)&bi, sizeof(BITMAPINFOHEADER), &dwBytesWritten, NULL);
	WriteFile(hFile, (LPSTR)lpbitmap, dwBmpSize, &dwBytesWritten, NULL);

	//Unlock and Free the DIB from the heap
	GlobalUnlock(hDIB);
	GlobalFree(hDIB);

	//Close the handle for the file that was created
	CloseHandle(hFile);

done: //Clean up
	DeleteObject(hbmWindow);
	DeleteObject(hdcMemDC);
	ReleaseDC(hWnd, hdcWindow);

	//	CaptureAnImageConvert(hWnd);

	return 0;
}
*/

/*

//-----------------------------------------------------------------------------
int cmdLineOptions ( CTX *ctx, LPSTR lpszCmdLine )
//-----------------------------------------------------------------------------
{
	// decode command line options
	char	*p = (char*)lpszCmdLine;

	char	buffer[1024];
	char	*av[64];
	int		ac,
			nextAc;

	// make copy of the command line
	strncpy ( buffer, (char*)lpszCmdLine, 1024 );

	// parse the command string
	ac = par_lexeme ( buffer, av, 64 );
	nextAc = 0;

	command_line_new(ctx, ac, av); // NEED TO HANDLE ERRORS
	return 0;
	while (nextAc < ac)
	{
		if (!strcmp(av[nextAc], "-f")) // filename
		{
			if (++nextAc < ac)
			{
				strcpy(ctx->filename, av[nextAc++]);
			}
		}
		else if (!strcmp(av[nextAc], "-sx")) // window start x position
		{
			if (++nextAc < ac)
				ctx->window.start_x = atoi(av[nextAc++]);
		}
		else if (!strcmp(av[nextAc], "-sy")) // window start y position
		{
			if (++nextAc < ac)
				ctx->window.start_y = atoi(av[nextAc++]);
		}
		else if (!strcmp(av[nextAc], "-w")) // window width
		{
			if (++nextAc < ac)
				ctx->window.width = atoi(av[nextAc++]);
		}
		else if (!strcmp(av[nextAc], "-h")) // window height
		{
			if (++nextAc < ac)
				ctx->window.height = atoi(av[nextAc++]);
		}
		else if (!strcmp(av[nextAc], "-g")) // initial geometry
		{
			if (++nextAc < ac)
			{
				// default
				ctx->base_geometry.type = GEOMETRY_ICOSAHEDRON;
				if (!strncmp(av[nextAc], "i", 1))
					ctx->base_geometry.type = GEOMETRY_ICOSAHEDRON;
				else if (!strncmp(av[nextAc], "o", 1))
					ctx->base_geometry.type = GEOMETRY_OCTAHEDRON;
				else if (!strncmp(av[nextAc], "t", 1))
					ctx->base_geometry.type = GEOMETRY_TETRAHEDRON;
				else if (!strncmp(av[nextAc], "c", 1))
					ctx->base_geometry.type = GEOMETRY_CUBEHEDRON;
				ctx->file_type_override = 1;
				++nextAc;
			}
		}
		else if (!strcmp(av[nextAc], "-orientation")) // initial orientation
		{
			if (++nextAc < ac)
			{
				if (!strncmp(av[nextAc], "face", 1))
					ctx->geomAdj.orientation = GEOMETRY_ORIENTATION_FACE;
				else if (!strncmp(av[nextAc], "edge", 1))
					ctx->geomAdj.orientation = GEOMETRY_ORIENTATION_EDGE;
				else if (!strncmp(av[nextAc], "vertex", 1))
					ctx->geomAdj.orientation = GEOMETRY_ORIENTATION_VERTEX;

				++nextAc;
			}
		}
		else if (!strcmp(av[nextAc], "-capture")) // single frame capture option info
		{
			if ((nextAc + 1) < ac)
			{
				strcpy(ctx->capture.output_filename, av[++nextAc]);
				ctx->capture.nFrames = 1;
				ctx->capture.singleFlag = 1; // don't add index to name
				++nextAc;
			}
		}
		else if (!strcmp(av[nextAc], "-film")) // film (multiple frame) capture option info
		{
			if ((nextAc + 2) < ac)
			{
				strcpy(ctx->capture.output_filename, av[++nextAc]);
				ctx->capture.nFrames = atoi(av[++nextAc]);
				ctx->capture.singleFlag = 0; // add index to name
				++nextAc;
			}
		}
		else if (!strcmp(av[nextAc], "-normal")) // force vector/point normalization
		{
			// no arguments required
			ctx->drawAdj.normalizeFlag = 1;
			++nextAc;
		}
		else if (!strcmp(av[nextAc], "-front")) // set front facing draw mode
		{
			if (++nextAc < ac)
			{
				// point line fill
				if (!strncmp(av[nextAc], "point", 1))
					ctx->geomAdj.polymode[0] = GEOMETRY_POLYMODE_POINT;
				else if (!strncmp(av[nextAc], "line", 1))
					ctx->geomAdj.polymode[0] = GEOMETRY_POLYMODE_LINE;
				else if (!strncmp(av[nextAc], "fill", 1))
					ctx->geomAdj.polymode[0] = GEOMETRY_POLYMODE_FILL;

				++nextAc;
			}
		}
		else if (!strcmp(av[nextAc], "-back")) // set back facing draw mode
		{
			if (++nextAc < ac)
			{
				// point line fill
				if (!strncmp(av[nextAc], "point", 1))
					ctx->geomAdj.polymode[1] = GEOMETRY_POLYMODE_POINT;
				else if (!strncmp(av[nextAc], "line", 1))
					ctx->geomAdj.polymode[1] = GEOMETRY_POLYMODE_LINE;
				else if (!strncmp(av[nextAc], "fill", 1))
					ctx->geomAdj.polymode[1] = GEOMETRY_POLYMODE_FILL;

				++nextAc;
			}
		}
		else if (!strcmp(av[nextAc], "-unique_color")) // use auto unique triangle color settings
		{	// will be superceded by -override_color
			// no arguments required (0 is default)
			ctx->clrCtl.triangle.flag = 1;
			++nextAc;
		}
		else if (!strcmp(av[nextAc], "-override_color")) // // override color
		{
			if ((nextAc + 3) < ac)
			{
				// red green blue (0.0 - 1.0) range
				// default is black
				ctx->clrCtl.triangle.override.r = atof(av[++nextAc]);
				ctx->clrCtl.triangle.override.g = atof(av[++nextAc]);
				ctx->clrCtl.triangle.override.b = atof(av[++nextAc]);
				ctx->clrCtl.triangle.flag = 1;
				++nextAc;
			}
			else
			{
				++nextAc;
			}
		}
		else if (!strcmp(av[nextAc], "-default_color")) // override color for triangles
		{
			if ((nextAc + 3) < ac)
			{
				// red green blue (0.0 - 1.0) range
				// default is black
				ctx->clrCtl.triangle.defaultColor.r = atof(av[++nextAc]);
				ctx->clrCtl.triangle.defaultColor.g = atof(av[++nextAc]);
				ctx->clrCtl.triangle.defaultColor.b = atof(av[++nextAc]);
				++nextAc;
			}
			else
			{
				++nextAc;
			}
		}
		else if (!strcmp(av[nextAc], "-clear")) // override color
		{
			if ((nextAc + 3) < ac)
			{
				// red green blue (0.0 - 1.0) range
				// default is white
				ctx->clrCtl.bkgClear.r = atof(av[++nextAc]);
				ctx->clrCtl.bkgClear.g = atof(av[++nextAc]);
				ctx->clrCtl.bkgClear.b = atof(av[++nextAc]);
				++nextAc;
				ctx->clearFlag = 1;
			}
			else
			{
				++nextAc;
			}
		}
		else if (!strcmp(av[nextAc], "-rx")) // override color
		{
			if (++nextAc < ac)
			{
				MTX_MATRIX	mr, mm;

				ctx->matrixFlag = 1;
				mtx_create_rotation_matrix(&mr, MTX_ROTATE_X_AXIS, DTR(atof(av[nextAc++])));
				mtx_multiply_matrix(&ctx->matrix, &mr, &mm);
				ctx->matrix = mm;
			}
		}
		else if (!strcmp(av[nextAc], "-ry")) // override color
		{
			if (++nextAc < ac)
			{
				MTX_MATRIX	mr, mm;

				ctx->matrixFlag = 1;
				mtx_create_rotation_matrix(&mr, MTX_ROTATE_Y_AXIS, DTR(atof(av[nextAc++])));
				mtx_multiply_matrix(&ctx->matrix, &mr, &mm);
				ctx->matrix = mm;
			}
		}
		else if (!strcmp(av[nextAc], "-rz")) // override color
		{
			if (++nextAc < ac)
			{
				MTX_MATRIX	mr, mm;

				ctx->matrixFlag = 1;
				mtx_create_rotation_matrix(&mr, MTX_ROTATE_Z_AXIS, DTR(atof(av[nextAc++])));
				mtx_multiply_matrix(&ctx->matrix, &mr, &mm);
				ctx->matrix = mm;
			}
		}
		else if (!strcmp(av[nextAc], "-spin")) // turn on spin
		{
			if ((nextAc + 3) < ac)
			{
				ctx->drawAdj.spin.dx = atof(av[++nextAc]);
				ctx->drawAdj.spin.dy = atof(av[++nextAc]);
				ctx->drawAdj.spin.timerMSec = atoi(av[++nextAc]);
				ctx->drawAdj.spinFlag = 1;
				ctx->drawAdj.spin.spinState = ROTATE;	// default
			}
		}
		else // unknown
		{
			++nextAc; // skip so we can eventually get out of the loop
		}
	}

	return 0;
}
*/

/*
BOOL read_bmp(char *outputFilename, IMAGE *image);

//-----------------------------------------------------------------------------
int ConvertBMP(HWND hWnd)
//-----------------------------------------------------------------------------
{
	CTX		*ctx;
	char	outputFilename[256];
	IMAGE	image;

	ctx = (CTX*)GetWindowLong(hWnd, GWL_USERDATA);
	// A file is created, this is where we will save the screen capture.
	sprintf(outputFilename, "%s%05d.bmp", ctx->imageCapture.basename, --ctx->imageCapture.index);
//	read_bmp(outputFilename, &image);
	read_bmp2(outputFilename, &image);
	sprintf(outputFilename, "%s%05d.png", ctx->imageCapture.basename, ctx->imageCapture.index++);
	write_png(outputFilename, &image);
	return 0;
}

//-----------------------------------------------------------------------------
int CaptureBMP(HWND hWnd)
//-----------------------------------------------------------------------------
{
	//	Captures a screenshot into a window and then saves it in a .bmp file.

	HDC		hdcWindow;
	HDC		hdcMemDC = NULL;
	HBITMAP	hbmWindow = NULL;
	BITMAP	bmpWindow;
	CTX		*ctx;
	char	outputFilename[256];

	ctx = (CTX*)GetWindowLong(hWnd, GWL_USERDATA);

	// Retrieve the handle to a display device context for the client area of the window.
	hdcWindow = GetDC(hWnd);

	// Create a compatible DC which is used in a BitBlt from the window DC
	hdcMemDC = CreateCompatibleDC(hdcWindow);

	if (!hdcMemDC)
	{
		MessageBox(hWnd, L"CreateCompatibleDC has failed", L"Failed", MB_OK);
		goto done;
	}

	// Get the client area for size calculation
	RECT rcClient;
	GetClientRect(hWnd, &rcClient);

	// Create a compatible bitmap from the Window DC
	hbmWindow = CreateCompatibleBitmap(hdcWindow, rcClient.right - rcClient.left, rcClient.bottom - rcClient.top);

	if (!hbmWindow)
	{
		MessageBox(hWnd, L"CreateCompatibleBitmap Failed", L"Failed", MB_OK);
		goto done;
	}

	// Select the compatible bitmap into the compatible memory DC.
	SelectObject(hdcMemDC, hbmWindow);

	// Bit block transfer into our compatible memory DC.
	if (!BitBlt(hdcMemDC,
		0, 0,
		rcClient.right - rcClient.left, rcClient.bottom - rcClient.top,
		hdcWindow,
		0, 0,
		SRCCOPY))
	{
		MessageBox(hWnd, L"BitBlt has failed", L"Failed", MB_OK);
		goto done;
	}

	// Get the BITMAP from the HBITMAP
	GetObject(hbmWindow, sizeof(BITMAP), &bmpWindow);

	BITMAPFILEHEADER   bmfHeader;
	BITMAPINFOHEADER   bi;

	bi.biSize = sizeof(BITMAPINFOHEADER);
	bi.biWidth = bmpWindow.bmWidth;
	bi.biHeight = bmpWindow.bmHeight;
	bi.biPlanes = 1;
	bi.biBitCount = 32;
	bi.biCompression = BI_RGB;
	bi.biSizeImage = 0;
	bi.biXPelsPerMeter = 0;
	bi.biYPelsPerMeter = 0;
	bi.biClrUsed = 0;
	bi.biClrImportant = 0;

	DWORD dwBmpSize = ((bmpWindow.bmWidth * bi.biBitCount + 31) / 32) * 4 * bmpWindow.bmHeight;

	// Starting with 32-bit Windows, GlobalAlloc and LocalAlloc are implemented as wrapper functions that
	// call HeapAlloc using a handle to the process's default heap. Therefore, GlobalAlloc and LocalAlloc
	// have greater overhead than HeapAlloc.
	HANDLE hDIB = GlobalAlloc(GHND, dwBmpSize);
	char *lpbitmap = (char *)GlobalLock(hDIB);

	// Gets the "bits" from the bitmap and copies them into a buffer
	// which is pointed to by lpbitmap.
	GetDIBits(hdcWindow, hbmWindow, 0,
		(UINT)bmpWindow.bmHeight,
		lpbitmap,
		(BITMAPINFO *)&bi, DIB_RGB_COLORS);

	// A file is created, this is where we will save the screen capture.
	sprintf(outputFilename, "%s%05d.bmp", ctx->imageCapture.basename, ctx->imageCapture.index++);
	HANDLE hFile = CreateFile(outputFilename, //"captureqwsx.bmp",
		GENERIC_WRITE,
		0,
		NULL,
		CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL, NULL);

	// Add the size of the headers to the size of the bitmap to get the total file size
	DWORD dwSizeofDIB = dwBmpSize + sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);

	//Offset to where the actual bitmap bits start.
	bmfHeader.bfOffBits = (DWORD)sizeof(BITMAPFILEHEADER) + (DWORD)sizeof(BITMAPINFOHEADER);

	//Size of the file
	bmfHeader.bfSize = dwSizeofDIB;

	//bfType must always be BM for Bitmaps
	bmfHeader.bfType = 0x4D42; //BM

	DWORD dwBytesWritten = 0;
	WriteFile(hFile, (LPSTR)&bmfHeader, sizeof(BITMAPFILEHEADER), &dwBytesWritten, NULL);
	WriteFile(hFile, (LPSTR)&bi, sizeof(BITMAPINFOHEADER), &dwBytesWritten, NULL);
	WriteFile(hFile, (LPSTR)lpbitmap, dwBmpSize, &dwBytesWritten, NULL);

	//Unlock and Free the DIB from the heap
	GlobalUnlock(hDIB);
	GlobalFree(hDIB);

	//Close the handle for the file that was created
	CloseHandle(hFile);

done: //Clean up
	DeleteObject(hbmWindow);
	DeleteObject(hdcMemDC);
	ReleaseDC(hWnd, hdcWindow);

	ConvertBMP(hWnd);

	return 0;
}
*/
/*
//-----------------------------------------------------------------------------
void init(HWND hWnd)
//-----------------------------------------------------------------------------
{
	CTX		*ctx;
	GLfloat	fcolor[4] = { .5, .5, .5, 1.0 }; // gray

	ctx = (CTX*)GetWindowLong(hWnd, GWL_USERDATA);

	if (!ctx->base_geometry.type)
		ctx->base_geometry.type = GEOMETRY_ICOSAHEDRON;

	ctx->base_geometry.n_transforms_override = 0;
	ctx->base_geometry.icosa = &icosahedron;
	ctx->base_geometry.octa = &octahedron;
	ctx->base_geometry.tetra = &tetrahedron;
	ctx->base_geometry.cube = &cubehedron;

	//	if (!ctx->clearFlag)
	//	{
	//		ctx->clrCtl.bkgClear.r = 1.0;
	//		ctx->clrCtl.bkgClear.g = 1.0;
	//		ctx->clrCtl.bkgClear.b = 1.0;
	//	}

	ctx->drawAdj.clipFlag = 0; //.active = 0;
	ctx->drawAdj.clipVisibleFlag = 0; // clip.visible = 0;
	ctx->drawAdj.clipZIncrement = (float)0.05;
	ctx->drawAdj.clipZValue = 0;
	glClearColor(0, 0, 0, 0);

	ctx->drawAdj.axiiFlag = 0;
	//	ctx->display_text = 0;
	ctx->gobjectq = LL_Create();

	// enable depth testing with z
	glEnable(GL_DEPTH_TEST);

	if (!ctx->matrixFlag)
		mtx_set_unity(&ctx->matrix);

	if (ctx->drawAdj.spin.dx != 0 || ctx->drawAdj.spin.dy != 0 || ctx->drawAdj.spin.timerMSec != 0)
	{ // explicitly set
		ctx->drawAdj.spin.spinState = ROTATE;
		SetTimer(hWnd, 0, ctx->drawAdj.spin.timerMSec, 0);
	}
	else
	{
		ctx->drawAdj.spin.dx = 0.5;
		ctx->drawAdj.spin.dy = 0.5;
		ctx->drawAdj.spin.timerMSec = 100;
		ctx->drawAdj.spin.spinState = 0;
	}

	// edge attributes
	ctx->eAttr.height = 0.01;
	ctx->eAttr.width = 0.0065;
	ctx->eAttr.offset = 1.01;
	// draw attributes
	ctx->geomAdj.drawWhat = GEOMETRY_DRAW_TRIANGLES;
	ctx->clrCtl.autoColor = 0; // TRIANGLES
	ctx->drawAdj.projection = GEOMETRY_PROJECTION_PERPSECTIVE;

	int		i;
	char	*filename;
	FILE	*fp2;
	ctx->gobjAddFlag = ctx->nInputFiles; // add
	for (i = 0; i < ctx->nInputFiles; ++i)
	{
		filename = ctx->inputFilename[i];
		if (!filename || !strlen(filename))
			continue;
		{

			fp2 = fopen(filename, "r");

			if (fp2)
			{
				parse_file2(ctx, fp2, filename);
				fclose(fp2);
				{
					char	*p;

					p = filename + (strlen(filename) - 1);

					// need to make sure you handle filenames that don't have a path
					while (p > filename)
					{
						if (*p == '\\')
						{
							p = p + 1;
							break;
						}

						--p;
					}

					//					if (!ctx->file_type_override)
					//					{
					//						// check for filename nomenclature to automatically select correct geometry
					//						if (!strncmp(p, "3_5", 3)) ctx->base_geometry.type = GEOMETRY_ICOSAHEDRON;
					//						else if (!strncmp(p, "3_4", 3)) ctx->base_geometry.type = GEOMETRY_OCTAHEDRON;
					//						else if (!strncmp(p, "3_3", 3)) ctx->base_geometry.type = GEOMETRY_TETRAHEDRON;
					//						else if (!strncmp(p, "4_3", 3)) ctx->base_geometry.type = GEOMETRY_CUBEHEDRON;
					//					}
					File_SetWindowText(hWnd, p);
				}
			}
		}
		ctx->gobjAddFlag = 0; // add

	}
	
		if (strlen(ctx->filename))
		{
			FILE	*fp2;

			fp2 = fopen(ctx->filename, "r");

			if (fp2)
			{
				parse_file2(ctx, fp2, ctx->filename);
				fclose(fp2);
				{
					char	*p;

					p = ctx->filename + (strlen(ctx->filename) - 1);

					// need to make sure you handle filenames that don't have a path
					while (p > ctx->filename)
					{
						if (*p == '\\')
						{
							p = p + 1;
							break;
						}

						--p;
					}

					if (!ctx->file_type_override)
					{
						// check for filename nomenclature to automatically select correct geometry
						if (!strncmp(p, "3_5", 3)) ctx->base_geometry.type = GEOMETRY_ICOSAHEDRON;
						else if (!strncmp(p, "3_4", 3)) ctx->base_geometry.type = GEOMETRY_OCTAHEDRON;
						else if (!strncmp(p, "3_3", 3)) ctx->base_geometry.type = GEOMETRY_TETRAHEDRON;
						else if (!strncmp(p, "4_3", 3)) ctx->base_geometry.type = GEOMETRY_CUBEHEDRON;
					}
					File_SetWindowText(hWnd, p);
				}
			}
		}
}
*/
/*
//-----------------------------------------------------------------------------
int capture_film_frame (CTX *ctx)
//-----------------------------------------------------------------------------
{
// either capture the image and exit or go into loop
//	if (!strlen(ctx->capture.program_filename) || !strlen(ctx->capture.output_filename) || !ctx->capture.nFrames )
//		return 1;
//
//	char				buffer[1024], outputFilename[256];
//	static PAINTSTRUCT	ps;
//	STARTUPINFO			si;
//	PROCESS_INFORMATION pi;
//
//	if ( ctx->capture.nFrames > 1 )
//		sprintf(outputFilename, "%s%04d.png", ctx->capture.output_filename, ctx->capture.curFrame++);
//	else
//		sprintf(outputFilename, "%s", ctx->capture.output_filename );
//
//	sprintf(buffer, "%s /capture=3 /convert=%s ", ctx->capture.program_filename, outputFilename);
//
//	ZeroMemory( &si, sizeof(si) );
//	si.cb = sizeof(si);
//	ZeroMemory( &pi, sizeof(pi) );
//
//	// Start the child process.
//	if( !CreateProcess( ctx->capture.program_filename, // No module name (use command line)
//		buffer,							// Command line and options
//		NULL,						    // Process handle not inheritable
//		NULL,						    // Thread handle not inheritable
//		FALSE,						    // Set handle inheritance to FALSE
//		0,							    // No creation flags
//		NULL,						    // Use parent's environment block
//		NULL,						    // Use parent's starting directory
//		&si,						    // Pointer to STARTUPINFO structure
//		&pi ) ) 						// Pointer to PROCESS_INFORMATION structure
//	{
//		printf( "CreateProcess failed (%d).\n", GetLastError() );
//		return 1;
//	}
//
//	// Wait until child process exits.
//	WaitForSingleObject( pi.hProcess, INFINITE );
//
//	// Close process and thread handles.
//	CloseHandle( pi.hProcess );
//	CloseHandle( pi.hThread );
//
	return 0;
}
*/
/*
Scratchapixel 2.0Sign in
The Perspective and Orthographic Projection Matrix
Contents
What Are Projection Matrices and Where / Why Are They Used ?
Projection Matrices : What You Need to Know First
Building a Basic Perspective Projection Matrix
The OpenGL Perspective Projection Matrix
About the Projection Matrix, the GPU Rendering Pipeline and Clipping
The OpenGL Orthographic Projection Matrix
Source Code
A Simple Perspective Matrix
A word of warning again.The matrix we will present in this chapter is different from the projection matrix that is being used in APIs such as OpenGL or Direct3D.Though, it technically produces the same results.In the lesson 3D Viewing : the Pinhole Camera Model we learned how to compute the screen coordinates(left, right, top and bottom) based on the camera near clipping plane and angle - of - view(in fact, we learned how to compute these coordinates based on the parameters of a physically based camera model).We then used these coordinates to decide if projected points were visible or not in the image(they would only be visible if their coordinates where contained within the screen coordinates).In the lesson Rasterization : a Practical Implementation, we learned how to remap the projected point coordinates to NDC coordinates(coordinates in the range[-1, 1]) using the screen coordinates.In other words, to avoid having to compare the projected point coordinates to the screen coordinates, we remapped the point coordinates first to the range[-1, 1] using the screen coordinates.Deciding whether a point is visible or not is just a matter of testing if any of its coordinates is lower than - 1 or greater than 1.

In this chapter, we will use a slightly different approach.We will assume that the screen coordinates are(-1, 1) for the left and right coordinates and (-1, 1) for the bottom and top coordinates(assuming a square screen) to start with(since this is the range we want to test the coordinates against), and we will account for the camera field - of - view by scaling the projected point coordinates directly(rather than using the screen coordinates scaled by the angle - of - view to remap the points coordinates to NDC space).Both methods have the same effect.

Recall from the lesson on Geometry that the multiplication of a point by a matrix is as follows :

[xyzw]∗⎡⎣⎢⎢⎢m00m10m20m30m01m11m21m31m02m12m22m32m03m13m23m33⎤⎦⎥⎥⎥
x′ = x∗m00 + y∗m10 + z∗m20 + w∗m30y′ = x∗m01 + y∗m11 + z∗m21 + w∗m31z′ = x∗m02 + y∗m12 + z∗m22 + w∗m32w′ = x∗m03 + y∗m13 + z∗m23 + w∗m33
Also, remember from the previous chapter, that point P', i.e. the projection of P onto the image plane, can be computed by dividing the x- and y-coordinates of P by the inverse of the point z-coordinate:

P′x = Px−PzP′y = Py−Pz
How do we compute P' using a point-matrix multiplication?

Figure 1: when you create a camera, it is by default aligned along the world coordinate system negative z - axis.This is a convention used by most 3D applications.
First, x', y' and z' (the coordinates of P') in the equation above needs to be set with x, y and -z respectively(where x, y and z are the coordinates of the point P we want to project).Why do we want to set z' to -z instead of just z? Remember that when we transform points from world space to camera space, all points defined in the camera coordinate system and located in front of the camera have a negative z-value. This is due to the fact that by default, cameras always point down the negative z-axis (figure 1). We will also assign z to z' but invert its sign so that z' is positive:

x′ = x, y′ = yz′ = −zz′ > 0
If somehow within the point - matrix multiplication process, we could manage to divide x', y' and z' by -z, then we would actually end up with:

x′ = x−z, y′ = y−zz′ = −z−z = 1
Which, as we know, are the equations to compute the projected point P' coordinates (don't worry too much about z' for now). Thus, again the question is, is it possible to get the same result with a point-matrix multiplication? If so, what would that matrix look like? Let's consider the problem step by step.First we said we needed to set the coordinates x', y' and z' with the coordinates x, y and -z respectively. This is simple. In fact, a simple identity matrix (with a slight modification) will do the trick:

[xyz(w = 1)]∗⎡⎣⎢⎢⎢1000010000−100001⎤⎦⎥⎥⎥
x′ = x∗1 + y∗0 + z∗0 + w∗0y′ = x∗0 + y∗1 + z∗0 + w∗0z′ = x∗0 + y∗0 + z∗−1 + w∗0w′ = x∗0 + y∗0 + z∗0 + (w = 1)∗1====xy−z1
Note here that the point we multiply the matrix with, has homogeneous coordinates or at least is implicitly assumed to be a point with homogeneous coordinates and whose fourth coordinate, w, is set to 1. The second step requires to divide x' and y' by - z.Now, recall what we said in the previous chapter about points with homogeneous coordinates.Point P is a point with homogeneous coordinates, and its fourth coordinate, w, is equal to 1. This is the condition for making it possible to multiply 3D points which originally are 3D points with Cartesian coordinates, by 4x4 matrices.This doesn't mean though, that the point-matrix multiplication operation can't set the value of w' (the fourth coordinates of the transformed point P') to something different than 1 (we know w' is always equal to 1 when affine transformation matrices are used, but this doesn't have to be the case with other types matrices such as ... projection matrices of course).To convert the point with homogeneous coordinates back to a point with Cartesian coordinates, we need to divide x', y' and z' by w' as explained in the previous chapter :

... the homogeneous point[x, y, z, w] corresponds to the three - dimensional point[x / w, y / w, z / w].
This operation requires to divide x', y', z' by w', and guess what, if somehow w' was equal to -z, then we would exactly get what we are looking for: dividing x', y' and z' by - z.

The trick is to use to the conversion from homogeneous to Cartesian coordinate in the point - matrix multiplication process to perform the perspective divide(dividing x and y by z to compute the projected point coordinates x' and y').This requires to assign - z to w'.

The question now is : can we change our perspective projection matrix(which is just a slightly modified version of the identity matrix at this stage) so that the result of the point - matrix multiplication sets w' to -z? To answer this question, let's look again at the point - matrix multiplication but let's focus for now on the w' coordinate only :

w′ = x∗m03 + y∗m13 + z∗m23 + w∗m33
We know that the point P w - coordinate is equal to 1. Thus the above equation becomes :

w′ = x∗m03 + y∗m13 + z∗m23 + 1∗m33
But this is actually not important.What's important, is to note that z which is multiplied by the matrix coefficient m23 (in red) is used in this equation. And z, is exactly what we want w' to be set with or more exactly - z.It is trivial to note that if the matrix coefficient m23 was actually set to - 1 and all the other matrix coefficients involved in computing w' were set to 0 (m03, m13 and m33 respectively), then we would get:

w′ = x∗0 + y∗0 + z∗−1 + 1∗0 = −z.
Which is exactly the result we are looking for.In conclusion, to set w' to -z, the coefficients m03, m13 m23 and m33 of the perspective projection matrix need to be set to 0, 0, -1 and 0 respectively. If we make these changes to our previous matrix, here is what the perspective projection matrix now looks like:

[xyz1]∗⎡⎣⎢⎢⎢1000010000−1000−10⎤⎦⎥⎥⎥
Note the difference between this matrix and a standard affine transformation matrix.Remember that for the latter, the coefficients of the fourth column are always set to{ 0, 0, 0, 1 }.
⎡⎣⎢⎢⎢⎢m00m10m20Txm01m11m21Tym02m12m22Tz0001⎤⎦⎥⎥⎥⎥
In the current form of our projection matrix, the coefficients of this column are now set to{ 0, 0, -1, 0 }.
⎡⎣⎢⎢⎢⎢m00m10m20Txm01m11m21Tym02m12m22Tz00−10⎤⎦⎥⎥⎥⎥
This has for effect to set w' to -z. And if -z is different than 1, then the coefficient of the transformed points will need to be normalized. This how or when more precisely the perspective divide is performed when a point is multiplied by a projection matrix. It is important you understand this idea.
When this matrix is used in a point - matrix multiplication, we get :

x′ = x∗1 + y∗0 + z∗0 + 1∗0y′ = x∗0 + y∗1 + z∗0 + 1∗0z′ = x∗0 + y∗0 + z∗−1 + 1∗0w′ = x∗0 + y∗0 + z∗−1 + 1∗====xy−z−z
Then divide all coordinates by w' to set the point's homogeneous coordinates back to Cartesian coordinates :

x′ = x′ = xw′ = −z, y′ = y′ = yw′ = −z, z′ = z′ = −zw′ = −z = 1.
This is exactly the result we were aiming at.At this point in the chapter, we have a simple perspective projection matrix which can be used to compute P'. However we still need to account for two things. First, we need to remap z' to the range[0, 1].To do so, we will be using the camera near and far clipping planes.Finally, we need to take into account the camera angle - of - view.This parameter controls how much of the scene we see(remember that we aim to simulate a pinhole camera model which is defined by a near and far clipping planes as well as a field - of - view).

Remapping the Z - Coordinate
Another goal of the perspective projection matrix is to normalize the z - coordinate of P, that is, to scale its value between 0 and 1. To do so, we will use the near and far clipping planes of the camera(you can find more information on clipping planes in the lesson 3D Viewing : the Pinhole Camera Model).To achieve this goal, we will set the coefficients of the matrix used to calculate z' to certain values:
z′ = x∗m20 + y∗m21 + z∗m22 + 1∗m23
We will change the third(in green) and fourth(in red) coefficients of the third column to fulfil two conditions : when P lies on the near clipping plane, z' is equal to 0 after the z-divide, and when z lies on the far clipping plane, z' is equal to 1 after the z - divide.This remapping operation is obtained by setting these coefficients to :

−f(f−n),
and

−f∗n(f−n)
respectively, where n stands for the near clipping plane and f for the far clipping plane(you can find a derivation on these equation in the next chapter).To convince you that this works, let's look at the result of z' when P lies on the near and far clipping planes(\m_{ 20 }\) and m21 are equal to 0):

−(z′ = z = −n)∗f−f∗n(f−n)(w′ = −1∗z = n) = n∗f−f∗n(f−n)(w′ = −1∗z = n) = 0
−(z′ = z = −f)∗f−f∗n(f−n)(w′ = −1∗z = f) = f∗f−f∗n(f−n)(w′ = −1∗z = f) =
f∗(f−n)(f−n)(w′ = −1∗z = f) = ff = 1
When z equals n(the near clipping plane) you can see in the first line of the equation that the numerator is equal to 0. Therefore the result of the equation is 0. In the second line, we have replaced z with f, the far clipping plane.By rearranging the terms, we can see that the(f - n) terms cancel out, and we are left with f divided by itself, which equals 1.

Question from a reader : "You give the solution for remapping z to 0 to 1, but how did you come up with these formulas?".We will explain how to derive these formulas in the chapter devoted to the OpenGL perspective projection matrix.
Our modified perspective projection matrix that projects P to P' and remaps the z' - coordinate of P' from 0 to 1 now looks like this:

⎡⎣⎢⎢⎢⎢⎢⎢⎢⎢1000010000−f(f−n)−f∗n(f−n)00−10⎤⎦⎥⎥⎥⎥⎥⎥⎥⎥
The remapping of the z - coordinate from 0 to 1 is not a linear process.In the image on the right, we have plotted the result of z' with the near and far clipping planes set to 1 and 20, respectively. As is evident, the curve is steep for values in the interval [1:3] and quite flat for values greater than 7. It means that the precision of z' is high in the proximity of the near clipping plane and low as we get closer to the far clpping planes.If the range[near:far] is too large, depth precision problems known as z - fighting can arise in depth - based hidden surface renderers.It is therefore important to make this interval as small as possible in order to minimise the depth buffer precision problem.
Taking the Field - of - View into Account
In this chapter, we will assume that the screen is a square and that the distance between the screen and the eye is equal to 1. This is only to simplify the demonstration.You will provide a more generic solution in the next chapter.
All we need to do to get a basic perspective projection matrix working, is to account for the angle of view or field - of - view(FOV) of the camera.We know that by changing the focal length of a zoom lens on a real camera, we can change how much we see of a scene(the extent of the scene).We want our CG camera to work in the same way.

Figure 2: changing the focal makes it possible to see more or less of the scene we photograph.As can be seen in this illustration though, it normally changes the screen window.
The size of the projection window is[-1:1] in each dimension.In other words, a projected point is visible, if its x - and y - coordinates are within the range[-1:1].Points whose projected coordinates are not contained in this range are invisible and are not drawn.

Figure 3 : The field - of - view or FOV controls how much of the scene is viewed.
Note that in our system, the screen window maximum and minimum values do not change.They are always in the range[-1:1] regardless of the value used for the FOV(we assume that the screen is a square).When points coordinates are contained within the range[-1, 1] we say that they are defined in NDC space.

Remember from chapter 1, that the goal of perspective projection matrix, is to project point onto the screen and remap their coordinates to the range[-1, 1](or to NDC space).

The distance to the screen window from the eye position does not change either(it is equal to 1).When the FOV changes, however, we have just shown that the screen window should accordingly become larger or smaller(see figures 2 and 5).How do we reconcile this contradiction ? Since we want the screen window to be fixed, what we will change instead are the projected coordinates.We will scale them up or down and test them against the fixed borders of the screen window.Let's work through a few examples.

Figure 4 : To account for the field - of - view effect while keeping the size of the screen window the same(in the range[-1:1], we need to scale the points up or down, depending on the FOV value.
	Imagine a point whose projected x - y coordinates are(1.2, 1.3).These coordinates are outside the range[-1:1], and the point is therefore not visible.If we scale them down by multiplying them by 0.7, the new, scaled coordinates of the point become(0.84, 0.91).This point is now visible, since both coordinates are in the range[-1:1].This action would corresponds to the physical action of zooming out.Zooming out means decreasing the focal length on a zoom lens or increasing the FOV.For the opposite effect, multiply by a value greater than 1. For example, imagine a point whose projected coordinates are(-0.5, 0.3).If you multiply these numbers by 2.1, the new, scaled coordinates are(-1.05, 0.63).The y - coordinate is still contained within the range[-1:1], but now the x - coordinate is lower than - 1 and thus too far to the left.The point which was originally visible becomes invisible after scaling.What happened ? You zoomed in.

	To scale the projected coordinates up or down, we will use the field - of - view of the camera.The field - of - view(or angle - of - view) intuitively controls how much of the scene is visible to the camera.See the lesson 3D Viewing : the Pinhole Camera Model for more information.

	The FOV can be either the horizontal or vertical angle.If the screen window is square, the choice of FOV does not matter, as all the angles are the same.If the frame aspect ratio is different than 1, however, the choice of FOV(check the lesson on cameras in the basic section).In OpenGL(GLUT more precisely), the FOV corresponds to the vertical angle.In this lesson, the FOV is considered to be the horizontal angle(which is also the case in Maya).Figure 5 : Zooming in or out normally changes the size of the screen window.See how it becomes bigger or smaller as the field - of - view increases or decreases.
	The value of FOV, however, is not directly used; the tangent of the angle is used instead.In the CG literature, the FOV can be defined as either the angle or half of the angle that is subtended by the viewing cone.We believe it is more intuitive to see the FOV as the angular extent of the visible scene rather than as half of this angle(as represented in figures 3 and 5).To find a value that can be used to scale the projected coordinates, however, we need to divide the FOV angle by two.This explains why the FOV is sometimes expressed as the half - angle.Why do we divide the angle in half ? What is of interest to us is the right triangle inscribed in the cone.The change in this angle between the hypothenuse and the adjacent side of the triangle(or the FOV half - angle) controls the length of the triangle's opposite side. By increasing or decreasing this angle, we can scale up or down the border of the image window. And since we need a value that is centered around 1, we will take the tangent of this angle to scale our projected coordinates. Note that when the FOV half-angle is 45 degrees (FOV is then 90 degrees), the tangent of this angle is equal to 1. Therefore, when we multiply the projected coordinates by 1, the coordinates do not change. For values of the FOV lesser than 90 degrees, the tangent of the half-angle gives values smaller than 1, and for values greater than 90 degrees, it gives values greater than 1. But the opposite effect is needed. Recall that zooming in should correspond to a decrease in FOV, and so we need to multiply the projected point coordinates by a value greater than 1. To zoom out means that the FOV increases, so we need to multiply these coordinates by a value less than 1. Thus, we will use the reciprocal of the tangent or in other words, one over the tangent of the FOV half-angle.

	Here is the final equation to compute the value used to scale the coordinates of the projected point :

S = 1tan(fov2∗π180)
And thus we have the final version of our basic perspective projection matrix :

⎡⎣⎢⎢⎢⎢⎢⎢⎢⎢S0000S0000−f(f−n)−f∗n(f−n)00−10⎤⎦⎥⎥⎥⎥⎥⎥⎥⎥

Are There Different Ways of Building this Matrix ?
Yes and no.Some renderers may have a different implementation of the perspective projection matrix.This is the case with OpenGL.OpenGL used a function called glFrustum to create perspective projection matrices.This call takes as arguments, the left, right, bottom and top coordinates in addition to the near and far clipping planes.Unlike our system, OpenGL assumes that the points in the scene are projected on the near clipping planes, rather than on a plane that lies one unit away from the camera position.The matrix itself might also look slightly different.Be careful about the convention used for vectors and matrices.The projected point can be represented as either a row or column vector.Check also whether the renderer uses a left - or right - handed coordinate system, as that could change the sign of the matrix coefficients.Despite these differences, the underlying principle of the perspective projection matrix is the same for all renderers.They always divide the x - and y - coordinates of the point by its z - coordinate.In the end, all matrices should project the same points to the same pixel coordinates, regardless of the conventions or the matrix that is being used.We will study the construction of the OpenGL matrix in the next chapter.

Test Program
To test our basic perspective projection matrix, we wrote a small program to project the vertices of a polygonal object(the Newell's teapot) onto the image plane using the projection matrix we developed in this chapter. The program itself, is simple in its implementation. A function is used to build the perspective projection matrix. Its arguments are the camera's near and far clipping plane, as well as the camera field - of - view defined in degrees.The vertices of the teapot are stored in an array(line 5).Each point is then projected onto the image plane using a simple point - matrix multiplication(line 51).Note that we first transform the points from world or object space to camera space.The function multPointMatrix computes the product of a point with a matrix.Note how we create the fourth component, w(line 25), and divide the result of the new point's coordinates by w, only if w is different than 1 (line 28). This is where and when the z or perspective divide occurs. A point is only visible if its projected x- and y- coordinates are contained within the interval [-1:1] (regardless of the image aspect ratio). Otherwise the point is outside the boundaries of the camera's screen boundaries.If the point is contained within this interval, we need to remap these coordinates to raster space, i.e.pixel coordinates.This operation is simple.We remap the coordinates from[-1:1] to[0:1], multiply by the image size, and round the resulting floating digit to the nearest integer, as pixel coordinates must be integers.

#include <cstdio> 
#include <cstdlib> 
#include <fstream> 
#include "geometry.h" 
#include "vertexdata.h" 

	void setProjectionMatrix(const float &angleOfView, const float &near, const float &far, Matrix44f &M)
{
	// set the basic projection matrix
	float scale = 1 / tan(angleOfView * 0.5 * M_PI / 180);
	M[0][0] = scale; // scale the x coordinates of the projected point 
	M[1][1] = scale; // scale the y coordinates of the projected point 
	M[2][2] = -far / (far - near); // used to remap z to [0,1] 
	M[3][2] = -far * near / (far - near); // used to remap z [0,1] 
	M[2][3] = -1; // set w = -z 
	M[3][3] = 0;
}

void multPointMatrix(const Vec3f &in, Vec3f &out, const Matrix44f &M)
{
	//out = in * M;
	out.x = in.x * M[0][0] + in.y * M[1][0] + in.z * M[2][0] + M[3][0];
	out.y = in.x * M[0][1] + in.y * M[1][1] + in.z * M[2][1] + M[3][1];
	out.z = in.x * M[0][2] + in.y * M[1][2] + in.z * M[2][2] + M[3][2];
	float w = in.x * M[0][3] + in.y * M[1][3] + in.z * M[2][3] + M[3][3];

	// normalize if w is different than 1 (convert from homogeneous to Cartesian coordinates)
	if (w != 1) {
		out.x /= w;
		out.y /= w;
		out.z /= w;
	}
}

int main(int argc, char **argv)
{
	uint32_t imageWidth = 512, imageHeight = 512;
	Matrix44f Mproj;
	Matrix44f worldToCamera;
	worldToCamera[3][1] = -10;
	worldToCamera[3][2] = -20;
	float angleOfView = 90;
	float near = 0.1;
	float far = 100;
	setProjectionMatrix(angleOfView, near, far, Mproj);
	unsigned char *buffer = new unsigned char[imageWidth * imageHeight];
	memset(buffer, 0x0, imageWidth * imageHeight);
	for (uint32_t i = 0; i < numVertices; ++i) {
		Vec3f vertCamera, projectedVert;
		multPointMatrix(vertices[i], vertCamera, worldToCamera);
		multPointMatrix(vertCamera, projectedVert, Mproj);
		if (projectedVert.x < -1 || projectedVert.x > 1 || projectedVert.y < -1 || projectedVert.y > 1) continue;
		// convert to raster space and mark the position of the vertex in the image with a simple dot
		uint32_t x = std::min(imageWidth - 1, (uint32_t)((projectedVert.x + 1) * 0.5 * imageWidth));
		uint32_t y = std::min(imageHeight - 1, (uint32_t)((1 - (projectedVert.y + 1) * 0.5) * imageHeight));
		buffer[y * imageWidth + x] = 255;
	}
	// save to file
	std::ofstream ofs;
	ofs.open("./out.ppm");
	ofs << "P5\n" << imageWidth << " " << imageHeight << "\n255\n";
	ofs.write((char*)buffer, imageWidth * imageHeight);
	ofs.close();
	delete[] buffer;

	return 0;
}
*/
/*

//-----------------------------------------------------------------------------
void draw_geometryXXX(CTX *ctx)
//-----------------------------------------------------------------------------
{
	int			i, j, n_faces;
	MTX_MATRIX	*mp;
//	MTX_MATRIX	*mp;
	MTX_VECTOR	*v;
	MTX_STACK	*stack;
	COLOR		*c;
	GUT_POINT	pa, pb, pc;
	GUT_VECTOR	vab, vbc, normal;
	POLYHEDRON	*poly;
	GEO_OBJECT	*gobj;
	TRIANGLE	*tri;
	COLOR		*clr;
	EDGE		*edge;
	GUT_POINT	out[8]; // edge triangle points 
	static int	max_vertex;

//	geometry_draw_init(ctx);  //, NEW)
//	while (geometry_next_draw_transform(ctx, &mp, 0))
//	{
//		int i;
//		i = 12;
//	}
	stack = mtx_create_stack(32, MTX_PRE_MULTIPLY);

	switch (ctx->base_geometry.type) {
	case GEOMETRY_ICOSAHEDRON:	poly = ctx->base_geometry.icosa; break;
	case GEOMETRY_OCTAHEDRON:	poly = ctx->base_geometry.octa;  break;
	case GEOMETRY_TETRAHEDRON:	poly = ctx->base_geometry.tetra; break;
	case GEOMETRY_CUBEHEDRON:	poly = ctx->base_geometry.cube;  break;
	default: poly = ctx->base_geometry.icosa;
	}

	if (ctx->base_geometry.n_transforms_override)
		n_faces = 1;
	else
		n_faces = poly->n_faces;

	if (ctx->drawAdj.axiiFlag)
	{
		glBegin(GL_LINES);
		{
			glLineWidth((GLfloat) 10.0);
			glColor3f((float)1.0, (float)0, (float)0);
			glVertex3f((float)-1.05, (float)0, (float)0);
			glVertex3f((float)1.05, (float)0, (float)0);
			glColor3f((float)0.0, (float)1.0, (float)0);
			glVertex3f((float)0, (float)-1.05, (float)0);
			glVertex3f((float)0, (float)1.05, (float)0);
			glColor3f((float)0.0, (float)0, (float)1.0);
			glVertex3f((float)0, (float)0, (float)-1.05);
			glVertex3f((float)0, (float)0, (float)1.05);
		}
		glEnd();
	}

	LL_SetHead(ctx->gobjectq);
	while (gobj = (GEO_OBJECT*)LL_GetNext(ctx->gobjectq))
	{
		if (gobj->nTri && ( ctx->geomAdj.drawWhat & 0x1 ) ) //ahttri_edge_m == 0 || ctx->tri_edge_mode == 2 ) )
		{
			if (!gobj->v_out) // check if memory has been allocated
			{
				gobj->v_out = malloc(sizeof(MTX_VECTOR) * gobj->nVtx);
			}
			glBegin(GL_TRIANGLES);
			for (j = 0; j < n_faces; ++j)
			{
				mp = create_polyhedron_matrix(stack, poly->set + j, ctx->geomAdj.orientation);

				mtx_vector_multiply(gobj->nVtx, (MTX_VECTOR*)gobj->vtx, gobj->v_out, mp);

				mtx_stack_reset(stack);

				for (i = 0, v = gobj->v_out, tri=gobj->tri; i < gobj->nTri; ++i, ++tri)
				{
					// copy vertex data to new variables
					pa.x = v[tri->vtx[0]].data.xyzw[0];
					pa.y = v[tri->vtx[0]].data.xyzw[1];
					pa.z = v[tri->vtx[0]].data.xyzw[2];
					pb.x = v[tri->vtx[1]].data.xyzw[0];
					pb.y = v[tri->vtx[1]].data.xyzw[1];
					pb.z = v[tri->vtx[1]].data.xyzw[2];
					pc.x = v[tri->vtx[2]].data.xyzw[0];
					pc.y = v[tri->vtx[2]].data.xyzw[1];
					pc.z = v[tri->vtx[2]].data.xyzw[2];

					// check for special flag to re-normalize
					if (ctx->drawAdj.normalizeFlag)//if (ctx->global_normalize)
					{
						gut_normalize_point(&pa);
						gut_normalize_point(&pb);
						gut_normalize_point(&pc);
					}

					// determine face normal from cross product
					gut_vector(&pa, &pb, &vab);
					gut_vector(&pb, &pc, &vbc);
					gut_cross_product(&vab, &vbc, &normal);
					gut_normalize_point((GUT_POINT*)&normal);

					glNormal3f((float)normal.i * 3, (float)normal.j * 3, (float)normal.k * 3);

					if (ctx->clrCtl.triangle.flag )
					{
						glColor3f((float)ctx->clrCtl.triangle.override.r, (float)ctx->clrCtl.triangle.override.g, (float)ctx->clrCtl.triangle.override.b);
					}
					else if (ctx->clrCtl.autoColor && !ctbl_get_color(gobj->ctT, tri->id, &clr))
					{
						glColor3f((float)clr->r, (float)clr->g, (float)clr->b);
					}
					else
					{
						glColor3f((float)tri->color.r, (float)tri->color.g, (float)tri->color.b);
					}

					if (ctx->drawAdj.circleFlag)
					{
						draw_circle_segment(&pa, &pb, &pc);
					}
					else
					{
						glVertex3f((float)pa.x, (float)pa.y, (float)pa.z);// ++v;
						glVertex3f((float)pb.x, (float)pb.y, (float)pb.z);// ++v;
						glVertex3f((float)pc.x, (float)pc.y, (float)pc.z);// ++v;
					}
				}
			}
			glEnd();
		}
		if (gobj->nEdge && (ctx->geomAdj.drawWhat & 0x2 ) ) //ctx->tri_edge_mode == 1 || ctx->tri_edge_mode == 2))
		{
			if (!gobj->v_out) // check if memory has been allocated
			{
				gobj->v_out = malloc(sizeof(MTX_VECTOR) * gobj->nVtx);
			}
			glBegin(GL_TRIANGLES);
			for (j = 0; j < n_faces; ++j)
			{
				mp = create_polyhedron_matrix(stack, poly->set + j, ctx->geomAdj.orientation);

				mtx_vector_multiply(gobj->nVtx, (MTX_VECTOR*)gobj->vtx, gobj->v_out, mp);

				mtx_stack_reset(stack);

				for (i = 0, v = gobj->v_out, edge = gobj->edge; i < gobj->nEdge; ++i, ++edge)
				{
					// copy vertex data to new variables
					pa.x = v[edge->vtx[0]].data.xyzw[0];
					pa.y = v[edge->vtx[0]].data.xyzw[1];
					pa.z = v[edge->vtx[0]].data.xyzw[2];
					pb.x = v[edge->vtx[1]].data.xyzw[0];
					pb.y = v[edge->vtx[1]].data.xyzw[1];
					pb.z = v[edge->vtx[1]].data.xyzw[2];

					geo_edge_to_triangles(&ctx->eAttr, &pa, &pb, out, ctx->drawAdj.normalizeFlag);

					// if drawing both triangles and edges and they share a common color table reverse the color ID
					ctbl_get_color_new(gobj->ctE, edge->id, ((ctx->geomAdj.drawWhat == 0x3 ) && (gobj->ctE == gobj->ctT)) ? 1 : 0, &clr);
						
					draw_triangle(ctx, &out[0], &out[1], &out[2], clr); //gobj->clrE, edge->id);
					draw_triangle(ctx, &out[2], &out[3], &out[0], clr); //gobj->clrE, edge->id);
					draw_triangle(ctx, &out[0], &out[1], &out[2], clr); //gobj->clrE, edge->id);
					draw_triangle(ctx, &out[2], &out[3], &out[0], clr); //gobj->clrE, edge->id);
					if (ctx->eAttr.height != 0.0)
					{
						draw_triangle(ctx, &out[0], &out[4], &out[5], clr); //, gobj->clrE, edge->id);
						draw_triangle(ctx, &out[5], &out[1], &out[0], clr); //, gobj->clrE, edge->id);
						draw_triangle(ctx, &out[2], &out[6], &out[7], clr); //, gobj->clrE, edge->id);
						draw_triangle(ctx, &out[7], &out[3], &out[2], clr); //, gobj->clrE, edge->id);
					}
				}
			}
			glEnd();
		}
	}

	glBegin(GL_TRIANGLES);

	if (ctx->drawAdj.clipFlag && ctx->drawAdj.clipVisibleFlag)
	{
		glNormal3f((float)0, (float)0, (float)3);

		glColor3f((float)1, (float)1, (float)0);
		glVertex3f((float)1.05, (float)-1.05, (float)ctx->drawAdj.clipZValue);
		glVertex3f((float)1.05, (float)1.05, (float)ctx->drawAdj.clipZValue);
		glVertex3f((float)-1.05, (float)1.05, (float)ctx->drawAdj.clipZValue);

		glVertex3f((float)-1.05, (float)1.05, (float)ctx->drawAdj.clipZValue);
		glVertex3f((float)-1.05, (float)-1.05, (float)ctx->drawAdj.clipZValue);
		glVertex3f((float)1.05, (float)-1.05, (float)ctx->drawAdj.clipZValue);
	}

	// cleanup
	mtx_destroy_stack(stack);

	glEnd();
}
*/
/*

//-----------------------------------------------------------------------------
void ds_svg_draw_geometry(CTX *ctx, SVG *svg)
//-----------------------------------------------------------------------------
{
	int			i, j, k, n_faces;
	MTX_MATRIX	*mp; 
	MTX_VECTOR	*v;
	MTX_STACK	*stack; 
	COLOR		*c, ctmp;
	GUT_POINT	pa, pb, pc, origin[2] = { 0,0,0,1 };
	GUT_VECTOR	vab, vbc, normal;
	POLYHEDRON	*poly;
	GEO_OBJECT	*gobj;
	TRIANGLE	*tri;
	COLOR		*clr;
	EDGE		*edge;
	GUT_POINT	out[8]; // edge triangle points 
	GUT_POINT	tp[4], tpp[4];
	double		scale;
	double		xoffset, yoffset;
	char		style[64];
	GUT_POINT	light[2];// = { 0.5, 0.5, 2.0, 1.0 };
	GUT_VECTOR	vec[2];
	double		incidenceAngle;
	double		mproj[16];
	double		mview[16];
	double		mtran[16];
	double		sign; // used for face culling

	return ds_svg_draw_geometry2(ctx, svg);

	glGetDoublev(GL_MODELVIEW_MATRIX, &mview); // ctx->drawAdj.matrix);
	glGetDoublev(GL_PROJECTION_MATRIX, &mproj); // ctx->drawAdj.matrix);

	scale = ctx->window.height / 2.0;
	xoffset = ctx->window.width / 2.0;
	yoffset = ctx->window.height / 2.0;

	stack = mtx_create_stack(32, MTX_PRE_MULTIPLY);

	switch (ctx->base_geometry.type) {
	case GEOMETRY_ICOSAHEDRON:	poly = ctx->base_geometry.icosa; break;
	case GEOMETRY_OCTAHEDRON:	poly = ctx->base_geometry.octa;  break;
	case GEOMETRY_TETRAHEDRON:	poly = ctx->base_geometry.tetra; break;
	case GEOMETRY_CUBEHEDRON:	poly = ctx->base_geometry.cube;  break;
	default: poly = ctx->base_geometry.icosa;
	}

	if (ctx->base_geometry.n_transforms_override)
		n_faces = 1;
	else
		n_faces = poly->n_faces;

	// BACKGROUND (extend over the boundaries and let the renderer clip)
	if (ctx->svg.backgroundFlag)
	{
		sprintf(style, "style=\"fill:#%02x%02x%02x; \"", (int)(ctx->clrCtl.bkgClear.r * 255), (int)(ctx->clrCtl.bkgClear.g * 255), (int)(ctx->clrCtl.bkgClear.b * 255));
		tp[0].x = -4;
		tp[0].y = -4;
		tp[1].x = ctx->window.width + 4;
		tp[1].y = -4;
		tp[2].x = ctx->window.width + 4;
		tp[2].y = ctx->window.height + 4;
		tp[3].x = -4;
		tp[3].y = ctx->window.height + 4;
		svg_start_group(svg, style);
		svg_polygon(svg, tp, 4);
		svg_end_group(svg, style);
	}
	if (ctx->clrCtl.useLightingFlag)
		light[0] = ctx->clrCtl.light;

//	geometry_draw_init(ctx);
//	while (geometry_next_draw_transform(ctx, &mp, &reverseOrder, ctx->geomAdj.orientation)) //ctx->geomAdj.orientation
	
	LL_SetHead(ctx->gobjectq);
	while (gobj = (GEO_OBJECT*)LL_GetNext(ctx->gobjectq))
	{
		
		if (gobj->nTri && (ctx->geomAdj.drawWhat & 0x1)) //ahttri_edge_m == 0 || ctx->tri_edge_mode == 2 ) )
		{
			if (!gobj->v_out) // check if memory has been allocated
			{
				gobj->v_out = malloc(sizeof(MTX_VECTOR) * gobj->nVtx);
			}

			for (j = 0; j < n_faces; ++j)
			{
				// push model view matrix onto stack
				mtx_stack_reset(stack);
				mp = create_polyhedron_matrix(stack, poly->set + j, ctx->geomAdj.orientation);
				mtx_push_matrix(stack, (MTX_MATRIX*)&ctx->matrix);
				mtx_create_translation_matrix(&mtran, ctx->trans[0], ctx->trans[1], ctx->trans[2]);
				mtx_push_matrix(stack, (MTX_MATRIX*)&mtran);
				mp = mtx_get_stack_top(stack);

				// transform all the vertices 
				mtx_vector_multiply(gobj->nVtx, (MTX_VECTOR*)gobj->vtx, gobj->v_out, mp);
				// correctly position the light 
				mtx_vector_multiply(1, (MTX_VECTOR*)&light[0], &light[1], mtran); // need to translate the light
				mtx_vector_multiply(1, (MTX_VECTOR*)&origin[0], &origin[1], mtran);

				for (i = 0, v = gobj->v_out, tri = gobj->tri; i < gobj->nTri; ++i, ++tri)
				{
					// copy vertex data to new variables
					tp[0] = *(GUT_POINT*)v[tri->vtx[0]].data.xyzw;
					tp[1] = *(GUT_POINT*)v[tri->vtx[1]].data.xyzw;
					tp[2] = *(GUT_POINT*)v[tri->vtx[2]].data.xyzw;

					// lighting 
					gut_center_point(&tp[0], &tp[1], &tp[2], &tp[3]);
					gut_vector(&tp[3], &light[1], &vec[0]);
					gut_normalize_vector(&vec[0]);

					// check for special flag to re-normalize
					if (ctx->drawAdj.normalizeFlag)//if (ctx->global_normalize)
					{
						gut_normalize_point(&tp[0]);
						gut_normalize_point(&tp[1]);
						gut_normalize_point(&tp[2]);
					}

					// get color 
					if (ctx->clrCtl.triangle.flag)
					{
						clr = &ctx->clrCtl.triangle.override;
					}
					else if (ctx->clrCtl.autoColor && !ctbl_get_color(gobj->ctT, tri->id, &clr))
					{
					}
					else
					{
						clr = &tri->color;
					}
					ctmp = *clr;

					// determine face normal from cross product & affect lighting
					if (ctx->clrCtl.useLightingFlag)
					{
						gut_vector(&tp[0], &tp[1], &vab);
						gut_vector(&tp[1], &tp[2], &vbc);
						gut_cross_product(&vab, &vbc, &normal);
						gut_normalize_point((GUT_POINT*)&normal);

						gut_dot_product(&vec[0], &normal, &incidenceAngle);

						incidenceAngle += 0.5;
						incidenceAngle = incidenceAngle > 1.0 ? 1.0 : (incidenceAngle < 0 ? 0.0 : incidenceAngle);
						ctmp.r *= incidenceAngle;
						ctmp.g *= incidenceAngle;
						ctmp.b *= incidenceAngle;
					}

					sprintf(style, "style=\"fill:#%02x%02x%02x; \"", (int)(ctmp.r * 255), (int)(ctmp.g * 255), (int)(ctmp.b * 255));

					if (ctx->drawAdj.circleFlag)
					{
						int				n;
						GUT_POINT		poly[64];
						ds_svg_draw_circle_segment(&tp[0],&tp[1],&tp[2],poly,&n, &normal, &origin[1]);
						ctmp = *clr;
						// determine face normal from cross product & affect lighting
						if (ctx->clrCtl.useLightingFlag)
						{
							// lighting 
							gut_vector(&poly[0], &light[1], &vec[0]);
							gut_normalize_vector(&vec[0]);
							gut_dot_product(&vec[0], &normal, &incidenceAngle);

							incidenceAngle += 0.5;

							incidenceAngle = incidenceAngle > 1.0 ? 1.0 : ( incidenceAngle < 0 ? 0.0 : incidenceAngle );
							ctmp.r *= incidenceAngle;
							ctmp.g *= incidenceAngle;
							ctmp.b *= incidenceAngle;
						}
						sprintf(style, "style=\"fill:#%02x%02x%02x; \"", (int)(ctmp.r * 255), (int)(ctmp.g * 255), (int)(ctmp.b * 255));
						for (k = 0; k < n; ++k)
						{
							mtx_vector_multiply(1, (MTX_VECTOR*)&poly[k], &tpp[0], &mview); // mp);
							mtx_vector_multiply(1, (MTX_VECTOR*)&tpp[0], &poly[k], &mproj); // mp);
							poly[k].x /= poly[k].w;
							poly[k].y /= poly[k].w;
							poly[k].z /= poly[k].w;
						}
						sign = (poly[1].x - poly[0].x)*(poly[2].y - poly[0].y) - (poly[1].y - poly[0].y)*(poly[2].x - poly[0].x);
						if (sign < 0.0)
							continue;
						for (k = 0; k < n; ++k)
						{
							poly[k].x = poly[k].x * scale + xoffset;
							poly[k].y = poly[k].y * scale + yoffset;
							poly[k].y = ctx->window.height - poly[k].y;
						}
						svg_start_group(svg, style);
						svg_polygon(svg, poly, n);
						svg_end_group(svg, style);
					}
					else 
					{
						for (k = 0; k < 3; ++k)
						{
							mtx_vector_multiply(1, (MTX_VECTOR*)&tp[k], &tpp[k], &mview); // mp);
							mtx_vector_multiply(1, (MTX_VECTOR*)&tpp[k], &tp[k], &mproj); // mp);
							tp[k].x /= tp[k].w;
							tp[k].y /= tp[k].w;
							tp[k].z /= tp[k].w;
						}
						sign = (tp[1].x - tp[0].x)*(tp[2].y-tp[0].y) - (tp[1].y - tp[0].y)*(tp[2].x-tp[0].x);
						if (sign < 0.0)
							continue;
						for (k = 0; k < 3; ++k)
						{
							tp[k].x = tp[k].x * scale + xoffset;
							tp[k].y = tp[k].y * scale + yoffset;
							tp[k].y = ctx->window.height - tp[k].y;
						}
						svg_start_group(svg, style);
						svg_polygon(svg, tp, 3);
						svg_end_group(svg, style);
					}
				}
			}
		}
		if (gobj->nEdge && (ctx->geomAdj.drawWhat & 0x2)) //ctx->tri_edge_mode == 1 || ctx->tri_edge_mode == 2))
		{
			if (!gobj->v_out) // check if memory has been allocated
			{
				gobj->v_out = malloc(sizeof(MTX_VECTOR) * gobj->nVtx);
			}
			for (j = 0; j < n_faces; ++j)
			{
				// push model view matrix onto stack
				mtx_stack_reset(stack);
				mp = create_polyhedron_matrix(stack, poly->set + j, ctx->geomAdj.orientation);
				mtx_push_matrix(stack, (MTX_MATRIX*)&ctx->matrix);
				mtx_create_translation_matrix(&mtran, ctx->trans[0], ctx->trans[1], ctx->trans[2]);
				mtx_push_matrix(stack, (MTX_MATRIX*)&mtran);
				mp = mtx_get_stack_top(stack);

				// transform all the vertices 
				mtx_vector_multiply(gobj->nVtx, (MTX_VECTOR*)gobj->vtx, gobj->v_out, mp);
				mtx_vector_multiply(1, (MTX_VECTOR*)&origin[0], &origin[1], mp);
				// correctly position the light 
				mtx_vector_multiply(1, (MTX_VECTOR*)&light[0], &light[1], mtran); // need to translate the light

				for (i = 0, v = gobj->v_out, edge = gobj->edge; i < gobj->nEdge; ++i, ++edge)
				{
					// copy vertex data to new variables
					tp[0] = *(GUT_POINT*)v[edge->vtx[0]].data.xyzw;
					tp[1] = *(GUT_POINT*)v[edge->vtx[1]].data.xyzw;

					// get appropriate color 
					if (ctx->clrCtl.line.flag) // override 
					{
						clr = &ctx->clrCtl.line.override;
					}
					else
					{
						ctbl_get_color_new(gobj->ctE, edge->id, ((ctx->geomAdj.drawWhat == 0x3) && (gobj->ctE == gobj->ctT)) ? 1 : 0, &clr);
					}
					ctmp = *clr;

					// create edge triangles but only use first 4
					geo_edge_to_triangles2(&ctx->eAttr, &tp[0], &tp[1], out, ctx->drawAdj.normalizeFlag, &origin[1]);
					out[0].w = out[1].w = out[2].w = out[3].w = out[4].w = out[5].w = out[6].w = out[7].w = 1.0;

					if (ctx->clrCtl.useLightingFlag)
					{
						// lighting 
						gut_mid_point(&tp[0], &tp[1], &tp[3]);
						gut_vector(&tp[3], &light[1], &vec[0]);
						gut_normalize_vector(&vec[0]); // vector to light
						normal.i = tp[3].x - origin[1].x;
						normal.j = tp[3].y - origin[1].y;
						normal.k = tp[3].z - origin[1].z;
						normal.l = tp[3].w - origin[1].w;
						gut_normalize_vector(&normal); // vector tangent to surface

						gut_dot_product(&vec[0], &normal, &incidenceAngle);

						incidenceAngle += 0.5;
						incidenceAngle = incidenceAngle > 1.0 ? 1.0 : (incidenceAngle < 0 ? 0.0 : incidenceAngle);
						ctmp.r *= incidenceAngle;
						ctmp.g *= incidenceAngle;
						ctmp.b *= incidenceAngle;
					}

					sprintf(style, "style=\"fill:#%02x%02x%02x; \"", (int)(ctmp.r * 255), (int)(ctmp.g * 255), (int)(ctmp.b * 255));

					for (k = 0; k < 4; ++k)
					{
						mtx_vector_multiply(1, (MTX_VECTOR*)&out[k], &tpp[0], &mview); // mp);
						mtx_vector_multiply(1, (MTX_VECTOR*)&tpp[0], &tp[k], &mproj); // mp);
						tp[k].x /= tp[k].w;
						tp[k].y /= tp[k].w;
						tp[k].z /= tp[k].w;
					}
					sign = (tp[1].x - tp[0].x)*(tp[2].y - tp[0].y) - (tp[1].y - tp[0].y)*(tp[2].x - tp[0].x);
					if (sign < 0.0)
						continue;
					for (k = 0; k < 4; ++k)
					{
						tp[k].x = tp[k].x * scale + xoffset;
						tp[k].y = tp[k].y * scale + yoffset;
						tp[k].y = ctx->window.height - tp[k].y;
					}
					svg_start_group(svg, style);
					svg_polygon(svg, tp, 4);
					svg_end_group(svg, style);
				}
			}
		}
	}

	// cleanup
	mtx_destroy_stack(stack);
}
*/
/*

// add two additional rotations for orientation adjustment
ROT_PAIR pair_i_01[] = { 3, 0.0, 1, -20.9051574478893, 1, 58.282525588539 };
ROT_PAIR pair_i_02[] = { 3, 180.0, 1, 20.9051574478893 * 2.0, 1, -20.9051574478893, 1, 58.282525588539 };
ROT_PAIR pair_i_03[] = { 3, 180.0, 1, 20.9051574478893 * 2.0, 3, 120.0, 1, -20.9051574478893, 1, 58.282525588539 };
ROT_PAIR pair_i_04[] = { 3, 180.0, 1, 20.9051574478893 * 2.0, 3, 240.0, 1, -20.9051574478893, 1, 58.282525588539 };
ROT_PAIR pair_i_05[] = { 1, -20.9051574478893, 2, 31.7174744114610 + 37.3773681406497, 3, 90.0, 1, -20.9051574478893, 1, 58.282525588539 };
ROT_PAIR pair_i_06[] = { 1, -20.9051574478893, 2, 31.7174744114610 + 37.3773681406497, 3, 210.0, 1, -20.9051574478893, 1, 58.282525588539 };
ROT_PAIR pair_i_07[] = { 1, -20.9051574478893, 2, 31.7174744114610 + 37.3773681406497, 3, 330.0, 1, -20.9051574478893, 1, 58.282525588539 };
ROT_PAIR pair_i_08[] = { 1, -20.9051574478893, 2, -31.7174744114610 - 37.3773681406497, 3, -90.0, 1, -20.9051574478893, 1, 58.282525588539 };
ROT_PAIR pair_i_09[] = { 1, -20.9051574478893, 2, -31.7174744114610 - 37.3773681406497, 3, -210.0, 1, -20.9051574478893, 1, 58.282525588539 };
ROT_PAIR pair_i_10[] = { 1, -20.9051574478893, 2, -31.7174744114610 - 37.3773681406497, 3, -330.0, 1, -20.9051574478893, 1, 58.282525588539 };
ROT_PAIR pair_i_11[] = { 1, 180.0, 1, -20.9051574478893, 1, 58.282525588539 };
ROT_PAIR pair_i_12[] = { 3, 180.0, 1, 20.9051574478893 * 2.0, 1, 180.0, 1, -20.9051574478893, 1, 58.282525588539 };
ROT_PAIR pair_i_13[] = { 3, 180.0, 1, 20.9051574478893 * 2.0, 3, 120.0, 1, 180.0, 1, -20.9051574478893, 1, 58.282525588539 };
ROT_PAIR pair_i_14[] = { 3, 180.0, 1, 20.9051574478893 * 2.0, 3, 240.0, 1, 180.0, 1, -20.9051574478893, 1, 58.282525588539 };
ROT_PAIR pair_i_15[] = { 1, -20.9051574478893, 2, 31.7174744114610 + 37.3773681406497, 3, 90.0, 1, 180.0, 1, -20.9051574478893, 1, 58.282525588539 };
ROT_PAIR pair_i_16[] = { 1, -20.9051574478893, 2, 31.7174744114610 + 37.3773681406497, 3, 210.0, 1, 180.0, 1, -20.9051574478893, 1, 58.282525588539 };
ROT_PAIR pair_i_17[] = { 1, -20.9051574478893, 2, 31.7174744114610 + 37.3773681406497, 3, 330.0, 1, 180.0, 1, -20.9051574478893, 1, 58.282525588539 };
ROT_PAIR pair_i_18[] = { 1, -20.9051574478893, 2, -31.7174744114610 - 37.3773681406497, 3, -90.0, 1, 180.0, 1, -20.9051574478893, 1, 58.282525588539 };
ROT_PAIR pair_i_19[] = { 1, -20.9051574478893, 2, -31.7174744114610 - 37.3773681406497, 3, -210.0, 1, 180.0, 1, -20.9051574478893, 1, 58.282525588539 };
ROT_PAIR pair_i_20[] = { 1, -20.9051574478893, 2, -31.7174744114610 - 37.3773681406497, 3, -330.0, 1, 180.0, 1, -20.9051574478893, 1, 58.282525588539 };

ROT_PAIR pair_o_01[] = { 3, 0.0, 1, -35.264389682754654315377000330019, 1, 90.0 }; // top
ROT_PAIR pair_o_02[] = { 1, 180.0, 1, -35.264389682754654315377000330019, 1, 90.0 }; // bottom
ROT_PAIR pair_o_03[] = { 3, 30.0, 2, 35.264389682754654315377000330019 * 2.0, 3, 30.0, 1, -35.264389682754654315377000330019, 1, 90.0 };
ROT_PAIR pair_o_04[] = { 3, 30.0, 2, 35.264389682754654315377000330019 * 2.0, 3, 30.0 + 120.0, 1, -35.264389682754654315377000330019, 1, 90.0 };
ROT_PAIR pair_o_05[] = { 3, 30.0, 2, 35.264389682754654315377000330019 * 2.0, 3, 30.0 + 240.0, 1, -35.264389682754654315377000330019, 1, 90.0 };
ROT_PAIR pair_o_06[] = { 3, 30.0, 2, 35.264389682754654315377000330019 * 2.0, 2, 180.0, 3, 30.0, 1, -35.264389682754654315377000330019, 1, 90.0 };
ROT_PAIR pair_o_07[] = { 3, 30.0, 2, 35.264389682754654315377000330019 * 2.0, 2, 180.0, 3, 30.0 + 120.0, 1, -35.264389682754654315377000330019, 1, 90.0 };
ROT_PAIR pair_o_08[] = { 3, 30.0, 2, 35.264389682754654315377000330019 * 2.0, 2, 180.0, 3, 30.0 + 240.0, 1, -35.264389682754654315377000330019, 1, 90.0 };

ROT_PAIR pair_t_01[] = { 3, 0.0, 1, -54.735610317245345684622999669981, 1, 125.26438968275465431537700033002 }; // top
ROT_PAIR pair_t_02[] = { 3, 30.0, 2, 54.735610317245345684622999669981 * 2.0, 3, 30.0, 1, -54.735610317245345684622999669981, 1, 125.26438968275465431537700033002 };
ROT_PAIR pair_t_03[] = { 3, 30.0, 2, 54.735610317245345684622999669981 * 2.0, 3, 30.0 + 120.0, 1, -54.735610317245345684622999669981, 1, 125.26438968275465431537700033002 };
ROT_PAIR pair_t_04[] = { 3, 30.0, 2, 54.735610317245345684622999669981 * 2.0, 3, 30.0 + 240.0, 1, -54.735610317245345684622999669981, 1, 125.26438968275465431537700033002 };

ROT_PAIR pair_c_01[] = { 3,   0.0, 1, 45.0, 1, 45.0 }; // top
ROT_PAIR pair_c_02[] = { 2, 180.0, 1, 45.0, 1, 45.0 }; // bottom
ROT_PAIR pair_c_03[] = { 2, -90.0, 1, 45.0, 1, 45.0 }; // left
ROT_PAIR pair_c_04[] = { 1, -90.0, 1, 45.0, 1, 45.0 }; // 
ROT_PAIR pair_c_05[] = { 2,  90.0, 1, 45.0, 1, 45.0 };
ROT_PAIR pair_c_06[] = { 1,  90.0, 1, 45.0, 1, 45.0 };

ROT_SET	icosa[20] = {
	sizeof ( pair_i_01 ) / sizeof ( ROT_PAIR ), pair_i_01, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE, 
	sizeof ( pair_i_02 ) / sizeof ( ROT_PAIR ), pair_i_02, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE, 
	sizeof ( pair_i_03 ) / sizeof ( ROT_PAIR ), pair_i_03, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE, 
	sizeof ( pair_i_04 ) / sizeof ( ROT_PAIR ), pair_i_04, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE, 
	sizeof ( pair_i_05 ) / sizeof ( ROT_PAIR ), pair_i_05, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE, 
	sizeof ( pair_i_06 ) / sizeof ( ROT_PAIR ), pair_i_06, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE, 
	sizeof ( pair_i_07 ) / sizeof ( ROT_PAIR ), pair_i_07, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE, 
	sizeof ( pair_i_08 ) / sizeof ( ROT_PAIR ), pair_i_08, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE, 
	sizeof ( pair_i_09 ) / sizeof ( ROT_PAIR ), pair_i_09, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE, 
	sizeof ( pair_i_10 ) / sizeof ( ROT_PAIR ), pair_i_10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE, 
	sizeof ( pair_i_11 ) / sizeof ( ROT_PAIR ), pair_i_11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE, 
	sizeof ( pair_i_12 ) / sizeof ( ROT_PAIR ), pair_i_12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE, 
	sizeof ( pair_i_13 ) / sizeof ( ROT_PAIR ), pair_i_13, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE, 
	sizeof ( pair_i_14 ) / sizeof ( ROT_PAIR ), pair_i_14, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE, 
	sizeof ( pair_i_15 ) / sizeof ( ROT_PAIR ), pair_i_15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE, 
	sizeof ( pair_i_16 ) / sizeof ( ROT_PAIR ), pair_i_16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE, 
	sizeof ( pair_i_17 ) / sizeof ( ROT_PAIR ), pair_i_17, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE, 
	sizeof ( pair_i_18 ) / sizeof ( ROT_PAIR ), pair_i_18, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE, 
	sizeof ( pair_i_19 ) / sizeof ( ROT_PAIR ), pair_i_19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE, 
	sizeof ( pair_i_20 ) / sizeof ( ROT_PAIR ), pair_i_20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE,
};

ROT_SET	octa[8] = {
	sizeof ( pair_o_01 ) / sizeof ( ROT_PAIR ), pair_o_01, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE,
	sizeof ( pair_o_02 ) / sizeof ( ROT_PAIR ), pair_o_02, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE,
	sizeof ( pair_o_03 ) / sizeof ( ROT_PAIR ), pair_o_03, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE,
	sizeof ( pair_o_04 ) / sizeof ( ROT_PAIR ), pair_o_04, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE,
	sizeof ( pair_o_05 ) / sizeof ( ROT_PAIR ), pair_o_05, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE,
	sizeof ( pair_o_06 ) / sizeof ( ROT_PAIR ), pair_o_06, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE,
	sizeof ( pair_o_07 ) / sizeof ( ROT_PAIR ), pair_o_07, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE,
	sizeof ( pair_o_08 ) / sizeof ( ROT_PAIR ), pair_o_08, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE,
};

ROT_SET	tetra[4] = {
	sizeof ( pair_t_01 ) / sizeof ( ROT_PAIR ), pair_t_01, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE,
	sizeof ( pair_t_02 ) / sizeof ( ROT_PAIR ), pair_t_02, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE,
	sizeof ( pair_t_03 ) / sizeof ( ROT_PAIR ), pair_t_03, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE,
	sizeof ( pair_t_04 ) / sizeof ( ROT_PAIR ), pair_t_04, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE,
};

ROT_SET	cube[6] = {
	sizeof ( pair_c_01 ) / sizeof ( ROT_PAIR ), pair_c_01, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE,
	sizeof ( pair_c_02 ) / sizeof ( ROT_PAIR ), pair_c_02, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE,
	sizeof ( pair_c_03 ) / sizeof ( ROT_PAIR ), pair_c_03, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE,
	sizeof ( pair_c_04 ) / sizeof ( ROT_PAIR ), pair_c_04, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE,
	sizeof ( pair_c_05 ) / sizeof ( ROT_PAIR ), pair_c_05, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE,
	sizeof ( pair_c_06 ) / sizeof ( ROT_PAIR ), pair_c_06, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, GEOMETRY_ORIENTATION_FACE,
};

POLYHEDRON	icosahedron = { icosa, 20 },
			octahedron  = { octa,   8 },
			tetrahedron = { tetra,  4 },
			cubehedron  = { cube,   6 };
POLYHEDRON	*polyhedron[] = { &tetrahedron, &cubehedron, &octahedron, &icosahedron };

// BASE_GEOMETRY	base_geometry = { GEOMETRY_ICOSAHEDRON, 0, &icosahedron, &octahedron, &tetrahedron, &cubehedron };

*/
/*
//-----------------------------------------------------------------------------------
void geo_edge_to_triangles_hex(EDGE_ATTRIBUTES *eattr, VERTEX *a, VERTEX *b, VERTEX *p, GUT_VECTOR *n, int normalize)
//-----------------------------------------------------------------------------------
{
	// create normals
	GUT_VECTOR	z, x, y, h, w, r, tmp;
	GUT_POINT	m;
	double				rad, d;
	int					i;

	gut_mid_point((GUT_POINT*)a, (GUT_POINT*)b, &m);
	gut_normalize_point(&m);
	z = *(GUT_VECTOR*)&m;
	gut_vector((GUT_POINT*)a, (GUT_POINT*)b, &y);
	gut_normalize_vector(&y);
	gut_cross_product(&y, &z, &x);
	gut_normalize_vector(&x);

		// create points 
	gut_distance_from_point_to_point((GUT_POINT*)a, (GUT_POINT*)b, &d);
	rad = d * eattr->width / 2;

	gut_scale_vector(&z, rad*sqrt(3.0)/2.0, &h);
	gut_scale_vector(&x, rad / 2, &w);
	gut_scale_vector(&x, rad, &r);

	gut_add_vector(&h, &w, &tmp);
	gut_point_plus_vector((GUT_POINT*)a, &tmp, &p[0]);
	gut_point_plus_vector((GUT_POINT*)b, &tmp, &p[6]);
	n[0] = tmp;
	gut_normalize_vector(&n[0]);
	gut_point_plus_vector((GUT_POINT*)a, &r, &p[5]);
	gut_point_plus_vector((GUT_POINT*)b, &r, &p[11]);
	n[5] = r;
	gut_normalize_vector(&n[5]);
	gut_reverse_vector(&w);
	gut_add_vector(&h, &w, &tmp);
	gut_point_plus_vector((GUT_POINT*)a, &tmp, &p[1]);
	gut_point_plus_vector((GUT_POINT*)b, &tmp, &p[7]);
	n[1] = tmp;
	gut_normalize_vector(&n[1]);
	gut_reverse_vector(&r);
	gut_point_plus_vector((GUT_POINT*)a, &r, &p[2]);
	gut_point_plus_vector((GUT_POINT*)b, &r, &p[8]);
	n[2] = r;
	gut_normalize_vector(&n[2]);
	gut_reverse_vector(&h);
	gut_add_vector(&h, &w, &tmp);
	gut_point_plus_vector((GUT_POINT*)a, &tmp, &p[3]);
	gut_point_plus_vector((GUT_POINT*)b, &tmp, &p[9]);
	n[3] = tmp;
	gut_normalize_vector(&n[3]);
	gut_reverse_vector(&w);
	gut_add_vector(&h, &w, &tmp);
	gut_point_plus_vector((GUT_POINT*)a, &tmp, &p[4]);
	gut_point_plus_vector((GUT_POINT*)b, &tmp, &p[10]);
	n[4] = tmp;
	gut_normalize_vector(&n[4]);
}
*/
/*
//-----------------------------------------------------------------------------------
void geo_edge_to_triangles(EDGE_ATTRIBUTES *eattr, VERTEX *a, VERTEX *b, VERTEX *out, int normalize)
//-----------------------------------------------------------------------------------
{
	// create new points that represent triangles around edge
	static GUT_POINT	o; 
	static GUT_PLANE	p; //	define GUT_PLANE	p
	static GUT_VECTOR	v; //	define GUT_VECTOR	v
	static double		d;

	gut_distance_from_point_to_point(a, b, &d); 
	geo_plane_from_points(&o, b, a, &p); 
	d *= eattr->width / 2; // scale the edge length
	v.i = p.A * d; // scale the normal vector
	v.j = p.B * d;
	v.k = p.C * d;
	gut_point_plus_vector(a, &v, &out[0]);
	gut_point_plus_vector(b, &v, &out[1]);
	v.i *= -1; // reverse the direction
	v.j *= -1;
	v.k *= -1;
	gut_point_plus_vector(b, &v, &out[2]);
	gut_point_plus_vector(a, &v, &out[3]);
	d = ( 1 - eattr->height );
	geo_scale_pt(&out[0], &out[4], d);
	geo_scale_pt(&out[1], &out[5], d);
	geo_scale_pt(&out[2], &out[6], d);
	geo_scale_pt(&out[3], &out[7], d);
	// triangle out(0,1,2) - top
	// triangle out(2,3,0) - top
	// triangle out(0,4,5) - side
	// triangle out(5,1,0) - side 
	// triangle out(2,6,7) - side 
	// triangle out(7,3,2) - side 
	if (eattr->offset != 1.0)
	{	// move the points radially (in or out)
		d = eattr->offset;
		geo_scale_pt(&out[0], &out[0], d);
		geo_scale_pt(&out[1], &out[1], d);
		geo_scale_pt(&out[2], &out[2], d);
		geo_scale_pt(&out[3], &out[3], d);
		geo_scale_pt(&out[4], &out[4], d);
		geo_scale_pt(&out[5], &out[5], d);
		geo_scale_pt(&out[6], &out[6], d);
		geo_scale_pt(&out[7], &out[7], d);
	}
}
*/
/*
//------------------------------------------------------------------------------------
static void convert_context_2_geo_object(MATRIX_CONTEXT *ctx, GEO_OBJECT_VERTEX *g)
//------------------------------------------------------------------------------------
{
	// create additional vertices (this is a {3,5+}3,0 configuration)
	int			i, j;
	int			vid[7];
	GUT_POINT	mid;
	g->nTri = ctx->nf * 9;
	g->tri = (VTRIANGLE*)malloc(sizeof(VTRIANGLE)*g->nTri);
	for (i = 0, j = 0; i < ctx->nf; ++i, j += 9)
	{
		gut_point_on_line(&ctx->v[ctx->f[i].vid[0]], &ctx->v[ctx->f[i].vid[1]], 1.0 / 3.0, &mid);
		gut_normalize_point(&mid);
		if (insert_v(ctx, &mid, &vid[0]))
			ctx->v[vid[0]] = mid;
		gut_point_on_line(&ctx->v[ctx->f[i].vid[0]], &ctx->v[ctx->f[i].vid[1]], 2.0 / 3.0, &mid);
		gut_normalize_point(&mid);
		if (insert_v(ctx, &mid, &vid[1]))
			ctx->v[vid[1]] = mid;
		gut_point_on_line(&ctx->v[ctx->f[i].vid[1]], &ctx->v[ctx->f[i].vid[2]], 1.0 / 3.0, &mid);
		gut_normalize_point(&mid);
		if (insert_v(ctx, &mid, &vid[2]))
			ctx->v[vid[2]] = mid;
		gut_point_on_line(&ctx->v[ctx->f[i].vid[1]], &ctx->v[ctx->f[i].vid[2]], 2.0 / 3.0, &mid);
		gut_normalize_point(&mid);
		if (insert_v(ctx, &mid, &vid[3]))
			ctx->v[vid[3]] = mid;
		gut_point_on_line(&ctx->v[ctx->f[i].vid[2]], &ctx->v[ctx->f[i].vid[0]], 1.0 / 3.0, &mid);
		gut_normalize_point(&mid);
		if (insert_v(ctx, &mid, &vid[4]))
			ctx->v[vid[4]] = mid;
		gut_point_on_line(&ctx->v[ctx->f[i].vid[2]], &ctx->v[ctx->f[i].vid[0]], 2.0 / 3.0, &mid);
		gut_normalize_point(&mid);
		if (insert_v(ctx, &mid, &vid[5]))
			ctx->v[vid[5]] = mid;
		gut_center_point(&ctx->v[ctx->f[i].vid[0]], &ctx->v[ctx->f[i].vid[1]], &ctx->v[ctx->f[i].vid[2]], &mid);
		gut_normalize_point(&mid);
		if (insert_v(ctx, &mid, &vid[6]))
			ctx->v[vid[6]] = mid;

		g->tri[j + 0].vtx[0] = ctx->f[i].vid[0];	g->tri[j + 0].vtx[1] = vid[0]; g->tri[j + 0].vtx[2] = vid[5];
		g->tri[j + 1].vtx[0] = vid[0];				g->tri[j + 1].vtx[1] = vid[1]; g->tri[j + 1].vtx[2] = vid[6];
		g->tri[j + 2].vtx[0] = vid[5];				g->tri[j + 2].vtx[1] = vid[0]; g->tri[j + 2].vtx[2] = vid[6];

		g->tri[j + 3].vtx[0] = ctx->f[i].vid[1];	g->tri[j + 3].vtx[1] = vid[2]; g->tri[j + 3].vtx[2] = vid[1];
		g->tri[j + 4].vtx[0] = vid[2];				g->tri[j + 4].vtx[1] = vid[3]; g->tri[j + 4].vtx[2] = vid[6];
		g->tri[j + 5].vtx[0] = vid[1];				g->tri[j + 5].vtx[1] = vid[2]; g->tri[j + 5].vtx[2] = vid[6];

		g->tri[j + 6].vtx[0] = ctx->f[i].vid[2];	g->tri[j + 6].vtx[1] = vid[4]; g->tri[j + 6].vtx[2] = vid[3];
		g->tri[j + 7].vtx[0] = vid[4];				g->tri[j + 7].vtx[1] = vid[5]; g->tri[j + 7].vtx[2] = vid[6];
		g->tri[j + 8].vtx[0] = vid[3];				g->tri[j + 8].vtx[1] = vid[4]; g->tri[j + 8].vtx[2] = vid[6];

		== {3,5+}2,0 version
		gut_mid_point(&ctx->v[ctx->f[i].vid[0]], &ctx->v[ctx->f[i].vid[1]], &mid);
		gut_normalize_point(&mid);
		if ( insert_v(ctx, &mid, &vid[0]) )
		ctx->v[vid[0]] = mid;

		gut_mid_point(&ctx->v[ctx->f[i].vid[1]], &ctx->v[ctx->f[i].vid[2]], &mid);
		gut_normalize_point(&mid);
		if ( insert_v(ctx, &mid, &vid[1]) )
		ctx->v[vid[1]] = mid;

		gut_mid_point(&ctx->v[ctx->f[i].vid[2]], &ctx->v[ctx->f[i].vid[0]], &mid);
		gut_normalize_point(&mid);
		if (insert_v(ctx, &mid, &vid[2]))
		ctx->v[vid[2]] = mid;

		g->tri[j+0].vtx[0] = ctx->f[i].vid[0];
		g->tri[j+0].vtx[1] = vid[0];
		g->tri[j+0].vtx[2] = vid[2];

		g->tri[j+1].vtx[0] = ctx->f[i].vid[1];
		g->tri[j+1].vtx[1] = vid[1];
		g->tri[j+1].vtx[2] = vid[0];

		g->tri[j+2].vtx[0] = ctx->f[i].vid[2];
		g->tri[j+2].vtx[1] = vid[2];
		g->tri[j+2].vtx[2] = vid[1];

		g->tri[j+3].vtx[0] = vid[0];
		g->tri[j+3].vtx[1] = vid[1];
		g->tri[j+3].vtx[2] = vid[2];
		
	}
	g->nVtx = ctx->nv;
	g->vtx = (VERTEX*)malloc(sizeof(VERTEX)*g->nVtx * 2);
	g->v_out = g->vtx + ctx->nv;
	for (i = 0; i < ctx->nv; ++i)
	{
		g->vtx[i].x = ctx->v[i].x;
		g->vtx[i].y = ctx->v[i].y;
		g->vtx[i].z = ctx->v[i].z;
		g->vtx[i].w = 1;
	}

	int	i;
	g->nTri = ctx->nf;
	g->nVtx = ctx->nv;
	g->tri = (VTRIANGLE*)malloc(sizeof(VTRIANGLE)*ctx->nf);
	g->vtx = (VERTEX*)malloc(sizeof(VERTEX)*ctx->nv * 2);
	g->v_out = g->vtx + ctx->nv;
	for (i = 0; i < ctx->nf; ++i)
	{
	g->tri[i].vtx[0] = ctx->f[i].vid[0];
	g->tri[i].vtx[1] = ctx->f[i].vid[1];
	g->tri[i].vtx[2] = ctx->f[i].vid[2];
	}
	for (i = 0; i < ctx->nv; ++i)
	{
	g->vtx[i].x = ctx->v[i].x;
	g->vtx[i].y = ctx->v[i].y;
	g->vtx[i].z = ctx->v[i].z;
	g->vtx[i].w = 1;
	}
}
*/
////--------------------------------------------------------------------------------
//int x_dump(CTX *ctx, void **nguap, FILE *fp, float *defaultColor)
////--------------------------------------------------------------------------------
//{
//	FILE	*fp;
//	fp = fopen("c:/TEMP/junk.txt", "w");
//	for (i = 0; i < nf; ++i)
//	{
//		fprintf(fp, "f %3d ", i);
//		for (j = 0; j < of[i].nv; ++j)
//		{
//			fprintf(fp, "%3d ", f[i].vtx[j]);
//		}
//		fprintf(fp, "\n");
//	}
//	fclose(fp);
//}
/*
//--------------------------------------------------------------------------------
int ngua_off_read(CTX *ctx, void **nguap, FILE *fp, float *defaultColor)
//--------------------------------------------------------------------------------
{
	// Consume an OFF file and NOT determine uniqueness for all components
	//
	// Automatically determines zero tolerance for Vertex & Edges from number of 
	// significant digits in first vertex string
	//
	int				mnc = GUA_MAX_NUMBER_COMPONENTS_PER_BLOCK;
	NGUA_DB			*ngua;
	char			*bp;
	GUA_DB			*vdb;			// vertex DB      - unqiue coordinates 
	GUA_DB			*edb;			// edge DB        - unique vertex pairs 
	GUA_DB			*eldb;			// edge length DB - unique edge lengths  
	GUA_DB			*tedb;			// triangle DB    - unique edge length IDs 
	GUA_DB			*tdb;			// triangle DB    - unqiue vertex ID sets 
									//	GUA_DB			*tmpdb;			// used for vertex indices
	int				i, j, k, l;		// counters
	int				vid[32]; 		// unique vertex IDs for current triangle
	int				elid[32];		// unique edge length IDs for current triangle 
	int				eid[32];		// unigue edge by unique vertex ID's for current triangle
	int				tid;			// unique triangle by unique edge lengths
	int				ttid;			// unique triangle by unique vertex IDs
	char			buffer[256];
	GUA_WORD		word[32];
	int				n, m; 			// number of words parsed
	GUA_VDATA		v[32];			// vertex coordinate data for current triangle 
	double			elen[32];		// length of three edges of current triangle
	float			rgb[3];			// color of triangle
	int				explicitColor;	// color flag 
	int				maxVID = 0;
	int				nDigits = 0;
	int				decimal = 0;
	GUT_POINT		vpt[32];
	GUT_POINT		vpt_dup[32];
	GUT_POINT		vtmp[32];		// vertex coordinate data for current triangle 
	int				nv;
	int				nf;
	int				ne;
	GUT_POINT		*ov;
	POLYGON			*of;
	int				*ocf; // off color flag
	int				modulo;
	COLOR			*clr;
	int				nVIndx = 0; // sum of all vertex indices for all faces
	int				*vindx;
	NGUA			*db; 

	if (!fp) return 1; // error 

	bp = fgets(buffer, 256, fp); // read first line
	gua_parse(buffer, &n, word);
	if (!n || strcmp(word[0].buffer, "OFF"))
	{
		rewind(fp); // can't process
		return 1; // error
	}

	// create a NGUA structure and initialize database 
	db = (NGUA_DB*)MALLOC(sizeof(NGUA_DB));
	db->nc = 0;
	db->nci = 0;
	db->mnc = GUA_MAX_NUMBER_COMPONENTS_PER_BLOCK;
	db->head = db->tail = db->ihead = 0;
	blk = (NGUA_BLK*)MALLOC(sizeof(NGUA_BLK));
	blk->nc = 0;
	blk->next = 0;
	blk->data = (VTX_CLR*)MALLOC(sizeof(VTX_CLR)*db->mnc);
	db->head = (void*)blk;
	db->tail = (void*)blk;
	db->max_length = 0;
	db->min_length = 10000000;
	gua_integer_blk_init(&db->ihead, db->mnc); // initialize integer array
	*nguap = (void*)db; // send back to caller

	// create a GUA structure
//	gua = (NGUA_DB*)MALLOC(sizeof(NGUA_DB)); // guap;
//	if (gua == NULL) return 1; // error
//	*guap = (void*)gua; // pass pointer back 

						// create all the attribute databases
//	gua->vdb = gua_db_init(gua_vdata_init, gua_vdata_insert, mnc, xyz_compare);		// vertex DB
//	gua->eldb = gua_db_init(gua_eldata_init, gua_eldata_insert, mnc, el_compare);	// edge by length DB
//	gua->edb = gua_db_init(gua_edata_init, gua_edata_insert, mnc, e_compare);		// edge by unique vertex pairs DB
//	gua->tedb = gua_db_init(gua_tedata_init, gua_tedata_insert, mnc, te_compare);	// triangle by unique edges DB
//	gua->tdb = gua_db_init(gua_tdata_init, gua_tdata_insert, mnc, t_compare);		// triangle by unique vertices DB
//
//																					// local copies re-casted
//	vdb = (GUA_DB*)gua->vdb;
//	eldb = (GUA_DB*)gua->eldb;
//	edb = (GUA_DB*)gua->edb;
//	tedb = (GUA_DB*)gua->tedb;
//	tdb = (GUA_DB*)gua->tdb;

//	// data specific insert functions from each database with correct cast
//	GUA_VDATA_INS  vins = (GUA_VDATA_INS)vdb->insert;
//	GUA_EDATA_INS  eins = (GUA_EDATA_INS)edb->insert;
//	GUA_ELDATA_INS elins = (GUA_ELDATA_INS)eldb->insert;
//	GUA_TEDATA_INS teins = (GUA_TEDATA_INS)tedb->insert;
//	GUA_TDATA_INS  tins = (GUA_TDATA_INS)tdb->insert;

	while (bp = fgets(buffer, 256, fp)) // read a line of 3 vertex coordinates
	{
		gua_parse(buffer, &n, word);
		if (!n)
			continue; // empty or invalid line
		else if (word[0].buffer[0] == '#')
			continue;
		else if (n == 3)
			break;
		else
		{
			rewind(fp);
			return 1;
		}
	}

	nv = atoi(word[0].buffer); // number of vertices
	nf = atoi(word[1].buffer); // number of faces
	ne = atoi(word[2].buffer); // number of edges

	ov = (GUT_POINT*)MALLOC(sizeof(GUT_POINT)*nv);  // array storage for all vertices 
	of = (POLYGON*)MALLOC(sizeof(POLYGON)*nf);		// array storage for polygon faces 
	ocf = (int*)MALLOC(sizeof(int)*nf);				// array of color flags for all polygon faces

													// vertex section 
	for (i = 0; i < nv; ++i)
	{
		bp = fgets(buffer, 256, fp);
		gua_parse(buffer, &n, word);
		if (n < 3) // error
		{
			continue;
		}
		else if (n >= 3)
		{
			if (!decimal)
			{
				int	nDigits;
				vdb->zero = eldb->zero = set_tolerance(word[0].buffer, &decimal, &nDigits);
				vdb->nDigits = eldb->nDigits = nDigits;
			}
			ov[i].x = atof(word[0].buffer);
			ov[i].y = atof(word[1].buffer);
			ov[i].z = atof(word[2].buffer);
			ov[i].w = 1;
			// add to vertex database for unique ID
		}
	}

	// face section 
	for (i = 0; i < nf; ++i)
	{
		bp = fgets(buffer, 256, fp);
		gua_parse(buffer, &n, word);
		if (!n) // error
			continue;
		of[i].nVtx = atoi(word[0].buffer);
		if (n < of[i].nVtx + 1)
			return 1; // errror
		of[i].vtx = gua_integer_array(&ihead, db->mnc, &db->nci, of[i].nVtx);

		for (j = 1, k = 0; j < of[i].nVtx + 1; ++j, ++k)
		{
			of[i].vtx[k] = atoi(word[j].buffer);
		}
		of[i].id = i;
		ocf[i] = 0;
		if (n >= of[i].nVtx + 1 + 3) // color 
		{
			ocf[i] = 1;
			of[i].color.r = atoi(word[5].buffer) / 255.0;
			of[i].color.g = atoi(word[6].buffer) / 255.0;
			of[i].color.b = atoi(word[7].buffer) / 255.0;
		}
	}

	// process all faces 
	for (i = 0; i < nf; ++i)
	{
		modulo = of[i].nVtx;

		// make a copy of all the original vertices
		for (j = 0; j < of[i].nVtx; ++j)
			vpt[j] = ov[of[i].vtx[j]];

		if (!ocf[i])
			of[i].color = *(COLOR*)&defaultColor; // use the default color since it wasn't explicitly defined

												  // transform vertices
		if (ctx->inputTrans.transformFlag)
		{
			mtx_vector_multiply(of[i].nVtx, &vpt, &vtmp, &ctx->inputTrans.matrix[0]);
			for (j = 0; j < of[i].nVtx; ++j)
				vpt[j] = vtmp[j];
		}

		// replicate as required
		m = ctx->inputTrans.mirrorFlag ? 3 : 1;
		n = ctx->inputTrans.replicateFlag ? 3 : 1;
		for (k = 0; k < m; ++k) // mirror loop
		{
			if (!k)
			{
				for (j = 0; j < of[i].nVtx; ++j)
					vpt_dup[j] = vpt[j];
			}
			else
			{	// mirror the x coord
				for (j = 0; j < of[i].nVtx; ++j)
				{
					vpt[j] = vpt_dup[j]; vpt[j].x *= -1;
				}
			}

			for (j = 0; j < n; ++j) // z rotations
			{
				for (l = 0; l < of[i].nVtx; ++l)
				{
					v[l].p = vpt[l]; // copy coordinate data into node structure
					of[i].vtx[l] = vid[l] = vins((void*)vdb, &v[l]); // insert into tree
					++vdb->nProcessed;
				}

				// for each vertex pair determine the unique edge length id  
				for (l = 0; l < of[i].nVtx; ++l)
				{
					elid[l] = elins((void*)eldb, &v[l + 0], &v[(l + 1) % modulo], &elen[l]);
					++eldb->nProcessed;
				}

				// for each vertex pair (3 of them) determine the unique edge id 
				// add edges by vertex ID's
				{
					int	vuid[2], elnid;
					for (l = 0; l < of[i].nVtx; ++l)
					{
						vuid[0] = vid[l];
						vuid[1] = vid[(l + 1) % modulo];
						elnid = elid[l];
						++edb->nProcessed;
						eid[l] = eins((void*)edb, vuid, elnid); // save the vertex pair along with the edge length id 
					}
				}

				++tedb->nProcessed;
				tid = teins((void*)tedb, elid, of[i].nVtx); // use array of edge length IDs 
				++tdb->nProcessed;
				ttid = tins((void*)tdb, vid, of[i].nVtx, tid, &of[i].color); // use array of unique vertex IDs 

				if (ctx->inputTrans.replicateFlag && j < 2)
				{	// perform rotation transformation on coordinate data
					mtx_vector_multiply(of[i].nVtx, &vpt, &vtmp, &ctx->inputTrans.matrix[0]);
					for (j = 0; j < of[i].nVtx; ++j)
						vpt[j] = vtmp[j];

				}
			}
		}
	}

	// remove temp memory
	FREE(ov);
	FREE(ocf);
	FREE(of);

	return 0; // success
}
*/
/*
//--------------------------------------------------------------------------------
int ngua_off_read(CTX *ctx, void **nguap, FILE *fp, float *defaultColor)
//--------------------------------------------------------------------------------
{
	NGUA_BLK	*blk;
	NGUA_DB		*db;
	GUA_WORD	word[32];
	int			n, m;
	int			i, j, k;
	char		buffer[256];
	VTX_CLR		*vc;
	VTX_CLR		vct;
	VERTEX		vpt[32], vpt_dup[32];
	VERTEX		vtmp[32];
	double		length;

	// initialize database 
	db = (NGUA_DB*)MALLOC(sizeof(NGUA_DB));
	db->nc = 0;
	db->nci = 0;
	db->mnc = GUA_MAX_NUMBER_COMPONENTS_PER_BLOCK;
	db->head = db->tail = db->ihead = 0;
	blk = (NGUA_BLK*)MALLOC(sizeof(NGUA_BLK));
	blk->nc = 0;
	blk->next = 0;
	blk->data = (VTX_CLR*)MALLOC(sizeof(VTX_CLR)*db->mnc);
	db->head = (void*)blk;
	db->tail = (void*)blk;
	db->max_length = 0;
	db->min_length = 10000000;
	gua_integer_blk_init(&db->ihead, db->mnc); // initialize integer array
	*nguap = (void*)db; // send back to caller

	while (fgets(buffer, 256, fp))
	{
		// parse out the number of triangles
		gua_parse(buffer, &n, word);

		if (n < 9)
			continue; // not enough data

					  // read the data
		for (i = 0, j = 0; i < 3; ++i, j += 3)
		{
			vpt[i].x = atof(word[j + 0].buffer);
			vpt[i].y = atof(word[j + 1].buffer);
			vpt[i].z = atof(word[j + 2].buffer);
			vpt[i].w = 1;
		}

		// determine edge lengths
		gut_distance_from_point_to_point(&vpt[0], &vpt[1], &length);
		if (length < db->min_length) db->min_length = length;
		if (length > db->max_length) db->max_length = length;
		gut_distance_from_point_to_point(&vpt[1], &vpt[2], &length);
		if (length < db->min_length) db->min_length = length;
		if (length > db->max_length) db->max_length = length;
		gut_distance_from_point_to_point(&vpt[2], &vpt[0], &length);
		if (length < db->min_length) db->min_length = length;
		if (length > db->max_length) db->max_length = length;

		if (n >= 12) // color included
		{
			vct.color.r = atof(word[9].buffer);
			vct.color.g = atof(word[10].buffer);
			vct.color.b = atof(word[11].buffer);
		}
		else
		{
			vct.color.r = defaultColor[0]; // default
			vct.color.g = defaultColor[1]; // default
			vct.color.b = defaultColor[2]; // default
		}

		// transform vertices
		if (ctx->inputTrans.transformFlag)
		{
			mtx_vector_multiply(3, &vpt, &vtmp, &ctx->inputTrans.matrix[0]);
			vpt[0] = vtmp[0];
			vpt[1] = vtmp[1];
			vpt[2] = vtmp[2];
		}

		// replicate as required
		m = ctx->inputTrans.mirrorFlag ? 2 : 1;
		n = ctx->inputTrans.replicateFlag ? 3 : 1;
		for (k = 0; k < m; ++k) // mirrorFlag
		{
			if (!k) // make a copy of the original data and switch order
			{
				vpt_dup[0] = vpt[0];
				vpt_dup[1] = vpt[2];
				vpt_dup[2] = vpt[1];
			}
			else
			{	// mirror the x coord
				vpt[0] = vpt_dup[0]; vpt[0].x *= -1;
				vpt[1] = vpt_dup[1]; vpt[1].x *= -1;
				vpt[2] = vpt_dup[2]; vpt[2].x *= -1;
			}

			for (j = 0; j < n; ++j)
			{
				if (blk->nc == db->mnc)
				{
					blk = (NGUA_BLK*)MALLOC(sizeof(NGUA_BLK));
					blk->nc = 0;
					blk->next = 0;
					blk->data = (VTX_CLR*)MALLOC(sizeof(VTX_CLR)*db->mnc);
					((NGUA_BLK*)db->tail)->next = blk;
					db->tail = (void*)blk;
				}
				vc = (VTX_CLR*)blk->data + blk->nc++;
				++db->nc;

				vc->color = vct.color;

				for (i = 0; i < 3; ++i)
				{
					vc->vertex[i] = vpt[i]; // copy coordinate data into node structure
				}

				if (ctx->inputTrans.replicateFlag && j < 2)
				{	// perform rotation transformation on coordinate data
					mtx_vector_multiply(3, &vpt[0], &vtmp[0], &ctx->inputTrans.matrix[1]); // 120 degree rotation of z axis
					vpt[0] = vtmp[0];
					vpt[1] = vtmp[1];
					vpt[2] = vtmp[2];
				}
			}
		}
	}

	return 0;
}
*/
/*
//-----------------------------------------------------------------------------
void draw_geometry_new(CTX *ctx)
//-----------------------------------------------------------------------------
{
	int			i, j, reverseOrder;
	MTX_MATRIX	*mp;
	MTX_VECTOR	*v;
	COLOR		*c;
	GUT_POINT	pa, pb, pc;
	GUT_VECTOR	vab, vbc, normal;
	GEO_OBJECT	*gobj;
	TRIANGLE	*tri;
	COLOR		*clr;
	EDGE		*edge;
	GUT_POINT	out[12]; // edge triangle points 
	static int	max_vertex;
	static GUT_POINT origin = { 0,0,0,1 };

	draw_geometry_poly(ctx);
	return;

	if (ctx->drawAdj.axiiFlag)
	{
		//		glBegin(GL_LINES);
		glBegin(GL_TRIANGLES);
		{
			double	width = ctx->eAttr.width;
			COLOR		red = { 1,0,0 }, grn = { 0,1,0 }, blu = { 0,0,1 };
			GUT_VECTOR	normal[6], x = { 1,0,0 }, y = { 0, 1, 0 }, z = { 0,0,1 };
			// copy vertex data to new variables
			ctx->eAttr.width = 0.01;
			pa.x = -1.05; pa.y = 0; pa.z = 0; pb.x = 1.05; pb.y = 0; pb.z = 0;
			clr = &red;
			x.i *= -1.0;
			geo_edge_to_triangles_hex_axii(&ctx->eAttr, &pa, &pb, out, &y, &x, &z, normal, ctx->drawAdj.normalizeFlag, &origin);
			draw_triangle_hex(ctx, &out, &normal, clr, 0, 6, 7);
			draw_triangle_hex(ctx, &out, &normal, clr, 7, 1, 0);
			draw_triangle_hex(ctx, &out, &normal, clr, 1, 7, 8);
			draw_triangle_hex(ctx, &out, &normal, clr, 8, 2, 1);
			draw_triangle_hex(ctx, &out, &normal, clr, 2, 8, 9);
			draw_triangle_hex(ctx, &out, &normal, clr, 9, 3, 2);
			draw_triangle_hex(ctx, &out, &normal, clr, 3, 9, 10);
			draw_triangle_hex(ctx, &out, &normal, clr, 10, 4, 3);
			draw_triangle_hex(ctx, &out, &normal, clr, 4, 10, 11);
			draw_triangle_hex(ctx, &out, &normal, clr, 11, 5, 4);
			draw_triangle_hex(ctx, &out, &normal, clr, 5, 11, 6);
			draw_triangle_hex(ctx, &out, &normal, clr, 6, 0, 5);
			x.i *= -1.0;
			pa.x = 0; pa.y = -1.05; pa.z = 0; pb.x = 0; pb.y = 1.05; pb.z = 0;
			clr = &grn;
			geo_edge_to_triangles_hex_axii(&ctx->eAttr, &pa, &pb, out, &x, &y, &z, normal, ctx->drawAdj.normalizeFlag, &origin);
			draw_triangle_hex(ctx, &out, &normal, clr, 0, 6, 7);
			draw_triangle_hex(ctx, &out, &normal, clr, 7, 1, 0);
			draw_triangle_hex(ctx, &out, &normal, clr, 1, 7, 8);
			draw_triangle_hex(ctx, &out, &normal, clr, 8, 2, 1);
			draw_triangle_hex(ctx, &out, &normal, clr, 2, 8, 9);
			draw_triangle_hex(ctx, &out, &normal, clr, 9, 3, 2);
			draw_triangle_hex(ctx, &out, &normal, clr, 3, 9, 10);
			draw_triangle_hex(ctx, &out, &normal, clr, 10, 4, 3);
			draw_triangle_hex(ctx, &out, &normal, clr, 4, 10, 11);
			draw_triangle_hex(ctx, &out, &normal, clr, 11, 5, 4);
			draw_triangle_hex(ctx, &out, &normal, clr, 5, 11, 6);
			draw_triangle_hex(ctx, &out, &normal, clr, 6, 0, 5);
			pa.x = 0; pa.y = 0; pa.z = -1.05; pb.x = 0; pb.y = 0; pb.z = 1.05;
			clr = &blu;
			geo_edge_to_triangles_hex_axii(&ctx->eAttr, &pa, &pb, out, &y, &z, &x, normal, ctx->drawAdj.normalizeFlag, &origin);
			draw_triangle_hex(ctx, &out, &normal, clr, 0, 6, 7);
			draw_triangle_hex(ctx, &out, &normal, clr, 7, 1, 0);
			draw_triangle_hex(ctx, &out, &normal, clr, 1, 7, 8);
			draw_triangle_hex(ctx, &out, &normal, clr, 8, 2, 1);
			draw_triangle_hex(ctx, &out, &normal, clr, 2, 8, 9);
			draw_triangle_hex(ctx, &out, &normal, clr, 9, 3, 2);
			draw_triangle_hex(ctx, &out, &normal, clr, 3, 9, 10);
			draw_triangle_hex(ctx, &out, &normal, clr, 10, 4, 3);
			draw_triangle_hex(ctx, &out, &normal, clr, 4, 10, 11);
			draw_triangle_hex(ctx, &out, &normal, clr, 11, 5, 4);
			draw_triangle_hex(ctx, &out, &normal, clr, 5, 11, 6);
			draw_triangle_hex(ctx, &out, &normal, clr, 6, 0, 5);
			ctx->eAttr.width = width;
		}
		glEnd();
	}

	geometry_draw_init(ctx);
	while (geometry_next_draw_transform(ctx, &mp, &reverseOrder, ctx->geomAdj.orientation)) //ctx->geomAdj.orientation
	{
		LL_SetHead(ctx->gobjectq);
		while (gobj = (GEO_OBJECT*)LL_GetNext(ctx->gobjectq))
		{
			// transform the vertices once
			if (!gobj->v_out) // check if memory has been allocated
			{
				gobj->v_out = malloc(sizeof(MTX_VECTOR) * gobj->nVtx);
			}
			mtx_vector_multiply(gobj->nVtx, (MTX_VECTOR*)gobj->vtx, gobj->v_out, mp);

			// render vertices if required
			if (ctx->geomAdj.drawWhat & 0x4) //ctx->renderVertex.vtxObjFlag)
			{
				VERTEX	*vs = ctx->renderVertex.vtxObj.vtx, *vd = ctx->renderVertex.vtxObj.v_out;
				VTRIANGLE	*vt;
				double	scale = ctx->renderVertex.scale * ctx->eAttr.maxLength; // 0.03;
				clr = &ctx->renderVertex.clr;

				for (i = 0, v = gobj->v_out; i < gobj->nVtx; ++i, ++tri)
				{
					// check for special flag to re-normalize
					if (ctx->drawAdj.normalizeFlag)
						gut_normalize_point(&v[i]);

					// modify vertex object coordinates to be at this global position
					for (j = 0; j < ctx->renderVertex.vtxObj.nVtx; ++j)
					{
						vd[j].x = vs[j].x * scale + v[i].data.xyzw[0];
						vd[j].y = vs[j].y * scale + v[i].data.xyzw[1];
						vd[j].z = vs[j].z * scale + v[i].data.xyzw[2];
					}
					glBegin(GL_TRIANGLES);
					for (j = 0, vt = ctx->renderVertex.vtxObj.tri; j < ctx->renderVertex.vtxObj.nTri; ++j, ++vt)
					{
						glNormal3f((float)vs[vt->vtx[0]].x * 3, (float)vs[vt->vtx[0]].y * 3, (float)vs[vt->vtx[0]].z * 3);
						glColor3f((float)clr->r, (float)clr->g, (float)clr->b);
						glVertex3f((float)vd[vt->vtx[0]].x, (float)vd[vt->vtx[0]].y, (float)vd[vt->vtx[0]].z);// ++v;

						glNormal3f((float)vs[vt->vtx[1]].x * 3, (float)vs[vt->vtx[1]].y * 3, (float)vs[vt->vtx[1]].z * 3);
						glColor3f((float)clr->r, (float)clr->g, (float)clr->b);
						glVertex3f((float)vd[vt->vtx[1]].x, (float)vd[vt->vtx[1]].y, (float)vd[vt->vtx[1]].z);// ++v;

						glNormal3f((float)vs[vt->vtx[2]].x * 3, (float)vs[vt->vtx[2]].y * 3, (float)vs[vt->vtx[2]].z * 3);
						glColor3f((float)clr->r, (float)clr->g, (float)clr->b);
						glVertex3f((float)vd[vt->vtx[2]].x, (float)vd[vt->vtx[2]].y, (float)vd[vt->vtx[2]].z);// ++v;
					}
					glEnd();
//
//					// modify vertex object coordinates to be at this global position
//					for (j = 0; j < ctx->renderVertex.vtxObj.nVtx; ++j)
//					{
//						glColor3f((float)clr->r, (float)clr->g, (float)clr->b);
//						glTranslatef(v[i].data.xyzw[0], v[i].data.xyzw[1], v[i].data.xyzw[2]);
////						glutSolidSphere((double)0.01, (GLint)10, (GLint)10);
//						glutSolidIcosahedron();
//					}
//
				}
			}

			if (gobj->nTri && (ctx->geomAdj.drawWhat & 0x1)) //ahttri_edge_m == 0 || ctx->tri_edge_mode == 2 ) )
			{
				glBegin(GL_TRIANGLES);

				for (i = 0, v = gobj->v_out, tri = gobj->tri; i < gobj->nTri; ++i, ++tri)
				{
					// copy vertex data to new variables
					if (!reverseOrder)
					{
						pa.x = v[tri->vtx[0]].data.xyzw[0];
						pa.y = v[tri->vtx[0]].data.xyzw[1];
						pa.z = v[tri->vtx[0]].data.xyzw[2];
						pb.x = v[tri->vtx[1]].data.xyzw[0];
						pb.y = v[tri->vtx[1]].data.xyzw[1];
						pb.z = v[tri->vtx[1]].data.xyzw[2];
						pc.x = v[tri->vtx[2]].data.xyzw[0];
						pc.y = v[tri->vtx[2]].data.xyzw[1];
						pc.z = v[tri->vtx[2]].data.xyzw[2];
					}
					else
					{
						// copy vertex data to new variables
						pa.x = v[tri->vtx[2]].data.xyzw[0];
						pa.y = v[tri->vtx[2]].data.xyzw[1];
						pa.z = v[tri->vtx[2]].data.xyzw[2];
						pb.x = v[tri->vtx[1]].data.xyzw[0];
						pb.y = v[tri->vtx[1]].data.xyzw[1];
						pb.z = v[tri->vtx[1]].data.xyzw[2];
						pc.x = v[tri->vtx[0]].data.xyzw[0];
						pc.y = v[tri->vtx[0]].data.xyzw[1];
						pc.z = v[tri->vtx[0]].data.xyzw[2];
					}

					// check for special flag to re-normalize
					if (ctx->drawAdj.normalizeFlag)//if (ctx->global_normalize)
					{
						gut_normalize_point(&pa);
						gut_normalize_point(&pb);
						gut_normalize_point(&pc);
					}

					// determine face normal from cross product
					gut_vector(&pa, &pb, &vab);
					gut_vector(&pb, &pc, &vbc);
					gut_cross_product(&vab, &vbc, &normal);
					gut_normalize_point((GUT_POINT*)&normal);

					glNormal3f((float)normal.i * 3, (float)normal.j * 3, (float)normal.k * 3);

					if (ctx->clrCtl.triangle.flag) // override 
						clr = &ctx->clrCtl.triangle.override;
					else if (ctx->clrCtl.autoColor)
						ctbl_get_color(gobj->ctT, tri->id, &clr);
					else
						clr = &tri->color; // glColor3f((float)tri->color.r, (float)tri->color.g, (float)tri->color.b);

					if (ctx->drawAdj.circleFlag)
					{
						draw_circle_segment(&pa, &pb, &pc, &normal, clr);
					}
					else
					{
						glColor3f((float)clr->r, (float)clr->g, (float)clr->b);
						glVertex3f((float)pa.x, (float)pa.y, (float)pa.z);// ++v;
						glVertex3f((float)pb.x, (float)pb.y, (float)pb.z);// ++v;
						glVertex3f((float)pc.x, (float)pc.y, (float)pc.z);// ++v;
					}
				}

				glEnd();
			}
			if (gobj->nEdge && (ctx->geomAdj.drawWhat & 0x2)) //ctx->tri_edge_mode == 1 || ctx->tri_edge_mode == 2))
			{
				glBegin(GL_TRIANGLES);

				if (ctx->eAttr.type == GEOMETRY_EDGE_SQUARE)
				{
					for (i = 0, v = gobj->v_out, edge = gobj->edge; i < gobj->nEdge; ++i, ++edge)
					{
						// copy vertex data to new variables
						pa.x = v[edge->vtx[0]].data.xyzw[0];
						pa.y = v[edge->vtx[0]].data.xyzw[1];
						pa.z = v[edge->vtx[0]].data.xyzw[2];
						pb.x = v[edge->vtx[1]].data.xyzw[0];
						pb.y = v[edge->vtx[1]].data.xyzw[1];
						pb.z = v[edge->vtx[1]].data.xyzw[2];

						// check for special flag to re-normalize
						if (ctx->drawAdj.normalizeFlag)//if (ctx->global_normalize)
						{
							gut_normalize_point(&pa);
							gut_normalize_point(&pb);
						}
						
						geo_edge_to_triangles(&ctx->eAttr, &pa, &pb, out, ctx->drawAdj.normalizeFlag, &origin);

						if (ctx->clrCtl.line.flag) // override 
							clr = &ctx->clrCtl.line.override;
						// if drawing both triangles and edges and they share a common color table reverse the color ID
						else if (ctx->clrCtl.reverseColorFlag)
							ctbl_get_color_new(gobj->ctE, edge->id, ((ctx->geomAdj.drawWhat | GEOMETRY_DRAW_TRIANGLES) && (gobj->ctE == gobj->ctT)) ? 1 : 0, &clr);
//						ctbl_get_color_new(gobj->ctE, edge->id, ((ctx->geomAdj.drawWhat == 0x3) && (gobj->ctE == gobj->ctT)) ? 1 : 0, &clr);
						else
							ctbl_get_color(gobj->ctE, edge->id, &clr);

						draw_triangle(ctx, &out[0], &out[1], &out[2], clr); //gobj->clrE, edge->id);
						draw_triangle(ctx, &out[2], &out[3], &out[0], clr); //gobj->clrE, edge->id);
						draw_triangle(ctx, &out[0], &out[1], &out[2], clr); //gobj->clrE, edge->id);
						draw_triangle(ctx, &out[2], &out[3], &out[0], clr); //gobj->clrE, edge->id);
						if (ctx->eAttr.height != 0.0)
						{
							draw_triangle(ctx, &out[0], &out[4], &out[5], clr); //, gobj->clrE, edge->id);
							draw_triangle(ctx, &out[5], &out[1], &out[0], clr); //, gobj->clrE, edge->id);
							draw_triangle(ctx, &out[2], &out[6], &out[7], clr); //, gobj->clrE, edge->id);
							draw_triangle(ctx, &out[7], &out[3], &out[2], clr); //, gobj->clrE, edge->id);
						}
					}
				}
				else
				{
					GUT_VECTOR	normal[6];

					for (i = 0, v = gobj->v_out, edge = gobj->edge; i < gobj->nEdge; ++i, ++edge)
					{
						// copy vertex data to new variables
						pa.x = v[edge->vtx[0]].data.xyzw[0];
						pa.y = v[edge->vtx[0]].data.xyzw[1];
						pa.z = v[edge->vtx[0]].data.xyzw[2];
						pb.x = v[edge->vtx[1]].data.xyzw[0];
						pb.y = v[edge->vtx[1]].data.xyzw[1];
						pb.z = v[edge->vtx[1]].data.xyzw[2];

						// check for special flag to re-normalize
						if (ctx->drawAdj.normalizeFlag)//if (ctx->global_normalize)
						{
							gut_normalize_point(&pa);
							gut_normalize_point(&pb);
						}

						geo_edge_to_triangles_hex(&ctx->eAttr, &pa, &pb, out, normal, ctx->drawAdj.normalizeFlag, &origin);

						if (ctx->clrCtl.line.flag) // override 
							clr = &ctx->clrCtl.line.override;
						// if drawing both triangles and edges and they share a common color table reverse the color ID
						else if (ctx->clrCtl.reverseColorFlag)
							ctbl_get_color_new(gobj->ctE, edge->id, ((ctx->geomAdj.drawWhat | GEOMETRY_DRAW_TRIANGLES) && (gobj->ctE == gobj->ctT)) ? 1 : 0, &clr);
						// ctbl_get_color_new(gobj->ctE, edge->id, ((ctx->geomAdj.drawWhat == 0x3) && (gobj->ctE == gobj->ctT)) ? 1 : 0, &clr);
						else
							ctbl_get_color(gobj->ctE, edge->id, &clr);

						draw_triangle_hex(ctx, &out, &normal, clr, 0, 6, 7);
						draw_triangle_hex(ctx, &out, &normal, clr, 7, 1, 0);

						draw_triangle_hex(ctx, &out, &normal, clr, 1, 7, 8);
						draw_triangle_hex(ctx, &out, &normal, clr, 8, 2, 1);

						draw_triangle_hex(ctx, &out, &normal, clr, 2, 8, 9);
						draw_triangle_hex(ctx, &out, &normal, clr, 9, 3, 2);

						draw_triangle_hex(ctx, &out, &normal, clr, 3, 9, 10);
						draw_triangle_hex(ctx, &out, &normal, clr, 10, 4, 3);

						draw_triangle_hex(ctx, &out, &normal, clr, 4, 10, 11);
						draw_triangle_hex(ctx, &out, &normal, clr, 11, 5, 4);

						draw_triangle_hex(ctx, &out, &normal, clr, 5, 11, 6);
						draw_triangle_hex(ctx, &out, &normal, clr, 6, 0, 5);
					}
				}
				glEnd();
			}
		}
	}

	glBegin(GL_TRIANGLES);

	if (ctx->drawAdj.clipFlag && ctx->drawAdj.clipVisibleFlag)
	{
		glNormal3f((float)0, (float)0, (float)3);

		glColor3f((float)1, (float)1, (float)0);
		glVertex3f((float)1.05, (float)-1.05, (float)ctx->drawAdj.clipZValue);
		glVertex3f((float)1.05, (float)1.05, (float)ctx->drawAdj.clipZValue);
		glVertex3f((float)-1.05, (float)1.05, (float)ctx->drawAdj.clipZValue);

		glVertex3f((float)-1.05, (float)1.05, (float)ctx->drawAdj.clipZValue);
		glVertex3f((float)-1.05, (float)-1.05, (float)ctx->drawAdj.clipZValue);
		glVertex3f((float)1.05, (float)-1.05, (float)ctx->drawAdj.clipZValue);
	}

	// cleanup
	//	mtx_destroy_stack(stack);

	glEnd();
}
*/

/*
//-----------------------------------------------------------------------------
void draw_geometry_poly_old(CTX *ctx)
//-----------------------------------------------------------------------------
{
	int			i, j, k, reverseOrder;
	MTX_MATRIX	*mp;
	MTX_VECTOR	*v;
	COLOR		*c;
	GUT_POINT	p[32]; // pa, pb, pc;
	GUT_VECTOR	vab, vbc, normal;
	POLYHEDRON	*poly;
	GEO_OBJECT	*gobj;
	//	TRIANGLE	*tri;
	POLYGON		*tri;
	COLOR		*clr;
	EDGE		*edge;
	GUT_POINT	out[12]; // edge triangle points 
	static int	max_vertex;
	static GUT_POINT origin = { 0,0,0,1 };

	if (ctx->drawAdj.axiiFlag)
	{
		//		glBegin(GL_LINES);
		glBegin(GL_TRIANGLES);
		{
			double	width = ctx->eAttr.width;
			COLOR		red = { 1,0,0 }, grn = { 0,1,0 }, blu = { 0,0,1 };
			GUT_VECTOR	normal[6], x = { 1,0,0 }, y = { 0, 1, 0 }, z = { 0,0,1 };
			// copy vertex data to new variables
			ctx->eAttr.width = 0.01;
			p[0].x = -1.05; p[0].y = 0; p[0].z = 0; p[1].x = 1.05; p[1].y = 0; p[1].z = 0;
			clr = &red;
			x.i *= -1.0;
			geo_edge_to_triangles_hex_axii(&ctx->eAttr, &p[0], &p[1], out, &y, &x, &z, normal, ctx->drawAdj.normalizeFlag, &origin);
			draw_triangle_hex(ctx, &out, &normal, clr, 0, 6, 7);
			draw_triangle_hex(ctx, &out, &normal, clr, 7, 1, 0);
			draw_triangle_hex(ctx, &out, &normal, clr, 1, 7, 8);
			draw_triangle_hex(ctx, &out, &normal, clr, 8, 2, 1);
			draw_triangle_hex(ctx, &out, &normal, clr, 2, 8, 9);
			draw_triangle_hex(ctx, &out, &normal, clr, 9, 3, 2);
			draw_triangle_hex(ctx, &out, &normal, clr, 3, 9, 10);
			draw_triangle_hex(ctx, &out, &normal, clr, 10, 4, 3);
			draw_triangle_hex(ctx, &out, &normal, clr, 4, 10, 11);
			draw_triangle_hex(ctx, &out, &normal, clr, 11, 5, 4);
			draw_triangle_hex(ctx, &out, &normal, clr, 5, 11, 6);
			draw_triangle_hex(ctx, &out, &normal, clr, 6, 0, 5);
			x.i *= -1.0;
			p[0].x = 0; p[0].y = -1.05; p[0].z = 0; p[1].x = 0; p[1].y = 1.05; p[1].z = 0;
			clr = &grn;
			geo_edge_to_triangles_hex_axii(&ctx->eAttr, &p[0], &p[1], out, &x, &y, &z, normal, ctx->drawAdj.normalizeFlag, &origin);
			draw_triangle_hex(ctx, &out, &normal, clr, 0, 6, 7);
			draw_triangle_hex(ctx, &out, &normal, clr, 7, 1, 0);
			draw_triangle_hex(ctx, &out, &normal, clr, 1, 7, 8);
			draw_triangle_hex(ctx, &out, &normal, clr, 8, 2, 1);
			draw_triangle_hex(ctx, &out, &normal, clr, 2, 8, 9);
			draw_triangle_hex(ctx, &out, &normal, clr, 9, 3, 2);
			draw_triangle_hex(ctx, &out, &normal, clr, 3, 9, 10);
			draw_triangle_hex(ctx, &out, &normal, clr, 10, 4, 3);
			draw_triangle_hex(ctx, &out, &normal, clr, 4, 10, 11);
			draw_triangle_hex(ctx, &out, &normal, clr, 11, 5, 4);
			draw_triangle_hex(ctx, &out, &normal, clr, 5, 11, 6);
			draw_triangle_hex(ctx, &out, &normal, clr, 6, 0, 5);
			p[0].x = 0; p[0].y = 0; p[0].z = -1.05; p[1].x = 0; p[1].y = 0; p[1].z = 1.05;
			clr = &blu;
			geo_edge_to_triangles_hex_axii(&ctx->eAttr, &p[0], &p[1], out, &y, &z, &x, normal, ctx->drawAdj.normalizeFlag, &origin);
			draw_triangle_hex(ctx, &out, &normal, clr, 0, 6, 7);
			draw_triangle_hex(ctx, &out, &normal, clr, 7, 1, 0);
			draw_triangle_hex(ctx, &out, &normal, clr, 1, 7, 8);
			draw_triangle_hex(ctx, &out, &normal, clr, 8, 2, 1);
			draw_triangle_hex(ctx, &out, &normal, clr, 2, 8, 9);
			draw_triangle_hex(ctx, &out, &normal, clr, 9, 3, 2);
			draw_triangle_hex(ctx, &out, &normal, clr, 3, 9, 10);
			draw_triangle_hex(ctx, &out, &normal, clr, 10, 4, 3);
			draw_triangle_hex(ctx, &out, &normal, clr, 4, 10, 11);
			draw_triangle_hex(ctx, &out, &normal, clr, 11, 5, 4);
			draw_triangle_hex(ctx, &out, &normal, clr, 5, 11, 6);
			draw_triangle_hex(ctx, &out, &normal, clr, 6, 0, 5);
			ctx->eAttr.width = width;
		}
		glEnd();
	}

	geometry_draw_init(ctx);
	while (geometry_next_draw_transform(ctx, &mp, &reverseOrder, ctx->geomAdj.orientation)) //ctx->geomAdj.orientation
	{
		LL_SetHead(ctx->gobjectq);
		while (gobj = (GEO_OBJECT*)LL_GetNext(ctx->gobjectq))
		{
			if (!gobj->v_out) gobj->v_out = malloc(sizeof(MTX_VECTOR) * gobj->nVtx); // alocate memory once 

			mtx_vector_multiply(gobj->nVtx, (MTX_VECTOR*)gobj->vtx, gobj->v_out, mp); // transform the vertices once

			if (gobj->nTri && (ctx->geomAdj.drawWhat & 0x1)) // faces
			{
				tri = gobj->tri;

				for (i = 0, v = gobj->v_out; i < gobj->nTri; ++i, ++tri)
				{
					switch (tri->nVtx) {
					case 1: // degenerate vertices
						break;
					case 2: // degenerate edges
						break;
					default: // polygon faces
						;
					}

					// copy vertex data to new variables
					if (!reverseOrder)
					{
						for (j = 0; j<tri->nVtx; ++j)
							p[j] = *(GUT_POINT*)&v[tri->vtx[j]].data.xyzw[0];
					}
					else
					{
						for (k = 0, j = tri->nVtx - 1; j >= 0; --j, ++k)
							p[k] = *(GUT_POINT*)&v[tri->vtx[j]].data.xyzw[0];
					}

					// check for special flag to re-normalize
					if (ctx->drawAdj.normalizeFlag)//if (ctx->global_normalize)
					{
						for (j = 0; j < tri->nVtx; ++j)
							gut_normalize_point(&p[j]);
					}

					// determine face normal from cross product
					gut_vector(&p[0], &p[1], &vab);
					gut_vector(&p[1], &p[2], &vbc);
					gut_cross_product(&vab, &vbc, &normal);
					gut_normalize_point((GUT_POINT*)&normal);

					if (ctx->clrCtl.triangle.flag) // override 
						clr = &ctx->clrCtl.triangle.override;
					else if (ctx->clrCtl.autoColor)
						ctbl_get_color(gobj->ctT, tri->id, &clr);
					else
						clr = &tri->color; // glColor3f((float)tri->color.r, (float)tri->color.g, (float)tri->color.b);

					if (tri->nVtx == 3 && ctx->drawAdj.circleFlag)
					{
						glBegin(GL_TRIANGLES);
						draw_circle_segment(&p[0], &p[1], &p[2], &normal, clr);
						glEnd();
					}
					else
					{
						glBegin(GL_TRIANGLES);
						for (j = 0; j < tri->nVtx; ++j)
						{
							if (j >= 2)
							{
								// determine face normal from cross product
								gut_vector(&p[0], &p[j - 1], &vab);
								gut_vector(&p[j - 1], &p[j], &vbc);
								gut_cross_product(&vab, &vbc, &normal);
								gut_normalize_point((GUT_POINT*)&normal);
								glNormal3f((float)normal.i * 3, (float)normal.j * 3, (float)normal.k * 3);
								glColor3f((float)clr->r, (float)clr->g, (float)clr->b);
								glVertex3f((float)p[0].x, (float)p[0].y, (float)p[0].z);
								glVertex3f((float)p[j - 1].x, (float)p[j - 1].y, (float)p[j - 1].z);
								glVertex3f((float)p[j].x, (float)p[j].y, (float)p[j].z);
							}
						}
						glEnd();
					}
				}
			}

			if (gobj->nEdge && (ctx->geomAdj.drawWhat & 0x2)) //ctx->tri_edge_mode == 1 || ctx->tri_edge_mode == 2))
			{
				glBegin(GL_TRIANGLES);

				if (ctx->eAttr.type == GEOMETRY_EDGE_SQUARE)
				{
					for (i = 0, v = gobj->v_out, edge = gobj->edge; i < gobj->nEdge; ++i, ++edge)
					{
						// copy vertex data to new variables
						p[0].x = v[edge->vtx[0]].data.xyzw[0];
						p[0].y = v[edge->vtx[0]].data.xyzw[1];
						p[0].z = v[edge->vtx[0]].data.xyzw[2];
						p[1].x = v[edge->vtx[1]].data.xyzw[0];
						p[1].y = v[edge->vtx[1]].data.xyzw[1];
						p[1].z = v[edge->vtx[1]].data.xyzw[2];

						// check for special flag to re-normalize
						if (ctx->drawAdj.normalizeFlag)//if (ctx->global_normalize)
						{
							gut_normalize_point(&p[0]);
							gut_normalize_point(&p[1]);
						}

						geo_edge_to_triangles(&ctx->eAttr, &p[0], &p[1], out, ctx->drawAdj.normalizeFlag, &origin);

						if (ctx->clrCtl.line.flag) // override 
							clr = &ctx->clrCtl.line.override;
						// if drawing both triangles and edges and they share a common color table reverse the color ID
						else if (ctx->clrCtl.reverseColorFlag)
							//							ctbl_get_color_new(gobj->ctE, edge->id, (ctx->geomAdj.drawWhat | GEOMETRY_DRAW_TRIANGLES) ? 1 : 0), &clr);
							ctbl_get_color_new(gobj->ctE, edge->id, ((ctx->geomAdj.drawWhat & GEOMETRY_DRAW_TRIANGLES) && (gobj->ctE == gobj->ctT)) ? 1 : 0, &clr);
						else
							ctbl_get_color(gobj->ctE, edge->id, &clr);

						draw_triangle(ctx, &out[0], &out[1], &out[2], clr); //gobj->clrE, edge->id);
						draw_triangle(ctx, &out[2], &out[3], &out[0], clr); //gobj->clrE, edge->id);
						draw_triangle(ctx, &out[0], &out[1], &out[2], clr); //gobj->clrE, edge->id);
						draw_triangle(ctx, &out[2], &out[3], &out[0], clr); //gobj->clrE, edge->id);
						if (ctx->eAttr.height != 0.0)
						{
							draw_triangle(ctx, &out[0], &out[4], &out[5], clr); //, gobj->clrE, edge->id);
							draw_triangle(ctx, &out[5], &out[1], &out[0], clr); //, gobj->clrE, edge->id);
							draw_triangle(ctx, &out[2], &out[6], &out[7], clr); //, gobj->clrE, edge->id);
							draw_triangle(ctx, &out[7], &out[3], &out[2], clr); //, gobj->clrE, edge->id);
						}
					}
				}
				else
				{
					GUT_VECTOR	normal[6];

					for (i = 0, v = gobj->v_out, edge = gobj->edge; i < gobj->nEdge; ++i, ++edge)
					{
						// copy vertex data to new variables
						p[0].x = v[edge->vtx[0]].data.xyzw[0];
						p[0].y = v[edge->vtx[0]].data.xyzw[1];
						p[0].z = v[edge->vtx[0]].data.xyzw[2];
						p[1].x = v[edge->vtx[1]].data.xyzw[0];
						p[1].y = v[edge->vtx[1]].data.xyzw[1];
						p[1].z = v[edge->vtx[1]].data.xyzw[2];

						// check for special flag to re-normalize
						if (ctx->drawAdj.normalizeFlag)//if (ctx->global_normalize)
						{
							gut_normalize_point(&p[0]);
							gut_normalize_point(&p[1]);
						}

						geo_edge_to_triangles_hex(&ctx->eAttr, &p[0], &p[1], out, normal, ctx->drawAdj.normalizeFlag, &origin);

						if (ctx->clrCtl.line.flag) // override 
							clr = &ctx->clrCtl.line.override;
						// if drawing both triangles and edges and they share a common color table reverse the color ID
						else if (ctx->clrCtl.reverseColorFlag)
							//							ctbl_get_color_new(gobj->ctE, edge->id, ((ctx->geomAdj.drawWhat & (GEOMETRY_DRAW_TRIANGLES | GEOMETRY_DRAW_EDGES)) && (gobj->ctE == gobj->ctT)) ? 1 : 0, &clr);
							ctbl_get_color_new(gobj->ctE, edge->id, ((ctx->geomAdj.drawWhat & GEOMETRY_DRAW_TRIANGLES) && (gobj->ctE == gobj->ctT)) ? 1 : 0, &clr);
						else
							ctbl_get_color(gobj->ctE, edge->id, &clr);

						draw_triangle_hex(ctx, &out, &normal, clr, 0, 6, 7);
						draw_triangle_hex(ctx, &out, &normal, clr, 7, 1, 0);

						draw_triangle_hex(ctx, &out, &normal, clr, 1, 7, 8);
						draw_triangle_hex(ctx, &out, &normal, clr, 8, 2, 1);

						draw_triangle_hex(ctx, &out, &normal, clr, 2, 8, 9);
						draw_triangle_hex(ctx, &out, &normal, clr, 9, 3, 2);

						draw_triangle_hex(ctx, &out, &normal, clr, 3, 9, 10);
						draw_triangle_hex(ctx, &out, &normal, clr, 10, 4, 3);

						draw_triangle_hex(ctx, &out, &normal, clr, 4, 10, 11);
						draw_triangle_hex(ctx, &out, &normal, clr, 11, 5, 4);

						draw_triangle_hex(ctx, &out, &normal, clr, 5, 11, 6);
						draw_triangle_hex(ctx, &out, &normal, clr, 6, 0, 5);
					}
				}
				glEnd();
			}

			// render vertices if required
			if (ctx->geomAdj.drawWhat & 0x4) //ctx->renderVertex.vtxObjFlag)
			{
				VERTEX		*vs = ctx->renderVertex.vtxObj.vtx, *vd = ctx->renderVertex.vtxObj.v_out;
				VTRIANGLE	*vt;
				double		scale; // = ctx->renderVertex.scale * ctx->eAttr.maxLength; // 0.03;

				clr = &ctx->renderVertex.clr;
				if (gobj->nEdge && (ctx->eAttr.maxLength > 0.0))
					scale = ctx->renderVertex.scale * ctx->eAttr.maxLength; // 0.03;
				else // special case so use scale as an absolute value since maxLength is invalid
					scale = ctx->renderVertex.scale; // 0.03;

				for (i = 0, v = gobj->v_out; i < gobj->nVtx; ++i, ++tri)
				{
					// check for special flag to re-normalize
					if (ctx->drawAdj.normalizeFlag)
						gut_normalize_point(&v[i]);

					// modify vertex object coordinates to be at this global position
					for (j = 0; j < ctx->renderVertex.vtxObj.nVtx; ++j)
					{
						vd[j].x = vs[j].x * scale + v[i].data.xyzw[0];
						vd[j].y = vs[j].y * scale + v[i].data.xyzw[1];
						vd[j].z = vs[j].z * scale + v[i].data.xyzw[2];
					}
					glBegin(GL_TRIANGLES);
					for (j = 0, vt = ctx->renderVertex.vtxObj.tri; j < ctx->renderVertex.vtxObj.nTri; ++j, ++vt)
					{
						glNormal3f((float)vs[vt->vtx[0]].x * 3, (float)vs[vt->vtx[0]].y * 3, (float)vs[vt->vtx[0]].z * 3);
						glColor3f((float)clr->r, (float)clr->g, (float)clr->b);
						glVertex3f((float)vd[vt->vtx[0]].x, (float)vd[vt->vtx[0]].y, (float)vd[vt->vtx[0]].z);// ++v;

						glNormal3f((float)vs[vt->vtx[1]].x * 3, (float)vs[vt->vtx[1]].y * 3, (float)vs[vt->vtx[1]].z * 3);
						glColor3f((float)clr->r, (float)clr->g, (float)clr->b);
						glVertex3f((float)vd[vt->vtx[1]].x, (float)vd[vt->vtx[1]].y, (float)vd[vt->vtx[1]].z);// ++v;

						glNormal3f((float)vs[vt->vtx[2]].x * 3, (float)vs[vt->vtx[2]].y * 3, (float)vs[vt->vtx[2]].z * 3);
						glColor3f((float)clr->r, (float)clr->g, (float)clr->b);
						glVertex3f((float)vd[vt->vtx[2]].x, (float)vd[vt->vtx[2]].y, (float)vd[vt->vtx[2]].z);// ++v;
					}
					glEnd();
				}
			}
		}
	}

	glBegin(GL_TRIANGLES);

	if (ctx->drawAdj.clipFlag && ctx->drawAdj.clipVisibleFlag)
	{
		glNormal3f((float)0, (float)0, (float)3);

		glColor3f((float)1, (float)1, (float)0);
		glVertex3f((float)1.05, (float)-1.05, (float)ctx->drawAdj.clipZValue);
		glVertex3f((float)1.05, (float)1.05, (float)ctx->drawAdj.clipZValue);
		glVertex3f((float)-1.05, (float)1.05, (float)ctx->drawAdj.clipZValue);

		glVertex3f((float)-1.05, (float)1.05, (float)ctx->drawAdj.clipZValue);
		glVertex3f((float)-1.05, (float)-1.05, (float)ctx->drawAdj.clipZValue);
		glVertex3f((float)1.05, (float)-1.05, (float)ctx->drawAdj.clipZValue);
	}

	glEnd();
}
*/
/*
//-----------------------------------------------------------------------------------
void geo_edge_to_triangles_hex_old(EDGE_ATTRIBUTES *eattr, VERTEX *a, VERTEX *b, VERTEX *p, GUT_VECTOR *n, int normalize, GUT_POINT *origin)
//-----------------------------------------------------------------------------------
{
	// a & b are the endpoints of the line
	// p[] is the array of new endpoints arranged in 2 pairs of 6 vertices surrounding each end point
	// n[] is the normals to apply to each new endpoint when drawing
	// normalize is a flag 
	// origin is the local origin point
	//
	// create normals
	GUT_VECTOR	z, x, y, h, w, r, tmp;
	GUT_POINT	m;
	double		rad, d;
	int			i;

	gut_mid_point((GUT_POINT*)a, (GUT_POINT*)b, &m);
	z.i = m.x - origin->x;
	z.j = m.y - origin->y;
	z.k = m.z - origin->z;
//	gut_normalize_point(&m);
//	z = *(GUT_VECTOR*)&m;
	gut_vector((GUT_POINT*)a, (GUT_POINT*)b, &y);
	gut_normalize_vector(&y);
	gut_cross_product(&y, &z, &x);
	gut_normalize_vector(&x);

	// create points 
//	gut_distance_from_point_to_point((GUT_POINT*)a, (GUT_POINT*)b, &d);
	d = eattr->maxLength;
	rad = d * eattr->width / 2;

	gut_scale_vector(&z, rad*sqrt(3.0) / 2.0, &h);
	gut_scale_vector(&x, rad / 2, &w);
	gut_scale_vector(&x, rad, &r);

	gut_add_vector(&h, &w, &tmp);
	gut_point_plus_vector((GUT_POINT*)a, &tmp, &p[0]);
	gut_point_plus_vector((GUT_POINT*)b, &tmp, &p[6]);
	n[0] = tmp;
	gut_normalize_vector(&n[0]);
	gut_point_plus_vector((GUT_POINT*)a, &r, &p[5]);
	gut_point_plus_vector((GUT_POINT*)b, &r, &p[11]);
	n[5] = r;
	gut_normalize_vector(&n[5]);
	gut_reverse_vector(&w);
	gut_add_vector(&h, &w, &tmp);
	gut_point_plus_vector((GUT_POINT*)a, &tmp, &p[1]);
	gut_point_plus_vector((GUT_POINT*)b, &tmp, &p[7]);
	n[1] = tmp;
	gut_normalize_vector(&n[1]);
	gut_reverse_vector(&r);
	gut_point_plus_vector((GUT_POINT*)a, &r, &p[2]);
	gut_point_plus_vector((GUT_POINT*)b, &r, &p[8]);
	n[2] = r;
	gut_normalize_vector(&n[2]);
	gut_reverse_vector(&h);
	gut_add_vector(&h, &w, &tmp);
	gut_point_plus_vector((GUT_POINT*)a, &tmp, &p[3]);
	gut_point_plus_vector((GUT_POINT*)b, &tmp, &p[9]);
	n[3] = tmp;
	gut_normalize_vector(&n[3]);
	gut_reverse_vector(&w);
	gut_add_vector(&h, &w, &tmp);
	gut_point_plus_vector((GUT_POINT*)a, &tmp, &p[4]);
	gut_point_plus_vector((GUT_POINT*)b, &tmp, &p[10]);
	n[4] = tmp;
	gut_normalize_vector(&n[4]);
}
*/
