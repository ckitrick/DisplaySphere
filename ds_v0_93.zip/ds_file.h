
#ifndef FILE_HEADER
#define FILE_HEADER

#include <stdlib.h>
#include <stdio.h>
#include <windows.h>		/* must include this before GL/gl.h */
#include <direct.h>
#include <commdlg.h>
#include "resource.h"
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include "ds_sph.h"
#include "ds_par.h"

// Functions
int			FileInitialization		( HWND hWnd, char *filename, int dataType );
void		DoFileDialog			( HWND hOwnerWnd, CTX *ctx );
int			ReadFileFromBuffer		( CTX *ctx );
static void	FILM_DragAndDrop		( HWND hWnd, HDROP hdrop );
int			parse_execute			( CTX *ctx, FILE *fp );
int			BackgroundColorDialog	( HWND hOwnerWnd, CTX *ctx );
int			LineColorDialog(HWND hOwnerWnd, CTX *ctx);
int			DefaultColorDialog(HWND hOwnerWnd, CTX *ctx);
int			parse_file				( CTX *ctx, FILE *fp, char *filename );
int			parse_file_line			( CTX *ctx, FILE *fp, char *filename );
int			 capture_film_frame		( CTX *ctx );
#endif