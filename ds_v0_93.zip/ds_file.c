
#include <stdlib.h>
#include <stdio.h>
#include <windows.h>		/* must include this before GL/gl.h */
#include <direct.h>
#include <commdlg.h>
#include "resource.h"
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <matrix.h>
#include <geoutil.h>
#include <link.h>
#include "ds_sph.h"
#include "ds_par.h"
#include <link.h>
#include <mem.h>
#include "ds_file.h"
#include "ds_gua.h"

HINSTANCE		hInstance;

//int parse_file(CTX *ctx, FILE *fp, char *filename);

//-----------------------------------------------------------------------------
int File_SetWindowText ( HWND *hWnd, char *name )
//-----------------------------------------------------------------------------
{
	CTX		*ctx;

	ctx = (CTX*)GetWindowLong(hWnd, GWL_USERDATA);
	SetWindowText(hWnd, name);
	return 0;
}

//-----------------------------------------------------------------------------
int FileTypeInitialization ( CTX *ctx, char *filename )
//-----------------------------------------------------------------------------
{
	return 0;
}

//-----------------------------------------------------------------------------
int FileInitialization ( HWND hWnd, char *filename )
//-----------------------------------------------------------------------------
{
	char	c, *p;
	FILE	*fp;
	CTX		*ctx;
	char	buffer[128], buf1[24], buf2[12];

	ctx = (CTX*)GetWindowLong ( hWnd, GWL_USERDATA );

	p = filename + ( strlen(filename ) - 1 );
	while (c = *p--)
	{
		if (c == '\\')
		{
			++p;
			break;
		}
	}

	fp = fopen ( filename, "r" );

	if (fp)
	{
		File_SetWindowText(hWnd, p + 1);
		parse_file2(ctx, fp, filename);
		fclose(fp);
	}

	return 0;
}

//-----------------------------------------------------------------------------
void DoFileDialog ( HWND hOwnerWnd, CTX *ctx, int type )
//-----------------------------------------------------------------------------
{
	char			pFilter[] = "Geometry Data (*.off,*.spc)\0*.off;*.spc\0OFF Data (*.off)\0*.off;\0SPC Data (*.spc)\0*.spc;\0All Files (*.*)\0*.*\0\0";
	char			cFilter[] = "Color Table Files (*.txt)\0*.txt\0All Files (*.*)\0*.*\0\0";
	char			*p;
	BOOL			bRes;
	OPENFILENAME	ofn;
	FILE			*fp;

	ctx->filename[0]      = 0; // null terminate
	ofn.lStructSize       = sizeof( OPENFILENAME );
	ofn.hwndOwner         = hOwnerWnd;
	ofn.hInstance         = 0; //hInstance;
	ofn.lpstrFilter       = !type ? pFilter : cFilter;
	ofn.lpstrCustomFilter = 0;
	ofn.nMaxCustFilter    = 0;
	ofn.nFilterIndex      = 0;
	ofn.lpstrFile         = ctx->filename;
	ofn.nMaxFile          = _MAX_PATH;
	ofn.lpstrFileTitle    = 0;
	ofn.nMaxFileTitle     = _MAX_FNAME+_MAX_EXT;
	ofn.lpstrInitialDir   = 0;
	ofn.lpstrTitle        = 0;
	ofn.Flags             = OFN_HIDEREADONLY | OFN_CREATEPROMPT;
	ofn.nFileOffset       = 0;
	ofn.nFileExtension    = 0;
	ofn.lpstrDefExt       = "off";
	ofn.lCustData         = 0L;
	ofn.lpfnHook          = 0;
	ofn.lpTemplateName    = 0;

	bRes = GetOpenFileName ( &ofn );
	if (!bRes)
		return; // no file selected 

	if (!type) // geometry file
	{
		p = ctx->filename + (strlen(ctx->filename) - 1);
		while (*p != '\\')
		{
			--p;
		}
		File_SetWindowText(hOwnerWnd, p + 1);


		// repeat
		fp = fopen(ctx->filename, "r");
		if (fp)
		{
			FileTypeInitialization(ctx, p + 1);
			parse_file2(ctx, fp, ctx->filename);
		}
		fclose(fp);
	}
	else if (type == 1) // color tables 
	{
		if ( ctbl_process_color_table_file(&ctx->cts, ctx->filename))
			MessageBox(NULL, "Color table file read failed.", 0, MB_OK);
	}
}

//-----------------------------------------------------------------------------
int ReadFileFromBuffer ( CTX *ctx )
//-----------------------------------------------------------------------------
{
	FILE	*fp;

	if ( !strlen ( ctx->filename ) )
		return 1;

	fp = fopen(ctx->filename, "r");
	if (fp)
	{
		parse_file2(ctx, fp, ctx->filename);
		fclose(fp);
	}
	else
		MessageBox(NULL, "File read failed.", 0, MB_OK);

	return 0;
}

//-----------------------------------------------------------------------------
static void FILM_DragAndDrop ( HWND hWnd, HDROP hdrop )
//-----------------------------------------------------------------------------
{
	char			buffer[256];
	unsigned int	count, index;
	CTX				*ctx;

	ctx = (CTX*)GetWindowLong(hWnd, GWL_USERDATA);

	// determine if a file is available
	if (count = DragQueryFileA(hdrop, 0xFFFFFFFF, (LPSTR)buffer, (UINT)256))
	{
		for (index = 0; index < count; ++index)
		{
			if (index)
				ctx->gobjAddFlag = 1;

			// get the new filename
			DragQueryFile(hdrop, index, (LPSTR)buffer, (UINT)256);

			// reset the menus
			//FILM_SetDirectoryAndFile ( buffer );
			FileInitialization(hWnd, buffer, 0);
	
			ctx->gobjAddFlag = 0;
		}
	}

	// release system resources 
	DragFinish ( hdrop );
}

//-----------------------------------------------------------------------------
GEO_OBJECT *geo_object_find(CTX *ctx, char *filename)
//-----------------------------------------------------------------------------
{
	GEO_OBJECT	*gobj;

	LL_SetHead(ctx->gobjectq);
	while (gobj = (GEO_OBJECT*)LL_GetNext(ctx->gobjectq))
	{
		if (!strcmp(gobj->filename, filename))
			return gobj;
	}

	return 0;
}

//-----------------------------------------------------------------------------
GEO_OBJECT *geo_object_create2(CTX *ctx, char *filename)
//-----------------------------------------------------------------------------
{
	// initialize a geometric object
	GEO_OBJECT	*gobj, *lgobj;

	gobj = malloc(sizeof(GEO_OBJECT));
	if (!gobj)
		return 0;

	// memory allocated pointers 
	gobj->filename	= 0; 
	gobj->v_out		= 0;
//	gobj->poly		= 0;
	gobj->tri		= 0;
	gobj->edge		= 0;
	// assigned data/pointers
	gobj->nTri		= 0;
	gobj->nEdge		= 0;
	gobj->nVtx		= 0;
	gobj->ctT		= 0;
	gobj->ctE		= 0;
	gobj->ctB		= 0;
	gobj->vIndex    = 0;

	// inherit default settings
	gobj->active	= ctx->defInputObj.active;
	gobj->drawWhat	= ctx->defInputObj.drawWhat;
	gobj->eAttr		= ctx->defInputObj.eAttr;
	gobj->cAttr		= ctx->defInputObj.cAttr;
	gobj->vAttr		= ctx->defInputObj.vAttr;
	gobj->rAttr		= ctx->defInputObj.rAttr; 

	gobj->filename = malloc(strlen(filename) + 1);
	strcpy(gobj->filename, filename);

	if (!ctx->gobjAddFlag) // remove all the previous geometry
	{
		ctx->eAttr.maxLength = 0.0;
		ctx->eAttr.minLength = 1000000000.0;

		while (lgobj = (GEO_OBJECT*)LL_RemoveHead(ctx->gobjectq))
		{	// free up allocated memory
			lgobj->filename ? free(lgobj->filename) : 0;
			lgobj->v_out	? free(lgobj->v_out)	: 0;
			lgobj->tri		? free(lgobj->tri)		: 0;
			lgobj->edge		? free(lgobj->edge)		: 0;
			lgobj->vIndex   ? free(lgobj->vIndex)   : 0;
			lgobj			? free ( lgobj )		: 0; // free self
		}
	}

	LL_AddTail(ctx->gobjectq, gobj); // add to queue

	return gobj;
}

//-----------------------------------------------------------------------------
GEO_OBJECT *parse_file2(CTX *ctx, FILE *fp, char *filename)
//-----------------------------------------------------------------------------
{
//	GUA_UNIQUE	*gua;
	void		*gua;
	GEO_OBJECT	*geo;
	int			resultsFlag = 0;
	int			fileType;
	int			guaFlag = 0;
	enum {
		FILE_OFF,
		FILE_SPC
	};

	// atempt to read OFF format first 
	fileType = gua_off_read(ctx, (void*)&gua, fp, (float*)&ctx->clrCtl.triangle.defaultColor);

	switch (fileType) {
	case FILE_OFF:
		guaFlag = 1; // normal GUA data created
		break;
	case FILE_SPC:
		if (ctx->inputTrans.guaFlag)
		{
			guaFlag = 1;// normal GUA data created
			gua_spc_read(ctx, (void*)&gua, fp, (float*)&ctx->clrCtl.triangle.defaultColor);
		}
		else
		{	// NGUA data created
			ngua_spc_read(ctx, (void*)&gua, fp, (float*)&ctx->clrCtl.triangle.defaultColor);
		}
	}

	geo = geo_object_create2(ctx, filename); // create, initialize, and add to queue
	if (guaFlag && ctx->inputTrans.guaResultsFlag)
	{

		int			i, n = 0;
		char		buffer[512];
		n = strlen(filename);
		for (i = n - 1; i >= 0; --i)
			if (filename[i] == '.')
			{
				sprintf(buffer, "%.*s-unique.txt", i, filename);
				break;
			}
		if (!i)
			sprintf(buffer, "%s-unique.txt", filename);
		gua_dump(ctx, gua, filename, buffer);
	}
	if ( guaFlag)
		gua_convert_to_object(ctx, gua, geo);
	else
		ngua_convert_to_object(ctx, gua, geo);

	return geo;
}
