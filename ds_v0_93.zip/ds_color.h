#pragma once
#ifndef DISP_COLOR_HEADER
#define DISP_COLOR_HEADER

typedef struct {
	float	r,
			g,
			b;
} COLOR;

typedef struct {
	char	buffer[32];
} CWORD;

typedef struct {
	int				nColors;
	COLOR			*color;
	void			*next;
} COLOR_TABLE;

typedef struct {
	int				nTables;
	void			*head;
	void			*tail;
}COLOR_TABLE_SET;

int ctbl_add_color_table(COLOR_TABLE_SET *cts, COLOR_TABLE *ct);
COLOR_TABLE *ctbl_get_color_table(COLOR_TABLE_SET *cts, int nColors);
int ctbl_read_color_table(FILE *fp, COLOR_TABLE *ct, int max, int *nc, int *more);
int ctbl_get_color(COLOR_TABLE *ct, int index, COLOR **color);
int ctbl_process_color_table_file(COLOR_TABLE_SET *cts, char *filename);
int ctbl_get_color_new(COLOR_TABLE *ct, int index, int reverseFlag, COLOR **color);

#endif DISP_COLOR_HEADER
