// SVG Functions 
//
#include <stdlib.h>
#include <windows.h>		/* must include this before GL/gl.h */
#include <OBJBASE.H>
#include <direct.h>
#include <GL/gl.h>			/* OpenGL header file */
#include <GL/glext.h>		/* OpenGL header file */
#include <GL/wglext.h>
#include <stdio.h>
#include <math.h>
#include <commdlg.h>
#include "resource.h"
#include <geoutil.h>
#include <matrix.h>
#include <link.h>
#include <avl_new.h>
#include "ds_color.h"
#include "ds_sph.h"
#include "ds_file.h"

/*
	SVG LIBRARY - Simple utility functions

	int		svg_init ( svg, filename, line_width, pixel_width, pixel_height )
	int		svg_open ( svg )
			svg_close(svg)
			svg_polyline ( svg, pt, n )
			svg_polyline_width ( svg, pt, n, line_width )
			svg_polygon_start ( svg, pt, n )
			svg_polygon_add ( svg, pt, n )
			svg_polygon_end ( svg ) //, pt, n )
*/
/* USAGE EXAMPLE
	define SVG	ctx
	svg_init ( ctx, filename, lineWidth, width, height )
	svg_open ( ctx )
	svg_polyline ( ctx, ptArray, nPts )
	svg_polyline_width ( ctx, ptArray, nPts, tempLineWidth )
	svg_polyline ( ctx, ptArray, nPts )
	svg_close ( ctx )
*/
/* OUTPUT EXAMPLE
<svg width="1200" height="1200" xmlns="http://www.w3.org/2000/svg">
  <polyline fill="none" stroke="black" points=" 5,10 100,100 40,150 " stroke-width="0.5" stroke-linejoin="round"/>
  <polyline fill="none" stroke="black" points="10,10 110,100 45,150 " stroke-width="1" stroke-linejoin="round"/>
</svg>
*/
/*
	SVG LIBRARY - Simple utility functions

	int		svg_init ( svg, filename, line_width, pixel_width, pixel_height )
	int		svg_open ( svg )
			svg_close(svg)
			svg_polyline ( svg, pt, n )
			svg_polyline_width ( svg, pt, n, line_width )
			svg_polygon_start ( svg, pt, n )
			svg_polygon_add ( svg, pt, n )
			svg_polygon_end ( svg ) //, pt, n )
			svg_circle ( svg, pt, size )
			svg_text ( svg, pt, size, text, rotate )
			svg_image ( svg, filename, w, h )
			svg_image_rotate ( svg, filename, w, h, r )
*/
/* USAGE EXAMPLE
	define SVG	ctx
	svg_init ( ctx, filename, lineWidth, width, height )
	svg_open ( ctx )
	svg_polyline ( ctx, ptArray, nPts )
	svg_polyline ( ctx, ptArray, nPts, tempLineWidth )
	svg_polyline ( ctx, ptArray, nPts )
	svg_close ( ctx )
*/
/* OUTPUT EXAMPLE
<svg width="1200" height="1200" xmlns="http://www.w3.org/2000/svg">
  <polyline fill="none" stroke="black" points=" 5,10 100,100 40,150 " stroke-width="0.5" stroke-linejoin="round"/>
  <polyline fill="none" stroke="black" points="10,10 110,100 45,150 " stroke-width="1" stroke-linejoin="round"/>
</svg>
*/
/*
	UPDATE: 2/9/2018  - Add 0.5 pixel shift to align with pixel center position
	UPDATE: 2/10/2018 - Add color to line initialization, set line cap to butt
	UPDATE: 6/2018 - Added text, circle, image
	UPDATE: 12/2018 - Added groups
*/
/*
	GROUP examples
	<g fill="white" stroke="blue" stroke-width="1" > // used on a circle
	<g style="font-family: Arial; font-size: 14; text-anchor: middle; stroke: none; fill:#000000;"> // text
*/
/*
typedef struct { // SVG
	double	line_width;
	int		line_color[3]; //rgb
	int		image_width;
	int		image_height;
	int		override;
	char	fill[128];
	FILE	*fp; // holds the file pointer
	char	filename[512];
} SVG;

void ds_svg_draw_geometry(CTX *ctx, SVG *svg);

//--------------------------------------------------------------
int svg_init(SVG *svg, char *filename, double line_width, int *line_color, int pixel_width, int pixel_height)
//--------------------------------------------------------------
{
	svg->fp = fopen(filename, "w");
	if (!svg->fp)
		return 1; // failed to open file
			
	//	echo OPEN SVG FILE
	svg->line_width		= line_width;
	svg->image_width	= pixel_width;
	svg->image_height	= pixel_height;
	svg->override		= 0;
	svg->line_color[0]	= line_color[0]; // red
	svg->line_color[1]	= line_color[1]; // green
	svg->line_color[2]	= line_color[2]; // blue
	svg->override		= 0;
	svg->fill[0]		= 0;
	return 0; // success
}

//--------------------------------------------------------------
int svg_open(SVG *svg)
//--------------------------------------------------------------
{
	//	Output standard initialization
	// 	Open output file
	//	Only set a number of state items (width, fill, etc.) once since it doesn't change
	fprintf(svg->fp, "<svg width=\"%d\" height=\"%d\" ", svg->image_width, svg->image_height);
	fprintf(svg->fp, "stroke=\"rgb(%d,%d,%d)\" ", svg->line_color[0], svg->line_color[1], svg->line_color[2]);
	fprintf(svg->fp, "stroke-width=\"%4.1f\" stroke-linejoin=\"round\" ", svg->line_width);
	fprintf(svg->fp, "stroke-linecap=\"square\" "); // butt
	if (!svg->fill[0])
		fprintf(svg->fp, "fill=\"none\" ");
	else
		fprintf(svg->fp, "fill=\"%s\" ", svg->fill);
	fprintf(svg->fp, "shape-rendering=\"geometricPrecision\" xmlns=\"http://www.w3.org/2000/svg\">\n");
	return 0;
}

//--------------------------------------------------------------
int svg_close(SVG *svg)
//--------------------------------------------------------------
{
	if (!svg->fp)
		return 0;
	fprintf(svg->fp, "</svg>\n"); // complete the svg definition
	fclose(svg->fp);
	return 0;
}

//--------------------------------------------------------------
void svg_start_group(SVG *svg, char *style)
//--------------------------------------------------------------
{
	// start a group - style is just already created text
	fprintf(svg->fp, "<g %s>\n", style);
}

//--------------------------------------------------------------
void svg_end_group(SVG *svg)
//--------------------------------------------------------------
{
	// end a group
	fprintf(svg->fp, "</g>\n");
}

//--------------------------------------------------------------
void svg_polyline(SVG *svg, GUT_POINT *pt, int n)
//--------------------------------------------------------------
{
	//	add a polyline to the svg definition using common width
	fprintf(svg->fp, "<polyline ");

	fprintf(svg->fp, "points=\"");
	int		i;
	for (i = 0; i < n; ++i)
		fprintf(svg->fp, "%.3f,%.3f ", pt[i].x + 0.5, pt[i].y + 0.5);

	fprintf(svg->fp, "\"");

	if (svg->override) // reset line width override
	{
		svg->override = 0;
		fprintf(svg->fp, " stroke-width=\"%4.1f\" ", svg->line_width);
	}

	fprintf(svg->fp, "/>\n");
}

//--------------------------------------------------------------
void svg_polyline_width(SVG *svg, GUT_POINT *pt, int n, double line_width)
//--------------------------------------------------------------
{
	//	add a polyline to the svg definition
	fprintf(svg->fp, "<polyline ");

	fprintf(svg->fp, "points=\"");
	int		i;
	for (i = 0; i < n; ++i)
		fprintf(svg->fp, "%.3f,%.3f ", pt[i].x + 0.5, pt[i].y + 0.5);
	fprintf(svg->fp, "\"");

	fprintf(svg->fp, " stroke-width=\"%4.1f\" fill-opacity=\"0.0\" ", line_width);
	svg->override = 1; // set the override flag
	fprintf(svg->fp, "/>\n");
}

//--------------------------------------------------------------
void svg_polygon(SVG *svg, GUT_POINT *pt, int n)
//--------------------------------------------------------------
{
	//	add a polygon path to the svg definition using common width

	fprintf(svg->fp, "<path d=\"M");
	int		i;
	for (i = 0; i < n; ++i)
		fprintf(svg->fp, "%.3f,%.3f ", pt[i].x + 0.5, pt[i].y + 0.5);

	fprintf(svg->fp, " Z\" fill-rule=\"evenodd\"/>\n");
}

//--------------------------------------------------------------
void svg_polygon_fill(SVG *svg, GUT_POINT *pt, int n, char *fill)
//--------------------------------------------------------------
{
	//	add a polygon path to the svg definition using common width

	fprintf(svg->fp, "<path fill=\"%s\" d=\"M", fill);
	int		i;
	for (i = 0; i < n; ++i)
		fprintf(svg->fp, "%.3f,%.3f ", pt[i].x + 0.5, pt[i].y + 0.5);

	fprintf(svg->fp, " Z\" fill-rule=\"evenodd\" />\n");
}

//--------------------------------------------------------------
void svg_polygon_start(SVG *svg, GUT_POINT *pt, int n)
//--------------------------------------------------------------
{
	//	add a polygon path to the svg definition using common width
	//	echo POLY START
	fprintf(svg->fp, "<path d=\"M");
	int		i;
	for (i = 0; i < n; ++i)
		fprintf(svg->fp, "%.3f,%.3f ", pt[i].x + 0.5, pt[i].y + 0.5);

	//	fprintf ( svg->fp, " Z\" fill-rule=\"evenodd\"/>\n" )
}

//--------------------------------------------------------------
void svg_polygon_add(SVG *svg, GUT_POINT *pt, int n)
//--------------------------------------------------------------
{
	//	add a polygon path to the svg definition using common width
	//	echo POLY ADD
	fprintf(svg->fp, "M");
	int		i;
	for (i = 0; i < n; ++i)
		fprintf(svg->fp, "%.3f,%.3f ", pt[i].x + 0.5, pt[i].y + 0.5);

	//	fprintf ( svg->fp, " Z\" fill-rule=\"evenodd\"/>\n" )
}

//--------------------------------------------------------------
void svg_polygon_end(SVG *svg) //, pt, n )
//--------------------------------------------------------------
{
	fprintf(svg->fp, " Z\" fill-rule=\"evenodd\"/>\n");
}

//--------------------------------------------------------------
int ds_svg_output(CTX *ctx)
//--------------------------------------------------------------
{
	SVG		svg;
	int		lineColor[3] = { 0,0,0 };
	char	outputFilename[256];

	lineColor[0] = ctx->clrCtl.line.override.r * 255;
	lineColor[1] = ctx->clrCtl.line.override.g * 255;
	lineColor[2] = ctx->clrCtl.line.override.b * 255;

	if (strlen(ctx->curWorkingDir))
		SetCurrentDirectory(ctx->curWorkingDir);

	if (ctx->svg.singleFlag) //do not add index
		sprintf(outputFilename, "%s.svg", ctx->svg.basename); 
	else
		sprintf(outputFilename, "%s%05d.svg", ctx->svg.basename, ctx->svg.curFrame++);

	// create an SVG version of current content
	if (svg_init(&svg, outputFilename, ctx->svg.lineWidth, &lineColor, ctx->window.width, ctx->window.height))
		return 1; // file failed to open

	svg_open(&svg);
	ds_svg_draw_geometry(ctx, &svg);
	svg_close(&svg);

	return 0;
}

//-----------------------------------------------------------------------------
void ds_svg_draw_triangle(CTX *ctx, SVG *svg, GUT_POINT *a, GUT_POINT *b, GUT_POINT *c, COLOR *clr) //COLOR *ctbl, int id)
//-----------------------------------------------------------------------------
{
	static GUT_VECTOR	vab, vbc, normal;
	COLOR				*clrp;
	char				style[64];
	GUT_POINT			tp[3];

	// determine face normal from cross product
	gut_vector(a, b, &vab);
	gut_vector(b, c, &vbc);
	gut_cross_product(&vab, &vbc, &normal);
	gut_normalize_point((GUT_POINT*)&normal);

	glNormal3f((float)normal.i * 3, (float)normal.j * 3, (float)normal.k * 3);

	if (ctx->clrCtl.line.flag) // override 
	{
		clrp = &ctx->clrCtl.line.override;
	}
	else
	{
		clrp = clr;
	}
	if (normal.k <= 0.0)
		return;

	tp[0] = *a;
	tp[1] = *b;
	tp[2] = *c;
	sprintf(style, "style=\"fill:#%02x%02x%02x; \"", (int)(clrp->r * 255), (int)(clrp->g * 255), (int)(clrp->b * 255));
	svg_start_group(svg, style);
	svg_polygon(svg, tp, 3);
	svg_end_group(svg);// , style);
}

//-----------------------------------------------------------------------------
int ds_svg_draw_circle_segment(GUT_POINT *a, GUT_POINT *b, GUT_POINT *c, GUT_POINT *poly, int *n, GUT_VECTOR *normal, GUT_POINT *origin )
//-----------------------------------------------------------------------------
{
	// determine if a,b, or c is not on the sphere
	double		distance[3];
	GUT_POINT	*p[3];

	gut_distance_from_point_to_point(a, origin, &distance[0]);
	gut_distance_from_point_to_point(b, origin, &distance[1]);
	gut_distance_from_point_to_point(c, origin, &distance[2]);

	if (fabs(distance[0] - 1.0) > 0.00001)
	{
		p[0] = a;
		p[1] = b;
		p[2] = c;
	}
	else if (fabs(distance[1] - 1.0) > 0.00001)
	{
		p[0] = b;
		p[1] = c;
		p[2] = a;
	}
	else if (fabs(distance[2] - 1.0) > 0.00001)
	{
		p[0] = c;
		p[1] = a;
		p[2] = b;
	}
	else
	{
		return 1; // nothing to draw
	}

	{
		GUT_VECTOR	v[2];
		double		angle,
					t,
					tInc;
		GUT_POINT	d,
					e;
		int			i,
					nInc;

		gut_vector(p[0], p[1], &v[0]);
		gut_vector(p[0], p[2], &v[1]);

		gut_normalize_vector(&v[0]);
		gut_normalize_vector(&v[1]);
		gut_cross_product(&v[0], &v[1], normal);
		gut_normalize_vector(normal);

		gut_dot_product(&v[1], &v[0], &angle);

		angle = acos(angle);

		t = angle / DTR(10.0);
		//		nInc = angle / DTR( 10.0 );
		if (t < 1.0)
			nInc = 1;
		else if (t < 2.0)
			nInc = 2;
		else
			nInc = t;

		tInc = 1.0 / nInc;

		gut_distance_from_point_to_point(p[0], p[1], &distance[0]);

		*n = 0;
		poly[*n] = *p[0]; ++*n;
		poly[*n] = *p[1]; ++*n;
		for (i = 0, d = *p[1], t = tInc; i < nInc; ++i, t += tInc)
		{
			gut_vector(p[0], &d, &v[0]);
			distance[1] = sqrt(v[0].i * v[0].i + v[0].j * v[0].j + v[0].k * v[0].k);
			distance[2] = distance[1] / distance[0];
			d.x = p[0]->x + v[0].i / distance[2];
			d.y = p[0]->y + v[0].j / distance[2];
			d.z = p[0]->z + v[0].k / distance[2];
			d.w = 1.0;

			gut_parametric_point(p[1], p[2], &e, t);
			gut_vector(p[0], &e, &v[0]);
			distance[1] = sqrt(v[0].i * v[0].i + v[0].j * v[0].j + v[0].k * v[0].k);
			distance[2] = distance[1] / distance[0];
			e.x = p[0]->x + v[0].i / distance[2];
			e.y = p[0]->y + v[0].j / distance[2];
			e.z = p[0]->z + v[0].k / distance[2];
			e.w = 1.0;

			poly[*n] = e; ++*n;
			d = e;
		}
	}

	return 0;
}

//-----------------------------------------------------------------------------
void ds_svg_draw_geometry(CTX *ctx, SVG *svg)
//-----------------------------------------------------------------------------
{
	int			i, j, k; // j, k, n_faces;
	MTX_MATRIX	*mp;
	MTX_MATRIX	*mmp;
	MTX_VECTOR	*v;
	MTX_STACK	*stack;
	COLOR		ctmp;
//	GUT_POINT	pa, pb, pc, origin[2] = { 0,0,0,1 };
	GUT_POINT	origin[2] = { 0,0,0,1 };
	GUT_VECTOR	vab, vbc, normal;
//	POLYHEDRON	*poly;
	GEO_OBJECT	*gobj;
	TRIANGLE	*tri;
	COLOR		*clr;
	EDGE		*edge;
	GUT_POINT	out[12]; // edge triangle points 
	GUT_POINT	tp[32], tpp[32];
	double		scale, xscale, yscale;
	double		xoffset, yoffset;
	char		style[64];
	GUT_POINT	light[2];// = { 0.5, 0.5, 2.0, 1.0 };
	GUT_VECTOR	vec[2];
	double		incidenceAngle;
	double		mproj[16];
	double		mview[16];
	double		mtran[16];
	double		sign; // used for face culling
	int			reverseOrder;
	double		ambient = 0.4;
	double		length;

	glGetDoublev(GL_MODELVIEW_MATRIX, &mview); // ctx->drawAdj.matrix);
	glGetDoublev(GL_PROJECTION_MATRIX, &mproj); // ctx->drawAdj.matrix);

	scale = ctx->window.height / 2.0;
	xscale = scale * (double)ctx->window.width / (double)ctx->window.height;
	yscale = scale;
	xoffset = ctx->window.width / 2.0;
	yoffset = ctx->window.height / 2.0;

	stack = mtx_create_stack(32, MTX_PRE_MULTIPLY);

	// BACKGROUND (extend over the boundaries and let the renderer clip)
	if (ctx->svg.backgroundFlag)
	{
		sprintf(style, "style=\"fill:#%02x%02x%02x; \"", (int)(ctx->clrCtl.bkgClear.r * 255), (int)(ctx->clrCtl.bkgClear.g * 255), (int)(ctx->clrCtl.bkgClear.b * 255));
		tp[0].x = -4;
		tp[0].y = -4;
		tp[1].x = ctx->window.width + 4;
		tp[1].y = -4;
		tp[2].x = ctx->window.width + 4;
		tp[2].y = ctx->window.height + 4;
		tp[3].x = -4;
		tp[3].y = ctx->window.height + 4;
		svg_start_group(svg, style);
		svg_polygon(svg, tp, 4);
		svg_end_group(svg); // , style);
	}
	if (ctx->clrCtl.useLightingFlag)
		light[0] = ctx->clrCtl.light;

	geometry_draw_init(ctx);
	while (geometry_next_draw_transform(ctx, &mmp, &reverseOrder, ctx->geomAdj.orientation)) //ctx->geomAdj.orientation
	{
		LL_SetHead(ctx->gobjectq);
		while (gobj = (GEO_OBJECT*)LL_GetNext(ctx->gobjectq))
		{

			if (gobj->nTri && (ctx->geomAdj.drawWhat & 0x1)) //ahttri_edge_m == 0 || ctx->tri_edge_mode == 2 ) )
			{
				if (!gobj->v_out) // check if memory has been allocated
				{
					gobj->v_out = malloc(sizeof(MTX_VECTOR) * gobj->nVtx);
				}

				// push model view matrix onto stack
				mtx_stack_reset(stack);
				mtx_push_matrix(stack, mmp);
				mtx_push_matrix(stack, (MTX_MATRIX*)&ctx->matrix); // rotation matrix

				mtx_create_translation_matrix(&mtran, ctx->trans[0], ctx->trans[1], ctx->trans[2]);
				mtx_push_matrix(stack, (MTX_MATRIX*)&mtran);
				mp = mtx_get_stack_top(stack);

				// transform all the vertices 
				mtx_vector_multiply(gobj->nVtx, (MTX_VECTOR*)gobj->vtx, gobj->v_out, mp);
				// correctly position the light 
				mtx_vector_multiply(1, (MTX_VECTOR*)&light[0], &light[1], mtran); // need to translate the light
				mtx_vector_multiply(1, (MTX_VECTOR*)&origin[0], &origin[1], mtran);

				for (i = 0, v = gobj->v_out, tri = gobj->tri; i < gobj->nTri; ++i, ++tri)
				{
					// copy vertex data to new variables
					if (!reverseOrder)
					{
						// copy vertex data to new variables
//						tp[0] = *(GUT_POINT*)v[tri->vtx[0]].data.xyzw;
//						tp[1] = *(GUT_POINT*)v[tri->vtx[1]].data.xyzw;
//						tp[2] = *(GUT_POINT*)v[tri->vtx[2]].data.xyzw;

						for (j = 0; j < tri->nVtx; ++j)
						{
							tp[j] = *(GUT_POINT*)v[tri->vtx[j]].data.xyzw;
						}
					}
					else
					{
						// copy vertex data to new variables
//						tp[0] = *(GUT_POINT*)v[tri->vtx[0]].data.xyzw;
//						tp[1] = *(GUT_POINT*)v[tri->vtx[2]].data.xyzw;
//						tp[2] = *(GUT_POINT*)v[tri->vtx[1]].data.xyzw;

						for (j = 0; j < tri->nVtx; ++j)
						{
							tp[j] = *(GUT_POINT*)v[tri->vtx[j]].data.xyzw;
						}
					}

					// lighting 
					gut_center_point(&tp[0], &tp[1], &tp[2], &tp[3]);
					gut_vector(&tp[3], &light[1], &vec[0]);
					gut_normalize_vector(&vec[0]);

					// check for special flag to re-normalize
					if (ctx->drawAdj.normalizeFlag)//if (ctx->global_normalize)
					{
						gut_vector(&origin[1], &tp[0], &vab);
						gut_distance_from_point_to_point(&tp[0], &origin[1], &length);
						scale = 1.0 / length;
						gut_scale_vector(&vab, scale, &vab);
						gut_point_plus_vector(&origin[1], &vab, &tp[0]);

						gut_vector(&origin[1], &tp[1], &vab);
						gut_distance_from_point_to_point(&tp[1], &origin[1], &length);
						scale = 1.0 / length;
						gut_scale_vector(&vab, scale, &vab);
						gut_point_plus_vector(&origin[1], &vab, &tp[1]);

						gut_vector(&origin[1], &tp[2], &vab);
						gut_distance_from_point_to_point(&tp[2], &origin[1], &length);
						scale = 1.0 / length;
						gut_scale_vector(&vab, scale, &vab);
						gut_point_plus_vector(&origin[1], &vab, &tp[2]);
					}

					// get color 
					if (ctx->clrCtl.triangle.flag)
					{
						clr = &ctx->clrCtl.triangle.override;
					}
					else if (ctx->clrCtl.autoColor && !ctbl_get_color(gobj->ctT, tri->id, &clr))
					{
					}
					else
					{
						clr = &tri->color;
					}
					ctmp = *clr;

					// determine face normal from cross product & affect lighting
					if (ctx->clrCtl.useLightingFlag)
					{
						gut_vector(&tp[0], &tp[1], &vab);
						gut_vector(&tp[1], &tp[2], &vbc);
						gut_cross_product(&vab, &vbc, &normal);
						gut_normalize_point((GUT_POINT*)&normal);

						gut_dot_product(&vec[0], &normal, &incidenceAngle);

						incidenceAngle += ambient; // 0.5;
						incidenceAngle = incidenceAngle > 1.0 ? 1.0 : (incidenceAngle < 0 ? 0.0 : incidenceAngle);
						ctmp.r *= incidenceAngle;
						ctmp.g *= incidenceAngle;
						ctmp.b *= incidenceAngle;
					}

					sprintf(style, "style=\"fill:#%02x%02x%02x; \"", (int)(ctmp.r * 255), (int)(ctmp.g * 255), (int)(ctmp.b * 255));

					if (ctx->drawAdj.circleFlag)
					{
						int				n;
						GUT_POINT		poly[64];
						ds_svg_draw_circle_segment(&tp[0], &tp[1], &tp[2], poly, &n, &normal, &origin[1]);
						ctmp = *clr;
						// determine face normal from cross product & affect lighting
						if (ctx->clrCtl.useLightingFlag)
						{
							// lighting 
							gut_vector(&poly[0], &light[1], &vec[0]);
							gut_normalize_vector(&vec[0]);
							gut_dot_product(&vec[0], &normal, &incidenceAngle);

							incidenceAngle += ambient; // 0.5;

							incidenceAngle = incidenceAngle > 1.0 ? 1.0 : (incidenceAngle < 0 ? 0.0 : incidenceAngle);
							ctmp.r *= incidenceAngle;
							ctmp.g *= incidenceAngle;
							ctmp.b *= incidenceAngle;
						}
						sprintf(style, "style=\"fill:#%02x%02x%02x; \"", (int)(ctmp.r * 255), (int)(ctmp.g * 255), (int)(ctmp.b * 255));
						for (k = 0; k < n; ++k)
						{
							mtx_vector_multiply(1, (MTX_VECTOR*)&poly[k], &tpp[0], &mview); // mp);
							mtx_vector_multiply(1, (MTX_VECTOR*)&tpp[0], &poly[k], &mproj); // mp);
							poly[k].x /= poly[k].w;
							poly[k].y /= poly[k].w;
							poly[k].z /= poly[k].w;
						}
						sign = (poly[1].x - poly[0].x)*(poly[2].y - poly[0].y) - (poly[1].y - poly[0].y)*(poly[2].x - poly[0].x);
						if (sign < 0.0)
							continue;
						for (k = 0; k < n; ++k)
						{
							poly[k].x = poly[k].x * xscale + xoffset;
							poly[k].y = poly[k].y * yscale + yoffset;
							poly[k].y = ctx->window.height - poly[k].y;
						}
						svg_start_group(svg, style);
						svg_polygon(svg, poly, n);
						svg_end_group(svg, style);
					}
					else
					{
						for (k = 0; k < 3; ++k)
						{
							mtx_vector_multiply(1, (MTX_VECTOR*)&tp[k], &tpp[k], &mview); // mp);
							mtx_vector_multiply(1, (MTX_VECTOR*)&tpp[k], &tp[k], &mproj); // mp);
							tp[k].x /= tp[k].w;
							tp[k].y /= tp[k].w;
							tp[k].z /= tp[k].w;
						}
						sign = (tp[1].x - tp[0].x)*(tp[2].y - tp[0].y) - (tp[1].y - tp[0].y)*(tp[2].x - tp[0].x);
						if (sign < 0.0)
							continue;
						for (k = 0; k < 3; ++k)
						{
							tp[k].x = tp[k].x * xscale + xoffset;
							tp[k].y = tp[k].y * yscale + yoffset;
							tp[k].y = ctx->window.height - tp[k].y;
						}
						svg_start_group(svg, style);
						svg_polygon(svg, tp, 3);
						svg_end_group(svg, style);
					}
				}
			}
			if (gobj->nEdge && (ctx->geomAdj.drawWhat & 0x2)) //ctx->tri_edge_mode == 1 || ctx->tri_edge_mode == 2))
			{
				if (!gobj->v_out) // check if memory has been allocated
				{
					gobj->v_out = malloc(sizeof(MTX_VECTOR) * gobj->nVtx);
				}
				// push model view matrix onto stack
				mtx_stack_reset(stack);
				mtx_push_matrix(stack, mmp);
				mtx_push_matrix(stack, (MTX_MATRIX*)&ctx->matrix);
				mtx_create_translation_matrix(&mtran, ctx->trans[0], ctx->trans[1], ctx->trans[2]);
				mtx_push_matrix(stack, (MTX_MATRIX*)&mtran);
				mp = mtx_get_stack_top(stack);

				// transform all the vertices 
				mtx_vector_multiply(gobj->nVtx, (MTX_VECTOR*)gobj->vtx, gobj->v_out, mp);
				mtx_vector_multiply(1, (MTX_VECTOR*)&origin[0], &origin[1], mp);
				// correctly position the light 
				mtx_vector_multiply(1, (MTX_VECTOR*)&light[0], &light[1], mtran); // need to translate the light

				if (ctx->eAttr.type == GEOMETRY_EDGE_SQUARE)
				{
					for (i = 0, v = gobj->v_out, edge = gobj->edge; i < gobj->nEdge; ++i, ++edge)
					{
						// copy vertex data to new variables
						tp[0] = *(GUT_POINT*)v[edge->vtx[0]].data.xyzw;
						tp[1] = *(GUT_POINT*)v[edge->vtx[1]].data.xyzw;

						// check for special flag to re-normalize
						if (ctx->drawAdj.normalizeFlag)//if (ctx->global_normalize)
						{
							gut_vector(&origin[1], &tp[0], &vab);
							gut_distance_from_point_to_point(&tp[0], &origin[1], &length);
							scale = 1.0 / length;
							gut_scale_vector(&vab, scale, &vab);
							gut_point_plus_vector(&origin[1], &vab, &tp[0]);

							gut_vector(&origin[1], &tp[1], &vab);
							gut_distance_from_point_to_point(&tp[1], &origin[1], &length);
							scale = 1.0 / length;
							gut_scale_vector(&vab, scale, &vab);
							gut_point_plus_vector(&origin[1], &vab, &tp[1]);
						}

						// get appropriate color 
						if (ctx->clrCtl.line.flag) // override 
							clr = &ctx->clrCtl.line.override;
						else if (ctx->clrCtl.reverseColorFlag) // if drawing both triangles and edges and they share a common color table reverse the color ID
							ctbl_get_color_new(gobj->ctE, edge->id, ((ctx->geomAdj.drawWhat == 0x3) && (gobj->ctE == gobj->ctT)) ? 1 : 0, &clr);
						else
							ctbl_get_color(gobj->ctE, edge->id, &clr);

						ctmp = *clr;

						// create edge triangles but only use first 4
						geo_edge_to_triangles(ctx, &ctx->eAttr, &tp[0], &tp[1], out, ctx->drawAdj.normalizeFlag, &origin[1]);
						out[0].w = out[1].w = out[2].w = out[3].w = out[4].w = out[5].w = out[6].w = out[7].w = 1.0;

						if (ctx->clrCtl.useLightingFlag)
						{
							// lighting 
							gut_mid_point(&tp[0], &tp[1], &tp[3]);
							gut_vector(&tp[3], &light[1], &vec[0]);
							gut_normalize_vector(&vec[0]); // vector to light
							normal.i = tp[3].x - origin[1].x;
							normal.j = tp[3].y - origin[1].y;
							normal.k = tp[3].z - origin[1].z;
							normal.l = tp[3].w - origin[1].w;
							gut_normalize_vector(&normal); // vector tangent to surface

							gut_dot_product(&vec[0], &normal, &incidenceAngle);

							incidenceAngle += ambient; // 0.5;
							incidenceAngle = incidenceAngle > 1.0 ? 1.0 : (incidenceAngle < 0 ? 0.0 : incidenceAngle);
							ctmp.r *= incidenceAngle;
							ctmp.g *= incidenceAngle;
							ctmp.b *= incidenceAngle;
						}

						sprintf(style, "style=\"fill:#%02x%02x%02x; \"", (int)(ctmp.r * 255), (int)(ctmp.g * 255), (int)(ctmp.b * 255));

						for (k = 0; k < 4; ++k)
						{
							mtx_vector_multiply(1, (MTX_VECTOR*)&out[k], &tpp[0], &mview); // mp);
							mtx_vector_multiply(1, (MTX_VECTOR*)&tpp[0], &tp[k], &mproj); // mp);
							tp[k].x /= tp[k].w;
							tp[k].y /= tp[k].w;
							tp[k].z /= tp[k].w;
						}
						sign = (tp[1].x - tp[0].x)*(tp[2].y - tp[0].y) - (tp[1].y - tp[0].y)*(tp[2].x - tp[0].x);
						if (sign < 0.0)
							continue;
						for (k = 0; k < 4; ++k)
						{
							tp[k].x = tp[k].x * xscale + xoffset;
							tp[k].y = tp[k].y * yscale + yoffset;
							tp[k].y = ctx->window.height - tp[k].y;
						}
						svg_start_group(svg, style);
						svg_polygon(svg, tp, 4);
						svg_end_group(svg);// , style);
					}
				}
				else
				{
					GUT_VECTOR	norm[6];

					for (i = 0, v = gobj->v_out, edge = gobj->edge; i < gobj->nEdge; ++i, ++edge)
					{
						// copy vertex data to new variables
						tp[0] = *(GUT_POINT*)v[edge->vtx[0]].data.xyzw;
						tp[1] = *(GUT_POINT*)v[edge->vtx[1]].data.xyzw;

						// check for special flag to re-normalize
						if (ctx->drawAdj.normalizeFlag)//if (ctx->global_normalize)
						{
							gut_vector(&origin[1], &tp[0], &vab);
							gut_distance_from_point_to_point(&tp[0], &origin[1], &length);
							scale = 1.0 / length;
							gut_scale_vector(&vab, scale, &vab);
							gut_point_plus_vector(&origin[1], &vab, &tp[0]);

							gut_vector(&origin[1], &tp[1], &vab);
							gut_distance_from_point_to_point(&tp[1], &origin[1], &length);
							scale = 1.0 / length;
							gut_scale_vector(&vab, scale, &vab);
							gut_point_plus_vector(&origin[1], &vab, &tp[1]);
						}

						// get appropriate color 
						if (ctx->clrCtl.line.flag) // override 
							clr = &ctx->clrCtl.line.override;
						else if (ctx->clrCtl.reverseColorFlag) // if drawing both triangles and edges and they share a common color table reverse the color ID
							ctbl_get_color_new(gobj->ctE, edge->id, ((ctx->geomAdj.drawWhat == 0x3) && (gobj->ctE == gobj->ctT)) ? 1 : 0, &clr);
						else
							ctbl_get_color(gobj->ctE, edge->id, &clr);

						ctmp = *clr;

						geo_edge_to_triangles_hex(ctx, &ctx->eAttr, &tp[0], &tp[1], out, norm, ctx->drawAdj.normalizeFlag, &origin[1]);

						out[0].w = out[1].w = out[2].w = out[3].w = out[4].w = out[5].w = out[6].w = out[7].w = 1.0;

						if (ctx->clrCtl.useLightingFlag)
						{
							// lighting 
							gut_mid_point(&tp[0], &tp[1], &tp[3]);
							gut_vector(&tp[3], &light[1], &vec[0]);
							gut_normalize_vector(&vec[0]); // vector to light
							normal.i = tp[3].x - origin[1].x;
							normal.j = tp[3].y - origin[1].y;
							normal.k = tp[3].z - origin[1].z;
							normal.l = tp[3].w - origin[1].w;
							gut_normalize_vector(&normal); // vector tangent to surface

							gut_dot_product(&vec[0], &normal, &incidenceAngle);

							incidenceAngle += ambient; // 0.5;
							incidenceAngle = incidenceAngle > 1.0 ? 1.0 : (incidenceAngle < 0 ? 0.0 : incidenceAngle);
							ctmp.r *= incidenceAngle;
							ctmp.g *= incidenceAngle;
							ctmp.b *= incidenceAngle;
						}

//						draw_triangle_hex(ctx, &out, &normal, clr, 0, 6, 7);
//						draw_triangle_hex(ctx, &out, &normal, clr, 7, 1, 0);

						sprintf(style, "style=\"fill:#%02x%02x%02x; \"", (int)(ctmp.r * 255), (int)(ctmp.g * 255), (int)(ctmp.b * 255));

						// move vertices for top square
						out[3] = out[1];
						out[1] = out[6];
						out[2] = out[7];

						for (k = 0; k < 4; ++k)
						{
							mtx_vector_multiply(1, (MTX_VECTOR*)&out[k], &tpp[0], &mview); // mp);
							mtx_vector_multiply(1, (MTX_VECTOR*)&tpp[0], &tp[k], &mproj); // mp);
							tp[k].x /= tp[k].w;
							tp[k].y /= tp[k].w;
							tp[k].z /= tp[k].w;
						}
						sign = (tp[1].x - tp[0].x)*(tp[2].y - tp[0].y) - (tp[1].y - tp[0].y)*(tp[2].x - tp[0].x);
						if (sign < 0.0)
							continue;
						for (k = 0; k < 4; ++k)
						{
							tp[k].x = tp[k].x * xscale + xoffset;
							tp[k].y = tp[k].y * yscale + yoffset;
							tp[k].y = ctx->window.height - tp[k].y;
						}
						svg_start_group(svg, style);
						svg_polygon(svg, tp, 4);
						svg_end_group(svg);// , style);
					}

				}
			}
		}
	}

	// cleanup
	mtx_destroy_stack(stack);
}
*/