#include <stdlib.h>
#include <windows.h>		/* must include this before GL/gl.h */
#include <OBJBASE.H>
#include <direct.h>
#include <ShlObj.h>
#include <GL/gl.h>			/* OpenGL header file */
#include <GL/glext.h>		/* OpenGL header file */
#include <GL/wglext.h>
#include <stdio.h>
#include <math.h>
#include <commdlg.h>
#include "resource.h"
#include <geoutil.h>
#include <matrix.h>
#include <link.h>
#include "ds_sph.h"
#include "ds_file.h"
#include "ds_gua.h"
#include "ds_cmdline_lib.h"

enum OPTION { // need to be in the same order as the options
	OP_CD,
	OP_CIRCLE,
	OP_CLIP,
	OP_CLR_BACKGROUND,
	OP_CLR_E_SET,
	OP_CLR_E_USE,
	OP_CLR_F_DEFAULT,
	OP_CLR_F_SET,
	OP_CLR_F_USE,
	OP_CLR_TABLE,
	OP_CLR_V_SET,
	OP_DRAW,
	OP_EDGE_PARAM,
	OP_EDGE_TYPE,
	OP_FILM,
	OP_GEOMETRY,
	OP_GL_BACK,
	OP_GL_FRONT,
	OP_HELP,
	OP_HIRES,
	OP_IMAGE,
	OP_IN_CS,
	OP_IN_X_MIRROR,
	OP_IN_Z_ROTATE,
	OP_IN_TRANSFORM,
	OP_INACTIVE,
	OP_LIGHT,
	OP_NO_FOG,
	OP_NO_LIGHTING,
	OP_NO_UNIQUE,
	OP_NORMALIZE,
	OP_OBJECT,
	OP_ORIENTATION,
	OP_ORTHOGRAPHIC,
	OP_REPLICATE,
	OP_RX,
	OP_RY,
	OP_RZ,
	OP_SPIN,
	OP_SPP,
	OP_STEREO,
	OP_STEREO_ANGLE,
	OP_STEREO_NO_CROSS,
	OP_TOOLVIS,
	OP_TXYZ,
	OP_UDUMP,
	OP_VERTEX_SCALE,
	OP_WIN_WH,
	OP_WIN_XY,
};

//======================================== -back 
ARGUMENT	arg_back[] = {
	"fill",		"", 1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_POLYMODE_FILL,  0,	"",	/// back 1)) ctx->geomAdj.polymode[1] = GEOMETRY_POLYMODE_FILL;
	"line",		"", 1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_POLYMODE_LINE,  0,	"",	///, 1)) ctx->geomAdj.polymode[1] = GEOMETRY_POLYMODE_LINE;
	"point",	"", 1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_POLYMODE_POINT, 0,	"",	///	, 1)) ctx->geomAdj.polymode[1] = GEOMETRY_POLYMODE_POINT;
};
ARGUMENT_SET	set_back[] = {
	sizeof(arg_back) / sizeof(ARGUMENT), arg_back,			// top level
};

ARGUMENT	arg_front[] = {
	"fill",		"", 1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_POLYMODE_FILL,  0,	"",	/// back 1)) ctx->geomAdj.polymode[1] = GEOMETRY_POLYMODE_FILL;
	"line",		"", 1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_POLYMODE_LINE,  0,	"",	///, 1)) ctx->geomAdj.polymode[1] = GEOMETRY_POLYMODE_LINE;
	"point",	"", 1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_POLYMODE_POINT, 0,	"",	///	, 1)) ctx->geomAdj.polymode[1] = GEOMETRY_POLYMODE_POINT;
};
ARGUMENT_SET	set_front[] = {
	sizeof(arg_front) / sizeof(ARGUMENT), arg_front,			// top level
};

ATYPE	type_film[] = { ATYPE_STRING, ATYPE_INTEGER };
ADDR	addr_film[] = { 0, 0, };

ARGUMENT	arg_geometry[] = {
	"cube",		"", 1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_CUBEHEDRON,  0,	"",	/// geometry
	"icosa",	"", 1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_ICOSAHEDRON, 0,	"",	///
	"octa",		"", 1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_OCTAHEDRON,  0,	"",	///
	"tetra",	"", 1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_TETRAHEDRON, 0,	"",	///
};
ARGUMENT_SET	set_geometry[] = {
	sizeof(arg_geometry) / sizeof(ARGUMENT), arg_geometry,		// top level
};
ARGUMENT	arg_orientation[] = {
	"edge",		"", 1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_ORIENTATION_EDGE,	0,	"",	/// orientation
	"face",		"", 1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_ORIENTATION_FACE,	0,	"",	///
	"vertex",	"", 1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_ORIENTATION_VERTEX,  0,	"",	///
};
ARGUMENT_SET	set_orientation[] = {
	sizeof(arg_orientation) / sizeof(ARGUMENT), arg_orientation,		// top level
};

ARGUMENT	arg_main[] = {  // pre-sorted alphabetically
	"-cd",				 "-cd",		0,  1, (int*)ATYPE_STRING, 0, 0,							"set working directory",
	"-circle",			 "-cir",	0,  0, (int*)ATYPE_SET_EXPLICIT, 1, 0,						"enable circle mode",
	"-clip",			 "-clip",	0,  0, (int*)ATYPE_SET_EXPLICIT, 1, 0,						"enable clippling and set z and increment (z, increment)",
	"-clr_background",	 "-cbs",	6,  (ATYPE_ARRAY | 3), (int*)ATYPE_FLOAT_CLAMP, 0, 0,		"change the background color (r, g, b)",
	"-clr_e_set",		 "-ces",	0,  (ATYPE_ARRAY | 3), (int*)ATYPE_FLOAT_CLAMP, 0, 0,		"set current object edge override color (r, g, b)",
	"-clr_e_use",		 "-ceu",	0,  0, (int*)ATYPE_USER_FUNCTION, 0, 0,					"set which color to use for current object edges (A|O)",
	"-clr_f_default",	 "-cfds",	0,  (ATYPE_ARRAY | 3), (int*)ATYPE_FLOAT_CLAMP, 0, 0,		"set default color to assign to faces (r, g, b)",
	"-clr_f_set",		 "-cfs",	0,  (ATYPE_ARRAY | 3), (int*)ATYPE_FLOAT_CLAMP, 0, 0,		"set current object face override color (r, g, b)",
	"-clr_f_use",		 "-cfu",	0,  0, (int*)ATYPE_USER_FUNCTION, 0, 0,					"set which color to use for current object faces (E|A|O)",
	"-clr_table",		 "-ct",		0,  1, (int*)ATYPE_STRING, 0, 0,							"color table filename to read (filename)",
	"-clr_v_set",		 "-cvs",	0,  (ATYPE_ARRAY | 3), (int*)ATYPE_FLOAT_CLAMP, 0, 0,		"set current object vertex color (r, g, b)",
	"-draw",			 "-dr",		0,  0, (int*)ATYPE_USER_FUNCTION, 0, 0,					"set which components to draw on current object (FEV)",
	"-e_param",			 "-ep",		0,  (ATYPE_ARRAY | 3), (int*)ATYPE_DOUBLE, 0, 0,			"set edge parameters for the current object (width, height, offset)",
	"-e_type",			 "-et",		0,  0, (int*)ATYPE_USER_FUNCTION, 0, 0,					"set edge type for current object (box|round)",
	"-film",			 "-film",	0,  2, type_film, 0, addr_film,							"enable film mode ( #frames, base_filename )",
	"-geometry",		 "-geo",	0,	1, (int*)ATYPE_SUB_ARGUMENT, 0, (void*)&set_geometry,	"set base geometry (icosa|octa|cube|tetra)",
	"-gl_back",			 "-glb",	0,	1, (int*)ATYPE_SUB_ARGUMENT, 0, (void*)&set_back,		"set OpenGL mode for back facing polygons (fill|line|point)",
	"-gl_front",		 "-glf",	0,	1, (int*)ATYPE_SUB_ARGUMENT, 0, (void*)&set_front,		"set OpenGL mode for front facing polygons (fill|line|point)",
	"-help",			 "-help",	0,  0, (int*)ATYPE_USER_FUNCTION, 0, 0,					"display command line options",
	"-hires",			 "-hi",		0,  0, (int*)ATYPE_SET_EXPLICIT, 1, 0,						"enable high resolution rendering for edges and vertices",
	"-image",			 "-im",		0,  1, (int*)ATYPE_STRING, 0, 0,							"enable image capture mode (filename)",
	"-in_cs",			 "-incs",	0,  0, (int*)ATYPE_SET_EXPLICIT, 1, 0,						"enable input center and scaling",
	"-in_x_mirror",		 "-int",	0,  0, (int*)ATYPE_SET_EXPLICIT, 1, 0,						"enable input x axis mirroring",
	"-in_z_rotate",		 "-inx",	0,  0, (int*)ATYPE_SET_EXPLICIT, 1, 0,						"enable input z axis repetition",
	"-in_transform",	 "-inz",	0,  (ATYPE_ARRAY | 6), (int*)ATYPE_FLOAT, 0, 0,			"set and enable input rotation transformation (Zx, Zy, Zz, Yx, Yy, Yz)",
	"-inactive",		 "-ina",	0,  0, (int*)ATYPE_SET_EXPLICIT, 1, 0,						"set current object to be inactive",
	"-light",			 "-li",		0,  (ATYPE_ARRAY | 3), (int*)ATYPE_FLOAT, 0, 0,			"change the position of the light (x, y, z)",
	"-no_fog",			 "-nf",		0,  0, (int*)ATYPE_SET_EXPLICIT, 1, 0,						"disable fog",
	"-no_lighting",		 "-nl",		0,  0, (int*)ATYPE_SET_EXPLICIT, 1, 0,						"disable lighting",
	"-no_unique",		 "-nu",		0,  0, (int*)ATYPE_SET_EXPLICIT, 1, 0,						"disable unique processing on input",
	"-normalize",		 "-no",		0,  0, (int*)ATYPE_SET_EXPLICIT, 1, 0,						"enable normalization of all vertices",
	"-o",				 "-o",		0,  0, (int*)ATYPE_USER_FUNCTION, 0, 0,					"set current input object (filename.off|.spc)",
	"-orientation",		 "-ori",	0,	1, (int*)ATYPE_SUB_ARGUMENT, 0, (void*)&set_orientation,	"change default orientation (face|edge|vertex)",
	"-orthographic",	 "-ort",	0,  0, (int*)ATYPE_SET_EXPLICIT, GEOMETRY_PROJECTION_ORTHOGRAPHIC, 0,	"enable orthographic projection",
	"-replicate",		 "-rep",	0,  0, (int*)ATYPE_USER_FUNCTION, 0, 0,					"set current object replication options (01ZX)",
	"-rx",				 "-rx",		0,  0,	(int*)ATYPE_USER_FUNCTION, 0, 0,					"set initial x axis rotation (angle)",
	"-ry",				 "-ry",		0,  0,	(int*)ATYPE_USER_FUNCTION, 0, 0,					"set initial y axis rotation (angle)",
	"-rz",				 "-rz",		0,  0,	(int*)ATYPE_USER_FUNCTION, 0, 0,					"set initial z axis rotation (angle)",
	"-spin",			 "-spin",	0,  (ATYPE_ARRAY | 4), (int*)ATYPE_FLOAT, 0, 0,			"enable spin mode and set parameters (dx, dy, dz, mSec)",
	"-spp",				 "-spp",	0,  1,	(int*)ATYPE_INTEGER, 0, 0,							"set samples per pixel for rendering (#)",
	"-stereo",			 "-st",		0,  0, (int*)ATYPE_SET_EXPLICIT, 1, 0,						"enable stereo rendering - split screen",
	"-stereo_angle",	 "-sta",	0,  1, (int*)ATYPE_FLOAT, 0, 0,							"set the stereo eye seperation angle (angle)",
	"-stereo_no_cross",	 "-stnc",	0,  0, (int*)ATYPE_SET_EXPLICIT, 1, 0,						"disable cross-eye mode for stereo",
	"-toolvis",			 "-tv",		0,  0, (int*)ATYPE_SET_EXPLICIT, 1, 0,						"make tool windows visible at startup",
	"-txyz",			 "-txyz",	0,  (ATYPE_ARRAY | 3), (int*)ATYPE_FLOAT_CLAMP, 0, 0,		"set initial translation (x, y, z)",
	"-udump",			 "-ud",		0,  0, (int*)ATYPE_SET_EXPLICIT, 1, 0,						"enable automatic dump of unique processing results after object input",
	"-v_scale",			 "-vs",		0,  1, (int*)ATYPE_DOUBLE, 0, 0,							"set current object vertex scale (scale)",
	"-win_wh",			 "-wwh",	0,  (ATYPE_ARRAY | 2), (int*)ATYPE_INTEGER, 0, 0,			"set initial rendering window width and height (w, h)",
	"-win_xy",			 "-wxy",	0,  (ATYPE_ARRAY | 2), (int*)ATYPE_INTEGER, 0, 0,			"set initial rendering window left top corner position (x, y)",
};

ARGUMENT_SUBSTITUTE arg_main_substitute[]={
/*	OP_CLR_BACKGROUND,	 */  "-cbs",		"-clr_background",
/*	OP_CD,				 */  "-cd",			"-cd",
/*	OP_CLR_E_SET,		 */  "-ces",		"-clr_e_set",
/*	OP_CLR_E_USE,		 */  "-ceu",		"-clr_e_use",
/*	OP_CLR_F_DEFAULT,	 */  "-cfds",		"-clr_f_default",
/*	OP_CLR_F_SET,		 */  "-cfs",		"-clr_f_set",
/*	OP_CLR_F_USE,		 */  "-cfu",		"-clr_f_use",
/*	OP_CIRCLE,			 */  "-cir",		"-circle",
/*	OP_CLIP,			 */  "-clip",		"-clip",
/*	OP_CLR_TABLE,		 */  "-ct",			"-clr_table",
/*	OP_CLR_V_SET,		 */  "-cvs",		"-clr_v_set",
/*	OP_DRAW,			 */  "-dr",			"-draw",
/*	OP_EDGE_PARAM,		 */  "-ep",			"-e_param",
/*	OP_EDGE_TYPE,		 */  "-et",			"-e_type",
/*	OP_FILM,			 */  "-film",		"-film",
/*	OP_GEOMETRY,		 */  "-geo",		"-geometry",
/*	OP_GL_BACK,			 */  "-glb",		"-gl_back",
/*	OP_GL_FRONT,		 */  "-glf",		"-gl_front",
/*	OP_HELP,			 */  "-help",		"-help",
/*	OP_HIRES,			 */  "-hi",			"-hires",
/*	OP_IMAGE,			 */  "-im",			"-image",
/*	OP_INACTIVE,		 */  "-ina",		"-inactive",
/*	OP_IN_CS,			 */  "-incs",		"-in_cs",
/*	OP_IN_X_MIRROR,		 */  "-int",		"-in_transform",
/*	OP_IN_Z_ROTATE,		 */  "-inx",		"-in_x_mirror",
/*	OP_IN_TRANSFORM,	 */  "-inz",		"-in_z_rotate",
/*	OP_LIGHT,			 */  "-li",			"-light",
/*	OP_NO_FOG,			 */  "-nf",			"-no_fog",
/*	OP_NO_LIGHTING,		 */  "-nl",			"-no_lighting",
/*	OP_NORMALIZE,		 */  "-no",			"-normalize",
/*	OP_NO_UNIQUE,		 */  "-nu",			"-no_unique",
/*	OP_OBJECT,			 */  "-o",			"-o",
/*	OP_ORIENTATION,		 */  "-ori",		"-orientation",
/*	OP_ORTHOGRAPHIC,	 */  "-ort",		"-orthographic",
/*	OP_REPLICATE,		 */  "-rep",		"-replicate",
/*	OP_RX,				 */  "-rx",			"-rx",
/*	OP_RY,				 */  "-ry",			"-ry",
/*	OP_RZ,				 */  "-rz",			"-rz",
/*	OP_SPIN,			 */  "-spin",		"-spin",
/*	OP_SPP,				 */  "-spp",		"-spp",
/*	OP_STEREO,			 */  "-st",			"-stereo",
/*	OP_STEREO_ANGLE,	 */  "-sta",		"-stereo_angle",
/*	OP_STEREO_NO_CROSS,	 */  "-stnc",		"-stereo_no_cross",
/*	OP_TOOLVIS,			 */  "-tv",			"-toolvis",
/*	OP_TXYZ,			 */  "-txyz",		"-txyz",
/*	OP_UDUMP,			 */  "-ud",			"-udump",
/*	OP_VERTEX_SCALE,	 */  "-vs",			"-v_scale",
/*	OP_WIN_WH,			 */  "-wwh",		"-win_wh",
/*	OP_WIN_XY,			 */  "-wxy",		"-win_xy",
};

ARGUMENT_SET	set_main[] = {
	sizeof(arg_main) / sizeof(ARGUMENT), arg_main,			// top level
};

ARGUMENT_SET	set_main_substitute[] = {
	sizeof(arg_main_substitute) / sizeof(ARGUMENT_SUBSTITUTE), arg_main_substitute,			// top level
};

//-----------------------------------------------------------------------------
int disp_filename_arg_handler(ARGUMENT *arg, int *currentArgIndex, int maxNArgs, char **av, int *error)
//-----------------------------------------------------------------------------
{
	int		i;
	CTX		*ctx;
	if (!(ctx = (CTX*)arg->data)) { ++*error; return 1; }
	if (*currentArgIndex == maxNArgs) { ++*error; return 1; }//error

	// CREATE A NEW INPUT OBJECT
	GEO_INPUT_OBJECT	*gio = (GEO_INPUT_OBJECT*)malloc(sizeof(GEO_INPUT_OBJECT));
	if (!gio) return 1;

	LL_AddTail(ctx->inputObjq, gio); // add to queue
	ctx->curInputObj = gio; // make it the current object

	// inherit the default input object 
	memcpy(gio, &ctx->defInputObj, sizeof(GEO_INPUT_OBJECT));

	// replace the name
	gio->filename = (char*)malloc(strlen(av[*currentArgIndex]) + 1);
	strcpy(gio->filename, av[*currentArgIndex]);

	++*currentArgIndex; // move forward by one

	// update the addresses
	arg_main[OP_CLR_E_SET].addr		= (void*)&ctx->curInputObj->cAttr.edge.color;
	arg_main[OP_CLR_F_SET].addr		= (void*)&ctx->curInputObj->cAttr.face.color;
	arg_main[OP_CLR_V_SET].addr		= (void*)&ctx->curInputObj->cAttr.vertex.color;
	arg_main[OP_EDGE_PARAM].addr	= (void*)&ctx->curInputObj->eAttr.width;
	arg_main[OP_INACTIVE].addr		= (void*)&ctx->curInputObj->active;
	arg_main[OP_VERTEX_SCALE].addr	= (void*)&ctx->curInputObj->vAttr.scale;

	return 0;
}

//-----------------------------------------------------------------------------
static int disp_rotation(ARGUMENT *arg, int *currentArgIndex, int maxNArgs, char **av, int *error, int axis)
//-----------------------------------------------------------------------------
{
	int		i;
	CTX		*ctx;
	double	rotation;
	if (!(ctx = (CTX*)arg->data)) { ++*error; return 1; }
	if (*currentArgIndex == maxNArgs) { ++*error; return 1; }//error

	// get rotation value
	rotation = atof(av[*currentArgIndex]);
	++*currentArgIndex; // move forward by one

	if (rotation != 0)
	{
		MTX_MATRIX	mr, mm;

		ctx->matrixFlag = 1;
		mtx_create_rotation_matrix(&mr, axis, DTR(rotation));
		mtx_multiply_matrix(&ctx->matrix, &mr, &mm);
		ctx->matrix = mm;
	}

	return 0;
}
//-----------------------------------------------------------------------------
static int disp_rot_x_arg_handler(ARGUMENT *arg, int *currentArgIndex, int maxNArgs, char **av, int *error)
//-----------------------------------------------------------------------------
{
	return disp_rotation(arg, currentArgIndex, maxNArgs, av, error, MTX_ROTATE_X_AXIS);
}
//-----------------------------------------------------------------------------
static int disp_rot_y_arg_handler(ARGUMENT *arg, int *currentArgIndex, int maxNArgs, char **av, int *error)
//-----------------------------------------------------------------------------
{
	return disp_rotation(arg, currentArgIndex, maxNArgs, av, error, MTX_ROTATE_Y_AXIS);
}
//-----------------------------------------------------------------------------
static int disp_rot_z_arg_handler(ARGUMENT *arg, int *currentArgIndex, int maxNArgs, char **av, int *error)
//-----------------------------------------------------------------------------
{
	return disp_rotation(arg, currentArgIndex, maxNArgs, av, error, MTX_ROTATE_Z_AXIS);
}

//-----------------------------------------------------------------------------
static int disp_clip_arg_handler(ARGUMENT *arg, int *currentArgIndex, int maxNArgs, char **av, int *error)
//-----------------------------------------------------------------------------
{
	int		i;
	CTX		*ctx;
	double	zposition;
	if (!(ctx = (CTX*)arg->data)) { ++*error; return 1; }
	if (*currentArgIndex == maxNArgs) { ++*error; return 1; }//error

	// get z position value
	zposition = atof(av[*currentArgIndex]);
	++*currentArgIndex; // move forward by one

	ctx->drawAdj.clipFlag = 1;
	ctx->drawAdj.clipZValue = zposition;

	return 0;
}

//-----------------------------------------------------------------------------
static int disp_help_arg_handler(ARGUMENT *arg, int *currentArgIndex, int maxNArgs, char **av, int *error)
//-----------------------------------------------------------------------------
{
	CTX			*ctx;
	int			i, len;
	DWORD		nBytes;
	ARGUMENT	*a;
	char		buffer[1024];

	if (!(ctx = (CTX*)arg->data)) { ++*error; return 1; }

	AllocConsole();
	ctx->handle_out = GetStdHandle(STD_OUTPUT_HANDLE);
	ctx->handle_in = GetStdHandle(STD_INPUT_HANDLE);

	len = sprintf_s(buffer, sizeof(buffer), "DisplaySphere\n");
	WriteFile(ctx->handle_out, buffer, len, NULL, NULL);
	len = sprintf_s(buffer, sizeof(buffer), "Version - %s\n\n", PROGRAM_VERSION );
	WriteFile(ctx->handle_out, buffer, len, NULL, NULL);

	len = sprintf_s(buffer, sizeof(buffer), "Command line options\n\n" );
	WriteFile(ctx->handle_out, buffer, len, NULL, NULL);

	len = sprintf_s(buffer, sizeof(buffer), " %-20s %-9s %s\n", "Option", "Alternate", "Description");
	WriteFile(ctx->handle_out, buffer, len, NULL, NULL);
	len = sprintf_s(buffer, sizeof(buffer), " %-20s %-9s %s\n", "-----------------", "---------", "-------------------------");
	WriteFile(ctx->handle_out, buffer, len, NULL, NULL);

	for (i = 0, a=set_main->argument; i < set_main->nArguments; ++i, ++a)
	{
		len = sprintf_s(buffer, sizeof(buffer), " %-20s (%-7s) %s\n", a->text, a->alt, a->description);
		WriteFile(ctx->handle_out, buffer, len, NULL, NULL);
	}

	len = sprintf_s(buffer, sizeof(buffer), "\nHit return to exit or c to continue: ");
	WriteFile(ctx->handle_out, buffer, len, NULL, NULL);
	{

		char buffer[256];
		ReadFile(ctx->handle_in, buffer, 1, &nBytes, 0);
		if ( buffer[0] != 'c')
			exit(0);
		FreeConsole();
	}
	return 0;
}

//-----------------------------------------------------------------------------
static int disp_draw_what_arg_handler(ARGUMENT *arg, int *currentArgIndex, int maxNArgs, char **av, int *error)
//-----------------------------------------------------------------------------
{
	char				c, *p;
	CTX					*ctx;
	int					drawWhat = 0;

	if (!(ctx = (CTX*)arg->data)) { ++*error; return 1; }
	if (*currentArgIndex == maxNArgs) { ++*error; return 1; }//error

	GEO_INPUT_OBJECT	*gio = ctx->curInputObj;
	if (!gio)
		return 1;

	p = av[*currentArgIndex];
	++*currentArgIndex; // move forward by one

	while (c = *p++)
	{
		switch (c) {
		case 'f':  drawWhat |= GEOMETRY_DRAW_TRIANGLES;	break;
		case 'e':  drawWhat |= GEOMETRY_DRAW_EDGES;		break;
		case 'v':  drawWhat |= GEOMETRY_DRAW_VERTICES;		break;
		case 'F':  drawWhat |= GEOMETRY_DRAW_TRIANGLES;	break;
		case 'E':  drawWhat |= GEOMETRY_DRAW_EDGES;		break;
		case 'V':  drawWhat |= GEOMETRY_DRAW_VERTICES;		break;
		}
	}

	if (drawWhat) // don't update if not set correctly
		gio->drawWhat = drawWhat; // reset

	return 0;
}

//-----------------------------------------------------------------------------
static int disp_obj_clr_edge_arg_handler(ARGUMENT *arg, int *currentArgIndex, int maxNArgs, char **av, int *error)
//-----------------------------------------------------------------------------
{
	char				c, *p;
	CTX					*ctx;

	if (!(ctx = (CTX*)arg->data)) { ++*error; return 1; }
	if (*currentArgIndex == maxNArgs) { ++*error; return 1; }//error

	GEO_INPUT_OBJECT	*gio = ctx->curInputObj;
	if (!gio)
		return 1;

	p = av[*currentArgIndex];
	++*currentArgIndex; // move forward by one

	switch (c = *p) {
	case 'a':  gio->cAttr.edge.state = COLOR_STATE_AUTOMATIC;	break;
	case 'A':  gio->cAttr.edge.state = COLOR_STATE_AUTOMATIC;	break;
	case 'o':  gio->cAttr.edge.state = COLOR_STATE_OVERRIDE;	break;
	case 'O':  gio->cAttr.edge.state = COLOR_STATE_OVERRIDE;	break;
	}

	return 0;
}

//-----------------------------------------------------------------------------
static int disp_obj_clr_face_arg_handler(ARGUMENT *arg, int *currentArgIndex, int maxNArgs, char **av, int *error)
//-----------------------------------------------------------------------------
{
	char				c, *p;
	CTX					*ctx;

	if (!(ctx = (CTX*)arg->data)) { ++*error; return 1; }
	if (*currentArgIndex == maxNArgs) { ++*error; return 1; }//error

	GEO_INPUT_OBJECT	*gio = ctx->curInputObj;
	if (!gio)
		return 1;

	p = av[*currentArgIndex];
	++*currentArgIndex; // move forward by one

	switch (c = *p) {
	case 'a':  gio->cAttr.face.state = COLOR_STATE_AUTOMATIC;	break;
	case 'A':  gio->cAttr.face.state = COLOR_STATE_AUTOMATIC;	break;
	case 'e':  gio->cAttr.face.state = COLOR_STATE_EXPLICIT;	break;
	case 'E':  gio->cAttr.face.state = COLOR_STATE_EXPLICIT;	break;
	case 'o':  gio->cAttr.face.state = COLOR_STATE_OVERRIDE;	break;
	case 'O':  gio->cAttr.face.state = COLOR_STATE_OVERRIDE;	break;
	}

	return 0;
}

//-----------------------------------------------------------------------------
static int disp_object_e_type_arg_handler(ARGUMENT *arg, int *currentArgIndex, int maxNArgs, char **av, int *error)
//-----------------------------------------------------------------------------
{
	char				c, *p;
	CTX					*ctx;

	if (!(ctx = (CTX*)arg->data)) { ++*error; return 1; }
	if (*currentArgIndex == maxNArgs) { ++*error; return 1; }//error

	GEO_INPUT_OBJECT	*gio = ctx->curInputObj;
	if (!gio)
		return 1;

	p = av[*currentArgIndex];
	++*currentArgIndex; // move forward by one

	switch (c = *p) {
	case 'R':
	case 'r':
		gio->eAttr.type = GEOMETRY_EDGE_ROUND;
		break;
	case 'B':
	case 'b':
		gio->eAttr.type = GEOMETRY_EDGE_SQUARE;
		break;
	}

	return 0;
}

//-----------------------------------------------------------------------------
static int disp_obj_replicate_arg_handler(ARGUMENT *arg, int *currentArgIndex, int maxNArgs, char **av, int *error)
//-----------------------------------------------------------------------------
{
	char				c, *p;
	CTX					*ctx;

	if (!(ctx = (CTX*)arg->data)) { ++*error; return 1; }
	if (*currentArgIndex == maxNArgs) { ++*error; return 1; }//error

	GEO_INPUT_OBJECT	*gio = ctx->curInputObj;
	if (!gio)
		return 1;

	p = av[*currentArgIndex];
	++*currentArgIndex; // move forward by one

	while (c = *p++)
	{
		switch (c) {
		case '0':  gio->rAttr.oneFaceFlag = 0;	break;
		case '1':  gio->rAttr.oneFaceFlag = 1;	break;
		case 'x':
		case 'X':
			gio->rAttr.xMirrorFlag = 1;
			break;
		case 'z':
		case 'Z':
			gio->rAttr.zRotationFlag = 1;
			break;
		}
	}
	return 0;
}

//-----------------------------------------------------------------------------
int cmd_line_init(CTX *ctx)
//-----------------------------------------------------------------------------
{
	// assign pointers that can't be done at compile time
	ARGUMENT	*arg;

	arg = arg_back;
	arg[0].addr = (void*)&ctx->geomAdj.polymode[1];
	arg[1].addr = (void*)&ctx->geomAdj.polymode[1];
	arg[2].addr = (void*)&ctx->geomAdj.polymode[1];
	arg = arg_front;											//"-front", 0, 1, atype + 0, adata + 0, addr + 0,    // set front facing draw mode
	arg[0].addr = (void*)&ctx->geomAdj.polymode[0];
	arg[1].addr = (void*)&ctx->geomAdj.polymode[0];
	arg[2].addr = (void*)&ctx->geomAdj.polymode[0];
	arg = arg_geometry;											//"-geometry" set base geometry
	arg[0].addr = (void*)&ctx->base_geometry_new.type; //cube
	arg[1].addr = (void*)&ctx->base_geometry_new.type; //icos
	arg[2].addr = (void*)&ctx->base_geometry_new.type; //octa
	arg[3].addr = (void*)&ctx->base_geometry_new.type; //tetra
	arg = arg_orientation;											//"-orientation
	arg[0].addr = (void*)&ctx->geomAdj.orientation;
	arg[1].addr = (void*)&ctx->geomAdj.orientation;
	arg[2].addr = (void*)&ctx->geomAdj.orientation;
	
	addr_film[0] = (void*)ctx->png.basename;			// need to set index & flag correctly afterwards
	addr_film[1] = (void*)&ctx->png.nFrames;			// need to set index & flag correctly afterwards

	arg = arg_main;
	// GLOBALS ====================================================
	arg[OP_CD].addr				= (void*)ctx->curWorkingDir;					// "-cd set current working directory  
	arg[OP_CIRCLE].addr			= (void*)&ctx->drawAdj.circleFlag;				// "-cd set current working directory  
	arg[OP_CLIP].addr			= (void*)&disp_clip_arg_handler;				// "-cd set current working directory  
	arg[OP_CLIP].data			= (void*)ctx;									// 
	arg[OP_CLR_F_DEFAULT].addr	= (void*)&ctx->clrCtl.triangle.defaultColor;	// treat as float array
	arg[OP_CLR_BACKGROUND].addr = (void*)&ctx->clrCtl.bkgClear;					// treat as float array
	arg[OP_CLR_TABLE].addr		= (void*)&ctx->clrCtl.user_color_table;			// filename
//	arg[OP_GEOMETRY].addr		= 0; // need to be parsed
//	arg[OP_GL_BACK].addr		= 0
//	arg[OP_GL_FRONT].addr		= 0
	arg[OP_HELP].addr			= (void*)&disp_help_arg_handler;				// NEED FUNCTION
	arg[OP_HELP].data			= (void*)ctx;
	arg[OP_HIRES].addr			= (void*)&ctx->drawAdj.hiResFlag;				// -high resolution
	arg[OP_IMAGE].addr			= (void*)ctx->png.basename;						// need to set index & flag correctly afterwards

	arg[OP_LIGHT].addr			= (void*)&ctx->clrCtl.light;					// -light
	arg[OP_NO_FOG].addr			= (void*)&ctx->drawAdj.fogFlag;					// -nofog
	arg[OP_NO_LIGHTING].addr	= (void*)&ctx->clrCtl.useLightingFlag;			// -nolighting
	arg[OP_NORMALIZE].addr		= (void*)&ctx->drawAdj.normalizeFlag;			// -normal
//	arg[OP_ORIENTATION].addr	= 0;
	arg[OP_ORTHOGRAPHIC].addr	= (void*)&ctx->drawAdj.projection;				// change default
	arg[OP_SPP].addr			= (void*)&ctx->opengl.samplesPerPixel;			// -spp
	arg[OP_SPIN].addr			= (void*)&ctx->drawAdj.spin;					// -spin
	arg[OP_STEREO].addr			= (void*)&ctx->drawAdj.stereoFlag;				// -stereo
	arg[OP_STEREO_ANGLE].addr	= (void*)&ctx->drawAdj.eyeSeparation;
	arg[OP_STEREO_NO_CROSS].addr= (void*)&ctx->drawAdj.stereoCrossEyeFlag;
	arg[OP_TOOLVIS].addr		= (void*)&ctx->window.toolsVisible;				// -toolvis
	arg[OP_WIN_WH].addr			= (void*)&ctx->window.width;					// -win_wh
	arg[OP_WIN_XY].addr			= (void*)&ctx->window.start_x;					// -win_xy

//	INPUT MODIFICATIONS =================
	arg[OP_IN_CS].addr			= (void*)&ctx->inputTrans.centerAndScaleFlag;	// -in_cs
	arg[OP_IN_X_MIRROR].addr	= (void*)&ctx->inputTrans.mirrorFlag;			// -in_x_mirror
	arg[OP_IN_Z_ROTATE].addr	= (void*)&ctx->inputTrans.replicateFlag;		// -in_z_replicate
	arg[OP_IN_TRANSFORM].addr	= (void*)&ctx->inputTrans.zAxis;				// -ztran
	arg[OP_NO_UNIQUE].addr		= (void*)&ctx->inputTrans.guaFlag;				// -nogua
	arg[OP_RX].addr				= (void*)&disp_rot_x_arg_handler;				// 
	arg[OP_RX].data				= (void*)ctx;									// 
	arg[OP_RY].addr				= (void*)&disp_rot_y_arg_handler;				// 
	arg[OP_RY].data				= (void*)ctx;									// 
	arg[OP_RZ].addr				= (void*)&disp_rot_z_arg_handler;				// 
	arg[OP_RZ].data				= (void*)ctx;									// 
	arg[OP_TXYZ].addr			= (void*)&ctx->trans;							// -xyztran
	arg[OP_UDUMP].addr			= (void*)&ctx->inputTrans.guaResultsFlag;		// -unique_dump

// OBJECT PARAMETERS =================
	arg[OP_CLR_E_SET].addr		= (void*)&ctx->defInputObj.cAttr.edge.color; //  &gio->cAttr.edge.color;
	arg[OP_CLR_E_USE].addr		= (void*)&disp_obj_clr_edge_arg_handler; // NEED FUNCTION
	arg[OP_CLR_E_USE].data		= (void*)ctx;

	arg[OP_CLR_F_DEFAULT].addr	= (void*)&ctx->clrCtl.triangle.defaultColor; // keep it here

	arg[OP_CLR_F_SET].addr		= (void*)&ctx->defInputObj.cAttr.face.color; //&gio->cAttr.face.color;
	arg[OP_CLR_F_USE].addr		= (void*)&disp_obj_clr_face_arg_handler; // NEED FUNCTION
	arg[OP_CLR_F_USE].data		= (void*)ctx;

	arg[OP_CLR_V_SET].addr		= (void*)&ctx->defInputObj.cAttr.vertex.color; //&gio->cAttr.vertex.color;

	arg[OP_DRAW].addr			= (void*)&disp_draw_what_arg_handler; // NEED FUNCTION
	arg[OP_DRAW].data			= (void*)ctx;	
 
	arg[OP_EDGE_PARAM].addr		= (void*)&ctx->defInputObj.eAttr.width; //&gio->eAttr.width;

	arg[OP_EDGE_TYPE].addr		= (void*)&disp_object_e_type_arg_handler;
	arg[OP_EDGE_TYPE].data		= (void*)ctx;

	arg[OP_CLR_F_USE].addr		= (void*)&disp_obj_clr_face_arg_handler; // NEED FUNCTION
	arg[OP_CLR_F_USE].data		= (void*)ctx;

	arg[OP_INACTIVE].addr		= (void*)&ctx->defInputObj.active; //&gio->active;

	arg[OP_OBJECT].addr			= (void*)&disp_filename_arg_handler;
	arg[OP_OBJECT].data			= (void*)ctx;

	arg[OP_REPLICATE].addr		= (void*)&disp_obj_replicate_arg_handler; // NEED FUNCTION
	arg[OP_REPLICATE].data		= (void*)ctx;

	arg[OP_VERTEX_SCALE].addr	= (void*)&ctx->defInputObj.vAttr.scale; //&gio->vAttr.scale;

	return 0;
}

//-----------------------------------------------------------------------------
int ds_command_line(CTX *ctx, int ac, char **av, int *error, int *argIndex)
//-----------------------------------------------------------------------------
{
	int					currentIndex = 0;
	ARGUMENT_SUBSTITUTE *arg_sub;
	int					status = 0;

	cmd_line_init(ctx); // initialize any pointers

//	while (!arg_decode(set_main, &currentIndex, ac, av, error, argIndex))
//		;

	while (currentIndex < ac)
	{	
		// look for alternate short form - and replace if found
		if (arg_sub = arg_find_substitute(set_main_substitute, av[currentIndex]))
		{
			av[currentIndex] = arg_sub->longForm;
		}
		if(arg_decode(set_main, &currentIndex, ac, av, error, argIndex))
			break;
	}
	return 0;
}
