#include <stdlib.h>
#include <windows.h>		/* must include this before GL/gl.h */
#include <OBJBASE.H>
#include <direct.h>
#include <ShlObj.h>
#include <GL/gl.h>			/* OpenGL header file */
#include <GL/glext.h>		/* OpenGL header file */
#include <GL/wglext.h>
#include <stdio.h>
#include <math.h>
#include <commdlg.h>
#include "resource.h"
#include <geoutil.h>
#include <matrix.h>
#include <link.h>
#include "ds_sph.h"
#include "ds_file.h"
#include "ds_gua.h"
#include "ds_cmdline_lib.h"

//======================================== -back 
ARGUMENT	arg_back[] = {
	"fill",		1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_POLYMODE_FILL,  0,		/// back 1)) ctx->geomAdj.polymode[1] = GEOMETRY_POLYMODE_FILL;
	"line",		1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_POLYMODE_LINE,  0,		///, 1)) ctx->geomAdj.polymode[1] = GEOMETRY_POLYMODE_LINE;
	"point",	1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_POLYMODE_POINT, 0,		///	, 1)) ctx->geomAdj.polymode[1] = GEOMETRY_POLYMODE_POINT;
};
ARGUMENT_SET	set_back[] = {
	sizeof(arg_back) / sizeof(ARGUMENT), arg_back,			// top level
};

ARGUMENT	arg_front[] = {
	"fill",		1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_POLYMODE_FILL,  0,		/// back 1)) ctx->geomAdj.polymode[1] = GEOMETRY_POLYMODE_FILL;
	"line",		1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_POLYMODE_LINE,  0,		///, 1)) ctx->geomAdj.polymode[1] = GEOMETRY_POLYMODE_LINE;
	"point",	1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_POLYMODE_POINT, 0,		///	, 1)) ctx->geomAdj.polymode[1] = GEOMETRY_POLYMODE_POINT;
};
ARGUMENT_SET	set_front[] = {
	sizeof(arg_front) / sizeof(ARGUMENT), arg_front,			// top level
};

//ARGUMENT	arg_draw[] = {
//	"both",		1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)3, 0,		/// draw
//	"edge",		1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)2, 0,		///
//	"triangle",	1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)1, 0,		///
//};
//ARGUMENT_SET	set_draw[] = {
//	sizeof(arg_draw) / sizeof(ARGUMENT), arg_draw,			// top level
//};

ATYPE	type_film[] = { ATYPE_STRING, ATYPE_INTEGER };
ADDR	addr_film[] = { 0, 0, };

ATYPE	type_svg[] = { ATYPE_STRING, ATYPE_DOUBLE, ATYPE_INTEGER };
ADDR	addr_svg[] = { 0, 0, 0 };

ARGUMENT	arg_force_color[] = {
	"both",		1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)3, 0,		/// force color options
	"edge",		1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)2, 0,		///
	"triagle",	1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)1, 0,		///
};
ARGUMENT_SET	set_force_color[] = {
	sizeof(arg_force_color) / sizeof(ARGUMENT), arg_force_color,			// top level
};

ARGUMENT	arg_geometry[] = {
	"cube",		1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_CUBEHEDRON,  0,		/// geometry
	"icosa",	1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_ICOSAHEDRON, 0,		///
	"octa",		1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_OCTAHEDRON,  0,		///
	"tetra",	1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_TETRAHEDRON, 0,		///
};
ARGUMENT_SET	set_geometry[] = {
	sizeof(arg_geometry) / sizeof(ARGUMENT), arg_geometry,		// top level
};
ARGUMENT	arg_orientation[] = {
	"edge",		1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_ORIENTATION_EDGE,	0,		/// orientation
	"face",		1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_ORIENTATION_FACE,	0,		///
	"vertex",	1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_ORIENTATION_VERTEX,  0,		///
};
ARGUMENT_SET	set_orientation[] = {
	sizeof(arg_orientation) / sizeof(ARGUMENT), arg_orientation,		// top level
};
ARGUMENT	arg_estyle[] = {
	"box",		1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_EDGE_SQUARE,  0,
	"round",	1, 0, (int*)ATYPE_SET_EXPLICIT, (int*)GEOMETRY_EDGE_ROUND,   0,		
};
ARGUMENT_SET	set_estyle[] = {
	sizeof(arg_estyle) / sizeof(ARGUMENT), arg_estyle,			// top level
};

enum OPTION { // need to be in the same order as the options
	OP_BACK=0,
	OP_BACKGROUND,
	OP_CD,
	OP_CIRCLE,
	OP_CLIP,
	OP_COLOR_TABLE,
	OP_DEFAULT_COLOR,
	OP_DRAW,
	OP_EDGE_STYLE,
	OP_EDGE,
	OP_FILE,
	OP_FILM,
	OP_FORCE_COLOR,
	OP_FRONT,
	OP_GEOMETRY,
	OP_IMAGE,
	OP_IN_CS,
	OP_IN_MIRROR,
	OP_IN_REPLICATE,
	OP_LIGHT,
	OP_MIRROR,
	OP_NOFOG,
	OP_NOGUA,
	OP_NOLIGHTING,
	OP_NORMAL,
	OP_OEC,
	OP_ONE_FACE,
	OP_ORIENTATION,
	OP_ORTHO,
	OP_OTC,
	OP_REPLICATE,
	OP_RX,
	OP_RY,
	OP_RZ,
	OP_SAMPLES,
	OP_SPIN,
	OP_STEREO,
	OP_SVG,
	OP_TOOLVIS,
	OP_TRANSFORM,
	OP_TXYZ,
	OP_UDUMP,
	OP_UNIQUE_COLOR,
	OP_VERTEX,
	OP_WIN_WH,
	OP_WIN_XY,
};

ARGUMENT	arg_main[] = {  // pre-sorted alphabetically
"-back",			0,	1, (int*)ATYPE_SUB_ARGUMENT, 0, (void*)&set_back,				// set back facing draw mode
"-background",		0,	(ATYPE_ARRAY | 3), (int*)ATYPE_FLOAT_CLAMP, 0, 0, 				// set background color
"-cd",				0,	1, (int*)ATYPE_STRING, 0, 0,									// set current working directory  
"-circle",			0,	0, (int*)ATYPE_SET_EXPLICIT, 1, 0,								// set normalize option
"-clip",			0,	0, (int*)ATYPE_USER_FUNCTION, 0, 0,								// set normalize option
"-color_table",		0,	1, (int*)ATYPE_STRING, 0, 0,									// single frame capture option info
"-default_color",	0,	(ATYPE_ARRAY | 3), (int*)ATYPE_FLOAT_CLAMP, 0, 0,				// override color for triangles
//"-draw",			0,	1, (int*)ATYPE_SUB_ARGUMENT, 0, (void*)&set_draw,				// set draw what mode
"-draw",			0,	0, (int*)ATYPE_USER_FUNCTION, 0, 0,								// set normalize option
"-e_style",			0,	1, (int*)ATYPE_SUB_ARGUMENT, 0, (void*)&set_estyle, 			// set edge parameters
"-edge",			0,	(ATYPE_ARRAY | 3), (int*)ATYPE_DOUBLE, 0, 0, 					// set edge parameters
"-f",				0,	0, (int*)ATYPE_USER_FUNCTION, 0, 0,								// multi-file handler
"-film",			0,	2, type_film, 0, addr_film,										// set film parameters
"-force_color",		0,	1, (int*)ATYPE_SUB_ARGUMENT, 0, (void*)&set_force_color,		// override color for triangles/edges
"-front",			0,	1, (int*)ATYPE_SUB_ARGUMENT, 0, (void*)&set_front,				// set front facing draw mode
"-geometry",		2,	1, (int*)ATYPE_SUB_ARGUMENT, 0, (void*)&set_geometry,			// set geometry for replication
"-image",			0,	1, (int*)ATYPE_STRING, 0, 0,									// single frame capture option info
"-in_cs",			0,	0, (int*)ATYPE_SET_EXPLICIT, 1, 0,								// input modification - center and scale 
"-in_mirror",		0,	0, (int*)ATYPE_SET_EXPLICIT, 1, 0,								// input modification - x axis mirroring
"-in_replicate",	0,	0, (int*)ATYPE_SET_EXPLICIT, 1, 0,								// input modification - z axis replication
"-light",			0,	(ATYPE_ARRAY | 3), (int*)ATYPE_DOUBLE, 0, 0,					// light position 
"-mirror",			0,	0, (int*)ATYPE_SET_EXPLICIT, 1, 0,								// runtime modification - x axis mirroring
"-nofog",			0,	0, (int*)ATYPE_SET_EXPLICIT, 0, 0,								// set nofog
"-nogua",			0,	0, (int*)ATYPE_SET_EXPLICIT, 0, 0,								// set nogua
"-nolighting",		0,	0, (int*)ATYPE_SET_EXPLICIT, 0, 0,								// set use lighting flag
"-normal",			0,	0, (int*)ATYPE_SET_EXPLICIT, 1, 0,								// set normalize option
"-oec",				0,	(ATYPE_ARRAY | 3), (int*)ATYPE_FLOAT_CLAMP, 0, 0,				// override edge color 
"-one_face",		4,	0, (int*)ATYPE_SET_EXPLICIT, 1, 0,								// set face transforms off
"-orientation",		5,	1, (int*)ATYPE_SUB_ARGUMENT, 0, (void*)&set_orientation,		// set orientation
"-ortho",			0,	0, (int*)ATYPE_SET_EXPLICIT, GEOMETRY_PROJECTION_ORTHOGRAPHIC, 0,// override perpsective default
"-otc",				0,	(ATYPE_ARRAY | 3), (int*)ATYPE_FLOAT_CLAMP, 0, 0,				// override triangle color 
"-replicate",		3,	0, (int*)ATYPE_SET_EXPLICIT, 1, 0,								// runtime replication flag 
"-rx",				0,	0, (int*)ATYPE_USER_FUNCTION, 0, 0,								// initial axii rotations 
"-ry",				0,	0, (int*)ATYPE_USER_FUNCTION, 0, 0,								// initial axii rotations 
"-rz",				0,	0, (int*)ATYPE_USER_FUNCTION, 0, 0,								// initial axii rotations 
"-spp",				0,	1, (int*)ATYPE_INTEGER, 0, 0,									// samples per pixel 
"-spin",			0,	(ATYPE_ARRAY | 4), (int*)ATYPE_FLOAT, 0, 0,						// initial spin parameters 
"-stereo",			0,	0, (int*)ATYPE_SET_EXPLICIT, 1, 0,								// dump unique results
"-svg",				0,	3, type_svg, 0, addr_svg,										// set SVG parameters
"-toolvis",			0,	0, (int*)ATYPE_SET_EXPLICIT, 1, 0,								// open tool windows
"-transform",		0,	(ATYPE_ARRAY | 6), (int*)ATYPE_DOUBLE, 0, 0,					// input transformation axii 
"-txyz",			0,	(ATYPE_ARRAY | 3), (int*)ATYPE_FLOAT, 0, 0,						// initial translation 
"-udump",			0,	0, (int*)ATYPE_SET_EXPLICIT, 1, 0,								// dump unique results
"-unique_color",	0,	0, (int*)ATYPE_SET_EXPLICIT, 1, 0,								// use triangle unique colors
"-vertex",			0,	(ATYPE_ARRAY | 4), (int*)ATYPE_FLOAT, 0, 0,						// vertex scale & color 
"-win_wh",			0,	(ATYPE_ARRAY | 2), (int*)ATYPE_INTEGER, 0, 0,					// window initial width height 
"-win_xy",			0,	(ATYPE_ARRAY | 2), (int*)ATYPE_INTEGER, 0, 0,					// window initial x y corner 
};

ARGUMENT_SET	set_main[] = {
	sizeof(arg_main) / sizeof(ARGUMENT), arg_main,			// top level
};

//-----------------------------------------------------------------------------
int disp_filename_arg_handler(ARGUMENT *arg, int *currentArgIndex, int maxNArgs, char **av, int *error)
//-----------------------------------------------------------------------------
{
	int		i;
	CTX		*ctx;
	if (!(ctx = (CTX*)arg->data)) { ++*error; return 1; }
	if (*currentArgIndex == maxNArgs) { ++*error; return 1; }//error

	// check # of args left
	if ((i = ctx->nInputFiles) < MAX_NUM_INPUT_FILES)
	{
		ctx->inputFilename[i] = (char*)malloc(strlen(av[*currentArgIndex] + 1));
		strcpy(ctx->inputFilename[i], av[*currentArgIndex]);
		++ctx->nInputFiles;
		++*currentArgIndex; // move forward by one
	}
	return 0;
}

//-----------------------------------------------------------------------------
static int disp_rotation(ARGUMENT *arg, int *currentArgIndex, int maxNArgs, char **av, int *error, int axis)
//-----------------------------------------------------------------------------
{
	int		i;
	CTX		*ctx;
	double	rotation;
	if (!(ctx = (CTX*)arg->data)) { ++*error; return 1; }
	if (*currentArgIndex == maxNArgs) { ++*error; return 1; }//error

	// get rotation value
	rotation = atof(av[*currentArgIndex]);
	++*currentArgIndex; // move forward by one

	if (rotation != 0)
	{
		MTX_MATRIX	mr, mm;

		ctx->matrixFlag = 1;
		mtx_create_rotation_matrix(&mr, axis, DTR(rotation));
		mtx_multiply_matrix(&ctx->matrix, &mr, &mm);
		ctx->matrix = mm;
	}

	return 0;
}
//-----------------------------------------------------------------------------
static int disp_rot_x_arg_handler(ARGUMENT *arg, int *currentArgIndex, int maxNArgs, char **av, int *error)
//-----------------------------------------------------------------------------
{
	return disp_rotation(arg, currentArgIndex, maxNArgs, av, error, MTX_ROTATE_X_AXIS);
}
//-----------------------------------------------------------------------------
static int disp_rot_y_arg_handler(ARGUMENT *arg, int *currentArgIndex, int maxNArgs, char **av, int *error)
//-----------------------------------------------------------------------------
{
	return disp_rotation(arg, currentArgIndex, maxNArgs, av, error, MTX_ROTATE_Y_AXIS);
}
//-----------------------------------------------------------------------------
static int disp_rot_z_arg_handler(ARGUMENT *arg, int *currentArgIndex, int maxNArgs, char **av, int *error)
//-----------------------------------------------------------------------------
{
	return disp_rotation(arg, currentArgIndex, maxNArgs, av, error, MTX_ROTATE_Z_AXIS);
}

//-----------------------------------------------------------------------------
static int disp_clip_arg_handler(ARGUMENT *arg, int *currentArgIndex, int maxNArgs, char **av, int *error)
//-----------------------------------------------------------------------------
{
	int		i;
	CTX		*ctx;
	double	zposition;
	if (!(ctx = (CTX*)arg->data)) { ++*error; return 1; }
	if (*currentArgIndex == maxNArgs) { ++*error; return 1; }//error

	// get z position value
	zposition = atof(av[*currentArgIndex]);
	++*currentArgIndex; // move forward by one

	ctx->drawAdj.clipFlag = 1;
	ctx->drawAdj.clipZValue = zposition;

	return 0;
}

//-----------------------------------------------------------------------------
static int disp_draw_what_arg_handler(ARGUMENT *arg, int *currentArgIndex, int maxNArgs, char **av, int *error)
//-----------------------------------------------------------------------------
{
	char	c, *p;
	CTX		*ctx;

	if (!(ctx = (CTX*)arg->data)) { ++*error; return 1; }
	if (*currentArgIndex == maxNArgs) { ++*error; return 1; }//error

	p = av[*currentArgIndex];
	++*currentArgIndex; // move forward by one
	ctx->geomAdj.drawWhat = 0; // reset

	while (c = *p++)
	{
		switch (c) {
		case 't':  ctx->geomAdj.drawWhat |= GEOMETRY_DRAW_TRIANGLES;	break;
		case 'e':  ctx->geomAdj.drawWhat |= GEOMETRY_DRAW_EDGES;		break;
		case 'v':  ctx->geomAdj.drawWhat |= GEOMETRY_DRAW_VERTICES;		break;
		}
	}

	return 0;
}

//-----------------------------------------------------------------------------
int cmd_line_init(CTX *ctx)
//-----------------------------------------------------------------------------
{
	// assign pointers that can't be done at compile time
	ARGUMENT	*arg;

	arg = arg_back;
	arg[0].addr = (void*)&ctx->geomAdj.polymode[1];
	arg[1].addr = (void*)&ctx->geomAdj.polymode[1];
	arg[2].addr = (void*)&ctx->geomAdj.polymode[1];
//	arg = arg_draw;												// -draw
//	arg[0].addr = (void*)&ctx->geomAdj.drawWhat;
//	arg[1].addr = (void*)&ctx->geomAdj.drawWhat;
//	arg[2].addr = (void*)&ctx->geomAdj.drawWhat;
	arg = arg_force_color;										//-force_color", 0, 1, atype + 0, adata + 0, addr + 0,    // force override colo
	arg[0].addr = (void*)&ctx->clrCtl.forceWhat;
	arg[1].addr = (void*)&ctx->clrCtl.forceWhat;
	arg[2].addr = (void*)&ctx->clrCtl.forceWhat;
	arg = arg_front;											//"-front", 0, 1, atype + 0, adata + 0, addr + 0,    // set front facing draw mode
	arg[0].addr = (void*)&ctx->geomAdj.polymode[0];
	arg[1].addr = (void*)&ctx->geomAdj.polymode[0];
	arg[2].addr = (void*)&ctx->geomAdj.polymode[0];
	arg = arg_geometry;											//"-geometry" set base geometry
	arg[0].addr = (void*)&ctx->base_geometry_new.type; //cube
	arg[1].addr = (void*)&ctx->base_geometry_new.type; //icos
	arg[2].addr = (void*)&ctx->base_geometry_new.type; //octa
	arg[3].addr = (void*)&ctx->base_geometry_new.type; //tetra
	arg = arg_orientation;											//"-orientation
	arg[0].addr = (void*)&ctx->geomAdj.orientation;
	arg[1].addr = (void*)&ctx->geomAdj.orientation;
	arg[2].addr = (void*)&ctx->geomAdj.orientation;
	arg = arg_estyle;											//"-orientation
	arg[0].addr = (void*)&ctx->eAttr.type;
	arg[1].addr = (void*)&ctx->eAttr.type;

	addr_film[0] = (void*)ctx->png.basename;			// need to set index & flag correctly afterwards
	addr_film[1] = (void*)&ctx->png.nFrames;			// need to set index & flag correctly afterwards

	addr_svg[0] = (void*)ctx->svg.basename;				// need to set index & flag correctly afterwards
	addr_svg[1] = (void*)&ctx->svg.lineWidth;			// need to set index & flag correctly afterwards
	addr_svg[2] = (void*)&ctx->svg.backgroundFlag;		// need to set index & flag correctly afterwards

	arg = arg_main;
	arg[OP_BACKGROUND].addr		= (void*)&ctx->clrCtl.bkgClear;					// treat as float array
	arg[OP_CD].addr				= (void*)ctx->curWorkingDir;					// "-cd set current working directory  
	arg[OP_CIRCLE].addr			= (void*)&ctx->drawAdj.circleFlag;				// "-cd set current working directory  
	arg[OP_CLIP].addr			= (void*)&disp_clip_arg_handler;				// "-cd set current working directory  
	arg[OP_CLIP].data			= (void*)ctx;									// 
	arg[OP_COLOR_TABLE].addr	= (void*)&ctx->clrCtl.user_color_table;			// filename
	arg[OP_DEFAULT_COLOR].addr	= (void*)&ctx->clrCtl.triangle.defaultColor;	// treat as float array
	arg[OP_DRAW].addr			= (void*)&disp_draw_what_arg_handler;			// "-draw tev  
	arg[OP_DRAW].data			= (void*)ctx;									// 
	arg[OP_EDGE].addr			= (void*)&ctx->eAttr.width;						// treat as double array
	arg[OP_FILE].addr			= (void*)&disp_filename_arg_handler;			// 
	arg[OP_FILE].data			= (void*)ctx;									// 
	arg[OP_IMAGE].addr			= (void*)ctx->png.basename;						// "-capture", single frame capture option info
	arg[OP_IN_CS].addr			= (void*)&ctx->inputTrans.centerAndScaleFlag;	// -in_cs
	arg[OP_IN_MIRROR].addr		= (void*)&ctx->inputTrans.mirrorFlag;			// -in_mirror
	arg[OP_IN_REPLICATE].addr	= (void*)&ctx->inputTrans.replicateFlag;		// -in_replicate
	arg[OP_LIGHT].addr			= (void*)&ctx->clrCtl.light;					// -light
	arg[OP_MIRROR].addr			= (void*)&ctx->base_geometry_new.mirrorFlag;	// -replicate
	arg[OP_NOFOG].addr			= (void*)&ctx->drawAdj.fogFlag;					// -nofog
	arg[OP_NOGUA].addr			= (void*)&ctx->inputTrans.guaFlag;				// -nogua
	arg[OP_NOLIGHTING].addr		= (void*)&ctx->clrCtl.useLightingFlag;			// -nolighting
	arg[OP_NORMAL].addr			= (void*)&ctx->drawAdj.normalizeFlag;			// -normal
	arg[OP_OEC].addr			= (void*)&ctx->clrCtl.line.override;			// -oec
	arg[OP_ONE_FACE].addr		= (void*)&ctx->base_geometry_new.oneFaceFlag;	// -one_face
	arg[OP_ORTHO].addr			= (void*)&ctx->drawAdj.projection;				// change default
	arg[OP_OTC].addr			= (void*)&ctx->clrCtl.triangle.override;		// -otc
	arg[OP_REPLICATE].addr		= (void*)&ctx->base_geometry_new.zRotFlag;		// -replicate
	arg[OP_RX].addr				= (void*)&disp_rot_x_arg_handler;				// 
	arg[OP_RX].data				= (void*)ctx;									// 
	arg[OP_RY].addr				= (void*)&disp_rot_y_arg_handler;				// 
	arg[OP_RY].data				= (void*)ctx;									// 
	arg[OP_RZ].addr				= (void*)&disp_rot_z_arg_handler;				// 
	arg[OP_RZ].data				= (void*)ctx;									// 
	arg[OP_SAMPLES].addr		= (void*)&ctx->opengl.samplesPerPixel;			// -spp
	arg[OP_SPIN].addr			= (void*)&ctx->drawAdj.spin;					// -spin
	arg[OP_STEREO].addr			= (void*)&ctx->drawAdj.stereoFlag;				// -stereo
	arg[OP_TOOLVIS].addr		= (void*)&ctx->window.toolsVisible;				// -toolvis
	arg[OP_TRANSFORM].addr		= (void*)&ctx->inputTrans.zAxis;				// -ztran
	arg[OP_TXYZ].addr			= (void*)&ctx->trans;							// -xyztran
	arg[OP_UDUMP].addr			= (void*)&ctx->inputTrans.guaResultsFlag;		// -unique_dump
	arg[OP_UNIQUE_COLOR].addr	= (void*)&ctx->clrCtl.autoColor;				// -unique_color ctx->clrCtl.autoColor
	arg[OP_VERTEX].addr			= (void*)&ctx->renderVertex.scale;				// -vertex
	arg[OP_WIN_WH].addr			= (void*)&ctx->window.width;					// -win_wh
	arg[OP_WIN_XY].addr			= (void*)&ctx->window.start_x;					// -win_xy

	return 0;
}

//-----------------------------------------------------------------------------
int command_line(CTX *ctx, int ac, char **av, int *error)
//-----------------------------------------------------------------------------
{
	int		currentIndex = 0;

	cmd_line_init(ctx);
	while (!arg_decode(set_main, &currentIndex, ac, av, error))
		;
	return 0;
}
